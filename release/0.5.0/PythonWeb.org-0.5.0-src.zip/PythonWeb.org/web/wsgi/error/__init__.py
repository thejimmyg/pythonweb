"Error Handling"

import web, web.error, sys

class Error:
    def __init__(self, application):
        self.application = application

    def __call__(self, environ, start_response):
        try:
            result = self.application(environ, start_response)
        except:
            status, h, error = self.error()
            if not status or not h or not error:
                status = '500 Error'
                h = [('Content-type','text/plain')]
                start_response(status, h, sys.exc_info())
                return ['An error occured and the error handling middleware failed to handle it correctly.']
            else:
                #raise
                start_response(status, h)
                if type(error) == type(''):
                    return [error]
                else:
                    return error
        else:
            return result

    def error(self):
        "Generate an error report"
        #error = []
        #error.append('Error Report\n------------\n')
        #error.append(str(sys.exc_info()[1]))
        #error.append('')
        return '200 Error Handled', [('Content-type','text/html')], web.error.info(output='debug', format='html')
