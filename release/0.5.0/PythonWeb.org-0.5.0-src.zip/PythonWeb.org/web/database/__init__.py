"""web.database -- SQL database layer"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

from database import *

#~ """
#~ Points to note:

    #~ - Results aren't always automatically committed but sometimes are
    #~ - You can alter the fetch and execute modes

    #~ - Seconds must be whole seconds.

    #~ - Should be able to call the ColTypes table something else and block the use of the name ColTypes.
    #~ - Important to commit() changes before and after creating/altering/dropping code.
#~ """

#~ #import drivers

#~ class DBError(Exception):
    #~ """Error Class for the DB Module. Use as follows:

    #~ try:
        #~ raise DBError(ERROR_PASSWORD)
    #~ except SessionError, e:
        #~ print 'DB exception occurred, value:', e.value
    #~ """
    
    #~ def __init__(self, value):
        #~ self.value = value
    #~ def __str__(self):
        #~ return self.value
        
#~ class DateError(Exception):
    #~ """Error Class for the Date Module. Use as follows:

    #~ try:
        #~ raise DateError(ERROR_PASSWORD)
    #~ except SessionError, e:
        #~ print 'Date exception occurred, value:', e.value
    #~ """
    #~ def __init__(self, value):
        #~ self.value = value
    #~ def __str__(self):
        #~ return self.value

#~ def connect(type, structureTableName='StructureTable', createStructureTable=True, **params):
    #~ """Empty params can be specified or params which aren't used."""  
    #~ if type.lower() == 'mysql':
        #~ import drivers.mysql as driver
    #~ elif type.lower() == 'snakesql':
        #~ import drivers.snake as driver
    #~ elif type.lower() == 'odbc':
        #~ import drivers.odbc as driver
    #~ elif type.lower() == 'sqlite':
        #~ import drivers.sqlite as driver
    #~ else:
        #~ raise Exception('Unknown datbase type %s'%(repr(type)))
    #~ return driver.Connection(
        #~ structureTableName=structureTableName,
        #~ driver = driver.driver,
        #~ createStructureTable = createStructureTable,
        #~ **params
    #~ )
