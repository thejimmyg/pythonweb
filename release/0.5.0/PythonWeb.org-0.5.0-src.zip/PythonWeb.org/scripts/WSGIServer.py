#!/usr/bin/env python

"""
PythonWeb.org WSGI Server 
   based on wsgiServer
"""

version = '1.0'

import sys; sys.path.append('../')
import web
    
def pathMap():
    sys.path.append('../doc/src/lib')
    import wsgiAuth, wsgiError, wsgiSession, wsgiSimple
    return {
        '/auth'    : wsgiAuth.application,
        '/error'   : wsgiError.application,
        '/session' : wsgiSession.application,
        '/simple'  : wsgiSimple.application,
    }
    
if __name__ == '__main__':
    from optparse import OptionParser, OptionGroup
    useage = "usage: %prog [options] database"
    parser = OptionParser(usage=useage, version="%%prog %s"%(version))
    parser.add_option("-l", "--launch",
        action="store_true", dest="launch", default=False,
        help="launch a web browser when started",
    )
    parser.add_option("-p", "--port",
        action="store", dest="port", default=8000,
        help="port on which to start the server", type="int",
    )
    (options, args) = parser.parse_args()
    print __doc__
    import wsgiServer
    server = wsgiServer.WSGIServer(('localhost', options.port), pathMap())
    while 1:
            print "Serving HTTP on %s port %s ..." % server.socket.getsockname()[0:2]
            sys.stdout.flush()
            server.handle_request()
    #server.serve_forever()
