#!/usr/bin/env python

import sys; sys.path.append('../../../') # show python where the web modules are
import web.xml
web.xml.transform("file-web-xml.xml","file-web-xml.xsl","xml.html")