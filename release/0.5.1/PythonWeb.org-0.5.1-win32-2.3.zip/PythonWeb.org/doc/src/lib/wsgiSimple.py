
def simplestApp(environ, start_response):
    """Simplest possible application object"""
    status = '200 OK'
    headers = [('Content-type','text/plain')]
    start_response(status, headers)
    return ['Hello world from simple_application!\n']

application = simplestApp
