#!/usr/bin/env python


"""SQL Interactive Interpreter - James Gardner

Bugs with related joins.. the errors raised are not the ones wanted!
"""
    
import sys, os.path
sys.path.append('../')
sys.path.append('../web/external/PDBC/')
import database
import code, traceback, time

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)
    
version = database.version
version_info = database.version_info

class SQLConsole(code.InteractiveConsole):
    "SQL Interactive Interpreter Class"
    def __init__(self, connectionParams, catchErrors=True, header="SQL Console", locals=None):
        code.InteractiveConsole.__init__(self, locals, header)
        self.connectionParams = connectionParams
        self.catchErrors = catchErrors
        sys.ps1 = 'sql> '

    def push(self, line):
        "If the line is a keyword, handle it. Otherwise send the line to the database as SQL."
        if line == 'help':
            print "See the online documentation at http://www.pythonweb.org/"
        elif line == 'copyright':
            print "Copyright James Gardner 2002-2005, All rights reserved."
        elif line == 'license':
            print "Released under the GNU LGPL. See the documentation at http://www.pythonweb.org/ for full information."
        elif line == 'exit':
            sys.exit(0)
        else:
            while line and line[1:] == ' ':
                line = line[1:]
            while line and line[-1:] == ' ':
                line = line[:-1]
            if not line:
                pass
            else:
                try:
                    self.buffer.append(line)
                    more = self.execute(line)
                    source = "\n".join(self.buffer)
                    #more = self.runsource(source, self.filename)
                    #if not more:
                    self.resetbuffer()
                    return more
                except SystemExit:
                    raise

    def execute(self, sql):
        """Connect to the database,y execute the SQL, return the result then close the connection
        so other users can access it."""
        start = time.time()
        connection = database.connect(**self.connectionParams)
        cursor = connection.cursor(fetch=False)
        try:
            try:
                cursor.execute(sql)
                results = cursor.fetchall(format='text')
                connection.commit()
            except:
                self.showtraceback()
            else:
                end = time.time()
                t = "%0.2f"%(end-start)
                if results:
                    print results
                print 'Query OK, %s sec\n'%t    
        finally:
            connection.close()
            


    def showtraceback(self):
        "Over-ride default traceback handling."
        if self.catchErrors:
            #if sys.exc_info()[0].__name__ in [
             #   'SQLError', 
            #    'SQLSyntaxError',
            #    'SQLKeyError',
            #    'SQLForeignKeyError',
            #]:
            print '\a'+sys.exc_info()[0].__name__+': '+str(sys.exc_info()[1])
            #else:
            #    code.InteractiveConsole.showtraceback(self)
            #    print "\aBUG: The error described above was not expected and should be considered a bug."
        else:
            raise

if __name__ == '__main__':
    from optparse import OptionParser, OptionGroup
    useage = "%prog [options]\ne.g. : %prog -a MySQL -d testDatabase\n\nUse %prog -h for a list of options"
    parser = OptionParser(usage=useage, version="SQL Console %s.%s"%(version_info[0],version_info[1]))
    
    parser.add_option(
        "-a", "--adapter",
        action="store", type="string", dest="adapter",
        help="type of database to connect to, eg MySQL, SnakeSQL",
    )
    parser.add_option(
        "-d", "--database",
        action="store", type="string", dest="database",
        help="database name to connect to",
    )
    parser.add_option(
        "-u", "--user",
        action="store", type="string", dest="user",
        help="username to connect with",
    )
    parser.add_option(
        "-p", "--password",
        action="store", type="string", dest="password",
        help="password to use",
    )
    parser.add_option(
        "-r", "--prepend",
        action="store", type="string", dest="prepend", default='',
        help="string to be transparently used in front of all tables",
    )
    parser.add_option(
        "-t", "--host",
        action="store", type="string", dest="host",
        help="remote host",
    )
    parser.add_option(
        "-o", "--port",
        action="store", type="string", dest="port",
        help="port to connect to",
    )
    parser.add_option(
        "-s", "--socket",
        action="store", type="string", dest="socket",
        help="socket to connect to if the database is running locally",
    )
    parser.add_option(
        "-e", "--debug",
        action="store_false", dest="catchError", default=True,
        help="exit when any exception occurs and display a traceback",
    )
    parser.add_option(
        "-m", "--more",
        action="store", type="string", dest="more",
        help="any other params as a dictionary, eg \"{'opt2':'val1', 'opt2'='val2'}\"",
    )
    (options, args) = parser.parse_args()

    more = {}
    if not options.adapter:
        parser.error('No database adapter specified')
    if options.more:
        try:
            more = eval(options.more)
        except:
            parser.error('Invalid syntax used in --more option\n%s'%(str(sys.exc_info()[1])))

    connectionParams = {
        'adapter'  : options.adapter,
        'database' : options.database,
        'user'     : options.user,
        'prepend'  : options.prepend,
        'password' : options.password,
        'host'     : options.host,
        'port'     : options.port,
        'socket'   : options.socket,
    }
    for k, v in connectionParams.items():
        if connectionParams[k] == None:
            del connectionParams[k]
    if more:
        for k,v in more.items():
            if k in ['adapter','database','user','prepend','password','host','port','socket']:
                parser.error('%s should not be specified by --more, it has a flag of its own. Use -h for details')
            else:
                connectionParams[k] = v
                
        op = []
        for k,v in more.items():
            op.append('%s=%s'%(k,repr(v)))
        print "\nUsing custom parameters %s\n"%', '.join(op)

    if connectionParams['adapter'].lower() == 'snakesql':
        for key in ['user','password','host','port','socket']:
            if connectionParams.has_key(key):
                parser.error('SnakeSQL does not support the %s parameter'%key)
        if not connectionParams['database']:
            parser.error('You must specify a database for SnakeSQL to connect to')
    # Check the database exists before we hide exceptions.
    try:
        connection = database.connect(**connectionParams)
    except Exception ,e:
        if options.catchError:
            print options.catchError
            print "Error: %s"%(str(sys.exc_info()[1]))
            sys.exit(1)
        else:
            raise
    else:
        connection.close()
    name = {
        'mysql': 'MySQL',
        'snakesql': 'SnakeSQL',
        'sqlite': 'SQLite',
    }
    header = """%s Interactive Prompt\nType SQL or "exit" to quit, "help", "copyright" or "license" for information."""%name[connectionParams['adapter'].lower()]
    c = SQLConsole(connectionParams, options.catchError, header=header)
    c.interact(header)
