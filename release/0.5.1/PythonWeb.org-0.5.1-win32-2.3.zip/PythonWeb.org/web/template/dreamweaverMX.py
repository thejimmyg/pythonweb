"""Module desinged to provide an easy interface to allow python programs to output HTML pages based on
Dreamweaver MX Templates *.dwt files.

The module allows you to treat editable regions as member variables of the page.

Basic Use:

    from xecos import template
    page = template.Template("C:\\xecos\\Templates\\main.dwt")

    # Preferred method using member variable notation
    page.Content = 'This is the content'        # Assignment overwrites the current text.
    page.Content += '...more content'           # String concatonation appends text to the end of the.
    print page.Content

    # Using mapping notation:
    page['Content'] = 'This is the content'     # Assignment overwrites the current text.
    page['Content'] += '...more content'        # String concatonation appends text to the end of the.
    print page['Content']

    # If 'Content' is the fourth editable region in the template, can access the valus using list notation:
    page[3] = 'This is the content'             # Assignment overwrites the current text.
    page[3] += '...more content'                # String concatonation appends text to the end of the.
    print page[3]

    # If there is more than one editable region we can use slice notation to get an array of values:
    print page[1:2]

    # Demonstrate some features

    page[0] = '0'
    page[1] = '1'
    page[2] = '2'
    page[3] = '3'

    print page[0:4]

    page[1:3] = ['b','c',]
    print page[0:4]

    print page.keys()
    print page.has_key('Content')
    print page.items()
    print page.count('Content')
    print page.index('3')

    # Finally print the whole document complete with the altered editable regions.    
    print page


Important Public Functions:
          
    set(key, value)             # Set the editable region "key" to "value"
    get(key)                    # Get the contents of the editable region "key" as a string
    append(key, value)          # Append the editable region "key" with the string "value"
    output()                    # Return the new page with all the ediable regions included
    asDictionary()              # Return the contents of the editable regions as a dictionary with the region names as keys.
    asList()                    # Return the contents of thr editable regions as a list

    getTemplateRegion(key)      # Get the contents of the editable region "key" as a string from the template
    getTemplateRegions()        # Return the contents of the editable regions of the tamplate as a dictionary

    swapTemplatePaths(new, old) # Used to change the text in the template (not in the Editable Regions). Used to update the links and paths in the template to point to the correct URL
    
        
"""

__author__ = "James Gardner <james@xecos.com>"
__date__ = "02 February 2003, updated 11 February 2005"
__version__ = "0.2"
__credits__ = """Guido van Rossum, for an excellent programming language."""

import re, os.path

class TemplateError(Exception):
    """Raised when a general Error in the templates.py module occurs
    Attributes:
        message -- explanation of what the specific error is.
    """
    def __init__(self, message):
        self.message = message

    def __str__(self):
        return self.message

class Template:
    """Class to parse Macromedia Dreamweaver MX Template files"""
    
    def __init__(self,file=None, template=None):
        """Parse the Template and place the content of the editable regions of the template in a dictionary with the namesof the ediatable regions as the keys."""
        if file and template:
            raise Exception('You cannot specify both a file and template text to be used.')
        self.__dict__['pageRegions'] = {}
        self.__dict__['templateRegions'] = {}
        self.__dict__['templateHTML'] = ''
        self.__dict__['_regions'] = []
        self.__dict__['file'] = file
        #raise Exception(template)
        if file:
            temp=open(file, "r")
            self.__dict__['templateHTML'] = temp.read()
            temp.close()
        else:
            self.__dict__['templateHTML'] = template
        self._findTemplateRegions()
        #for k,v in self.getTemplateRegions().items():

    
    def _findTemplateRegions(self):
        """Private method to extract the names and content of the editable regions from the template file."""
        nameExpr=re.compile(r"<!--\s*?TemplateBeginEditable\s*name=\"(\W*\s*.*\w*)?\"\s*?-->")
        contentExpr=re.compile(r"<!--\s*?TemplateEndEditable\s*?-->")
        pos = 0
        while 1:
            nameMatch = nameExpr.search(self.templateHTML,pos)
            if not nameMatch:
                break
            contentMatch = contentExpr.search(self.templateHTML,nameMatch.end(0))
            try:
                nameMatch.end(0),contentMatch.start(0)
                self.templateRegions[nameMatch.group(1)]=self.templateHTML[nameMatch.start(0):contentMatch.end(0)]

            	self.pageRegions[nameMatch.group(1)] = self.templateHTML[nameMatch.end(0):contentMatch.start(0)]
            	self._regions.append(nameMatch.group(1))

                pos = contentMatch.end(0)  # start next search where this one ended
            except:
                raise TemplateError("Error: Parsing Failied")
        
    def get(self, key):
        """Return the current value of the editable region "key"."""
        if self.getTemplateRegions().has_key(key) :
            return str(self.pageRegions[key])
        else:
            raise TemplateError("Error, '%s' is not an editable region the template." % key)
    
    def set(self,key,value):
        """Set the editable region specified by key to value."""
        value = str(value)
        key = str(key)
        if self.getTemplateRegions().has_key(key):
            self.pageRegions[key]=value
        else:
            raise TemplateError("Error, '%s' is not an editable region of the template." % key)
        
    def append(self, key, value):
        """Append value to the end of the editable region specified in key."""
        value = str(value)
        key = str(key)
        self.set(key, self.get(key)+value)
        
    def getTemplateRegions(self):
        """Return a dictionary of the Template Editable Regions as they stand"""
        return self.templateRegions
    
    def getTemplateRegion(self, key):
        """Return the current value of the region in the template specified by key if it exists."""
        if self.getTemplateRegions().has_key(key) :
            return self.templateRegions[key]
        else:
            raise TemplateError("Error, '%s' is not an editable region the template." % key)
    
    def swapTemplatePaths(self, swapFrom, swapTo):
        """Used to change the text in the template (not in the Editable Regions). Used to update the links and paths in the template to point to the correct URL"""
        self.__dict__['templateHTML'] = re.sub(r'<(\s*.*?)(href|src)\s*=\s*"'+swapFrom+r'(.*?)"(\s*.*?)>', r'<\1\2="'+swapTo+r'\3"\4>', self.templateHTML)
    
    def output(self, file=None):
        """Merge the Editable Regions with the information in the Template to create the HTML page to be output. Returns the HTML"""
        output=self.templateHTML
        for k in self.templateRegions.keys():
            v = ''
            if self.asDictionary().has_key(k):
                v = self.asDictionary()[k]
            if not v:
                v=''
            output = output.replace(self.templateRegions[k], '<!-- InstanceBeginEditable name="'+k+'" -->'+v+'<!-- InstanceEndEditable -->')
            #output = re.sub(
            #    #r"<!--\s*?TemplateBeginEditable\s*?name=\""+k+"\" -->"+self.templateRegions[k]+r"<!--\s*?TemplateEndEditable\s*?-->",
            #    self.templateRegions[k],
            #    '<!-- InstanceBeginEditable name="'+k+'" -->'+v+'<!-- InstanceEndEditable -->',
            #    output
            #)
        if type(file) is type(''):
            f=open(file,'w')
            f.write(output)
            f.close
            return 1
        else:
            return output
    
    def __str__(self):
        """Returns a string containing the complete HTML page for printing"""
        return self.output()
    
    def __repr__(self):
        return '<%s, %s>' % (self.__class__, repr(self.file))
    
    # These work by being called if the value cannot be found in the ususal places (ie __dict__) so in the __init__
    # the variables must be declared for the first time using the self.__dict__['varname'] notation.
    
    def __getattr__(self, name):
        'Simulate attribute-access via editable region names. Get the value of the ediable region "name".'
        return self.get(str(name))
        
    def __setattr__(self, name, value):
        'Simulate attribute-access via editable region names. Set the value of the editable region "name" to "value".'
        self.set(name, str(value))
        
    def __getitem__(self, key):
        'Simulate indexed (tuple/list) and mapping-style access'
        if type(key) == type(1):
            key = self._regions[key]
            return self.get(key)
        return self.get(key)
    
    def __setitem__(self, key, value):
        'Simulate indexed (tuple/list) and mapping-style access'
        if type(key) == type(1):
            key = self._regions[key]
            self.set(key, str(value))
        self.set(key, str(value))
    
    def __getslice__(self, i, j):
        'Simulate list/tuple slicing access'
        list = []
        for key in self._regions[i:j]:
            list.append(self.get(key))
        return list
    
    def __setslice__(self, i, j, list):
        'Simulate list/tuple slicing access'
        counter = 0
        for key in self._regions[i:j]:
            self.set(key, list[counter])
            counter += 1

    # Simulated methods
    
    def keys(self):
        "Simulate mapping's methods"
        return self._regions
    
    def has_key(self, key):
        "Simulate mapping's methods"
        return key in self._regions
    
    def items(self):
        "Simulate mapping's methods"
        return self.asDictionary().items()
    
    def count(self, item):
        "Simulate list's methods"
        return self.asList().count(item)
    
    def index(self, item):
        "Simulate list's methods"
        return self.asList().index(item)
    
    # Conversion Fns
    
    def asDictionary(self):
        """Return a dictionary containing the text in editable regions of the page as it stands with the names of theeditable regions as the keys."""
        return self.pageRegions
    
    def asList(self):
        'Return the "list" as a real mapping'
        list=[]
        for key in self._regions:
            list.append(self.get(key))
        return list



