"Defines all the error classes used in the web modules."

class EnvironmentError(Exception):
    pass
        
class SessionError(Exception):
    """Error Class for the Session Module. Use as follows:

    try:
        raise SessionError(ERROR_PASSWORD)
    except SessionError, e:
        print 'Session exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return str(self.value)

class SessionWarning(SessionError):
    pass

class ErrorHandlingError(Exception):
    """Error Class for the Error Module. Use as follows:

    try:
        raise SessionError(ERROR_PASSWORD)
    except SessionError, e:
        print 'Session exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return str(self.value)
        
        
class AuthError(Exception):
    """Error Class for the Auth Module. Use as follows:

    try:
        raise AuthError(ERROR_PASSWORD)
    except AuthError, e:
        print 'Auth exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return str(self.value)
        
class FormError(Exception):
    """Error Class for the Form Module. Use as follows:

    try:
        raise AuthError(ERROR_PASSWORD)
    except AuthError, e:
        print 'Auth exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return str(self.value)
        
class DatabaseObjectError(Exception):
    pass
    