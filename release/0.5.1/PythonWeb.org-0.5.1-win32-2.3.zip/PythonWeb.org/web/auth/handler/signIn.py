import web.form

class SignInHandler:

    def __init__(self, session, manager, cgi=None, redirect=None, modeName='mode', action='', stickyData={}):
        self.session = session
        self.manager = manager
        self.modeName = modeName
        self.action = action
        self.status = None
        self.stickyData = stickyData
        self.messages = {
            # Errors
            'ALREADY_SIGNED_IN'     : 'You are already signed in. If you want to sign in again you should <a href="%s">sign out</a> first.'%('?%s=signOut'%(self.modeName)),
            'NOT_SIGNED_IN_YET'     : '', # No status message needs displaying
            'NO_USER_ENTERED'       : 'Please enter a username.',
            'NO_USER'               : 'The username you have specified does not exist.',
            'NO_PASSWORD_ENTERED'   : 'No password entered.',
            'INVALID_PASSWORD'      : 'The password is incorrect.',
            # Statements:
            'SIGNED_OUT'            : 'You have been sucessfully signed out.',
            'SIGNED_IN'             : '', # No status message is returned anyway
        }
        if cgi == None:
            self.cgi = web.cgi
        else:
            self.cgi = cgi
        self.redirect = redirect
        # Setup the form
        self.stickyData[self.modeName] = 'signIn'
        self.stickyData['redirect'] = redirect
        self.form = web.form.Form(method='get', stickyData=self.stickyData, action=self.action)
        self.form.addField(type='String', name='username', size=18, required=1, requiredError=self.messages['NO_USER_ENTERED'])
        self.form.addField(type='Password', name='password', size=18, required=1, requiredError=self.messages['NO_PASSWORD_ENTERED'])
        self.form.addAction('Sign In')
        
    def handle(self):
        username = self.session.username() # Get the username of the current logged in user
        if username:
            self.status = 'ALREADY_SIGNED_IN'
            return self.messages[self.status]
        elif not self.cgi.has_key(self.modeName) or self.cgi[self.modeName].value not in ['signIn','signOut']:
            self.status = 'NOT_SIGNED_IN_YET'
            return self.form.html()
        else:
            if self.cgi[self.modeName].value == 'signOut':
                self.session.signOut()
                self.status = 'SIGNED_OUT'
                return self.messages[self.status]
            else:
                self.form.populate(self.cgi)
                validates = 1
                if not self.form.valid():
                    return self.form.html()
                elif not self.manager.userExists(self.form['username'].value):
                    self.status = 'NO_USER'
                    self.form['username'].setError(self.messages[self.status])
                    return self.form.html()
                elif self.manager.getUser(self.form['username'].value).password <> self.form['password'].value:
                    self.status = 'INVALID_PASSWORD'
                    self.form['password'].setError(self.messages[self.status])
                    return self.form.html()
                else:
                    self.session.signIn(self.cgi['username'].value)
                    if self.redirect: # Redirect to correct place!
                        status = 'SIGNED_IN'
                        self.setHeader("Location",self.redirect)
                        return None
                    else:
                        status = 'SIGNED_IN'
                        return None
        
    def setHeader(self, header, value):
        print "%s: %s\n\n"%(header,value)
