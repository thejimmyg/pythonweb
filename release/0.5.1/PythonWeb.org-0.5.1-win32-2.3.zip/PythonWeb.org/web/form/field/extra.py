"Derived fields."



# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)
    
from typed import String, Text
import re

class Email(String):

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter an email address', size=40):
        """Initialisation code"""
        String.__init__(self, name, default, description, error, required, requiredError, size)

    def invalid(self, value):
        if value == None:
            return False
        m = re.search('^.+@.+\..+$',value)
        if not m:
            #raise Exception(value)
            return "Please enter a valid email address. eg. james@example.com"           
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        elif type(value) <> type(''):
            return "Invalid value. Values should be strings or None. Null stings '' are not allowed. Use None instead."
        elif self.maxlength:
            if len(value)>self.maxlength:
                return "Text must be less then %s characters"%self.maxlength
        return False

    def html(self):
        return '<input type="text" name="%s" value="%s" size="%s" /> <small>eg.&nbsp;james@example.com</small>'% (self.htmlName, self.value2str(self.value), self.size)

class URL(String):
    "Form field for a URL."
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a website address.', size=40):
        String.__init__(self, name, default, description, error, required, requiredError, size)

    def invalid(self, value):
        if value == None:
            return False
        m = re.search('^.+://.+\..+$',value)
        if not m:
            return "Please enter a valid website address. eg. http://www.example.com/"           
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        elif type(value) <> type(''):
            return "Invalid value. Values should be strings or None. Null stings '' are not allowed. Use None instead."
        elif self.maxlength:
            if len(value)>self.maxlength:
                return "Text must be less then %s characters"%self.maxlength
        return False
       
    def html(self):
        return '<input type="text" name="%s" value="%s" size="%s" /> <small>eg.&nbsp;http://www.example.com/</small>'% (self.htmlName, self.value2str(self.value), self.size)

fields = {
    'Email':Email,
    'URL':URL,
}