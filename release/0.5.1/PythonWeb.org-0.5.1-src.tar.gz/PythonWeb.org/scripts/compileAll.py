#!/usr/bin/env python

"""Compile all the Python source files for faster execution."""

def main(dir):
    import compileall
    compileall.compile_dir(dir) 

if __name__ == '__main__':
    print "Compiling all Python source files for faster execution."
    main("../web")
    raw_input('All done. Press Enter to exit.')

