"""Sessions

Changes

2005-02-03

- Default behaviour of setCookie is to set to the current Session Expire time if maxAge is not specified. This 
  requires setting the default of self.expireTime to be the correct expire length.
"""

import time, random, Cookie, md5, base64
from web.errors import SessionError, SessionWarning

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)

def driver(storage, environment, **params):
    if storage=='database':
        import web.session.drivers.database
        return web.session.drivers.database.DatabaseSessionDriver(name=environment, **params)
    else:
        raise SessionError('Invalid driver type %s'%repr(driver))

def manager(
    driver,
    expire=86400, # One day
    path='/',
    domain='',
    comment="Built in Python using web.session from pythonweb.org",
    maxAge=None,
    seed='PythonWeb', 
    cleanupProbability=0.05, 
):
    "Return a session manager object with the options specified"
    cookie = {
        #'lifetime':0,   # Lifetime in seconds of cookie or, if 0, until browser is restarted.
        'path':path,
        'domain':domain,   
        'comment':comment,
        'secure':0,
        'max-age':maxAge, # Max Age. (set by expires if None)
        'version':1
    }
    return SessionManager(
        driver=driver, 
        expire=expire, 
        cookie=cookie, 
        seed=seed, 
        cleanupProbability=cleanupProbability,
    )

def start(
    app,
    environmentName,
    environmentType='database',
    expire=0, 
    setupSessionEnvironment=0,
    path='/',
    domain='',
    comment="Built in Python using web.session from pythonweb.org",
    maxAge=None,
    seed='PythonWeb', 
    cleanupProbability=0.05, 
    **environmentParams
):
    import web.session
    driver = web.session.driver(environmentType, environment=environmentName, **environmentParams)
    if setupSessionEnvironment and not driver.completeSessionEnvironment():
        driver.removeSessionEnvironment(ignoreErrors=True)
        driver.createSessionEnvironment()
    # Set up a session manager and load or create a new session
    manager = web.session.manager(
        driver=driver, 
        expire=expire, 
        path=path,
        domain=domain,
        comment=comment,
        maxAge=maxAge,
        seed=seed, 
        cleanupProbability=cleanupProbability,
    )
    sessionID = manager.cookieSessionID()
    if not manager.load(sessionID):
        manager.create(sendCookieHeaders=False)
        manager.sendCookieHeaders()
    # Get the session store for this application
    return manager.store(app)

class SessionManager:
    "Session manager class for managing the creation, destruction, loading, checking etc of sessions"
    # Underscored methods do not check things exist as it is assumed they do if the manager has a sessionID. This 
    # is safe accept in the case you cleanup sessions for sessions with an expire time in the future or 
    # another application destroys the session
    
    def __init__(self, driver, expire, cookie, seed, cleanupProbability):
        self.expireTime = int(expire + time.time())
        # setup member variables
        self.driver = driver
        self.expire = expire
        
        self.created = False
        self.sessionID = None
        self.cleanupProbability = cleanupProbability
        # check cookie parameters
        self.cookie, errors = self._checkCookieParams(cookie)
        if errors:
            raise SessionError(errors)
        # Remove unwanted sessions
        if random.random() < float(self.cleanupProbability):
            self.cleanup()
        self.response_headers = []
        self.sent_headers = []
        
    def sendCookieHeaders(self):
        for part, info in self.response_headers:
        #for part, info, result in self.response_headers:
            header = '%s: %s'%(part, info)
            #self.sent_headers.append((header, result))
            self.sent_headers.append(header)
            print header
        self.response_headers = []
        
    def load(self, sessionID=None):
        if sessionID == None:
            sessionID = self.cookieSessionID()
        error, expireTime = self.driver.load(sessionID)
        if error:
            return False
        else:
            self.sessionID = sessionID
            self.expireTime = expireTime
            return True

    def cleanup(self, min=None, max=None, ignoreWarning=False):
        if min > max:
            raise SessionError('The minimum expire time to cleanup cannot be greater than the maximum, min=%s max=%s'%(min,max))
        if not min:
            min = 0
        if not max:
            max = int(time.time())
        elif max > int(time.time()):
            if not ignoreWarning:
                raise SessionWarning('It is dangerous to set max greater than the current time as this removes sessions that have not yet expired and maybe in use by other applications as it may cause them to crash. This error can be ignored by setting ignoreWarning==True')
        self.driver.cleanup(min, max)
    
    def valid(self, sessionID=None):
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        return self.driver.valid(sessionID)

    def exists(self, sessionID=None):
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        return self.driver.exists(sessionID)

    def destroy(self, sessionID=None, sendCookieHeaders=True, ignoreWarning=False):
        """End a session and if removeCookie=True remove the session cookie."""
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        if not ignoreWarning:
            raise SessionWarning('It is dangerous to destroy a session as it may be in use by other applications which may cause them to crash. If you wish to remove the information for this application only use the empty() method of the store object for the particular app. This error can be ignored by setting ignoreWarning=True')
        destroy = self.driver.destroy(sessionID)
        self.deleteCookie(sendCookieHeaders)
        return destroy

    def create(self, sendCookieHeaders=True, expire=None, maxAge=None):
        """Private method to start a new session."""
        if self.sessionID:
            raise SessionError('The session %s already exists, you cannot create a new session without destroying the old one'%self.sessionID)
        if expire == None:
            expire = self.expire
        if maxAge == None:
            maxAge = int(self.cookie['max-age'])
        # Only try and create a new ID 100 times.. after that something is going wrong!
        counter = 0
        sessionID = ''
        while 1:
            counter += 1
            if counter > 100:
                raise SessionError('Could not create valid SessionID.')
            g = random.Random(time.time())
            sessionID = self.genSessionID(str(int(g.random()*10000000)))
            if not self.exists(sessionID):
                break
        self.sessionID = sessionID
        self.setCookie(int(maxAge), sendCookieHeaders)
        self.driver.create(sessionID, int(time.time() + expire))
        self.created = True
        return self.sessionID

    def setExpire(self, expireTime, sessionID=None):
        "Shouldn't need to update the Expire"
        expireTime = int(expireTime)
        if sessionID == None:
            sessionID = self.sessionID
        if self.sessionID == None:
            raise SessionError('No session has been loaded')
        if expireTime < time.time():
            raise SessionError('You cannot update a session with a time less than the current time. If you wish to destroy a session use destroy()')
        r = self.driver.setExpire(expireTime, sessionID)
        self.expireTime = expireTime
        return r

    def cookieSessionID(self, environ=None, noSessionID=''):
        """Read and return the sessionID from the HTTP_COOKIE environment variable"""
        sessionID=''
        if environ==None:
            import os
            environ = os.environ
        try:
            cookie = environ["HTTP_COOKIE"]
        except KeyError:
            pass
        else:
            c2 = Cookie.SimpleCookie()
            c2.load(environ["HTTP_COOKIE"])
            try:
                sessionID=c2[self.driver.name].value
            except:
                pass
        if sessionID: 
            if len(sessionID)>32:
                # raise SessionError('The Session ID is invalid. Session IDs should be 32 characters long.')
                return noSessionID
            return sessionID
        else:
            return noSessionID
            
    def setCookie(self, maxAge=None, sendCookieHeaders=False):
        if maxAge == None:
            maxAge = int(self.expireTime - time.time())
        if type(maxAge) <> type(1):
            raise SessionError('maxAge should be an integer, %s is an invalid value'%repr(maxAge))
        result = self.setCookieString(int(maxAge)).split(': ')
        part = result[0]
        if type(result[1]) != type(''):
            info = ': '.join(result[1:])
        else:
            info = result[1]
        self.response_headers.append((part, info))
        if sendCookieHeaders:
            self.sendCookieHeaders()

    def deleteCookie(self, sendCookieHeaders=False):
        result = self.deleteCookieString().split(': ')
        part = result[0]
        if type(result[1]) != type(''):
            info = ': '.join(result[1:])
        else:
            info = result[1]
        self.response_headers.append((part, info))
        if sendCookieHeaders:
            self.sendCookieHeaders()
            
    def setCookieString(self, maxAge):
        """Private method to set the session cookie with the options specified by the cookie param"""
        # Create a cookie dictionary object
        c1 = Cookie.SimpleCookie()
        c1[self.driver.name] = self.sessionID
        for k, v in self.cookie.items():
            if v:
                c1[self.driver.name][k] = v
        c1[self.driver.name]["version"] = 1
        c1[self.driver.name]["max-age"] = int(maxAge)
        return str(c1)
        
    def deleteCookieString(self):
        """Private method to remove session cookie."""
        c1 = Cookie.SimpleCookie()
        c1[self.driver.name] = self.sessionID
        c1[self.driver.name]["max-age"] = 1   # Time to keep, in seconds
        #c1[self.driver.name]["expires"] = 1   # Obsolete, but Netscape still seems to require it.. should this be included?
        c1[self.driver.name]["version"] = 1
        # Print the headers that sets the cookies
        return str(c1)

    def _checkCookieParams(self, cookie):
        errors = []
        for key in cookie.keys():
            if key not in ['path','domain','comment','secure','max-age','version']:        
                error.append("'%s' is not a valid key for a cookie dictionary."%key)
        if cookie['max-age'] == None:
            cookie['max-age'] = self.expire # Or could be 0 for until the end of the session
        return cookie, ' '.join(errors)
    
    def genSessionID(self, seed=None):
        """Private method to generate a new sessionID. Uses the entropySeed specified in Lemon.ini."""
        if seed == None:
            seed = self.seed
        m = md5.new()
        m.update('this is a test of the emergency broadcasting system')
        m.update(str(time.time()))
        m.update(str(seed))
        session = base64.encodestring(m.digest())[:-3].replace('/', '$')
        session = session.replace('+','p')
        session = session.replace('$','d')
        session = session.replace('\\','b')
        session = session.replace('/','f')
        return session

    def store(self, app):
        return SessionStore(self.driver, self.sessionID, app, self)

class SessionStore:
    "Session store class for manipluating the values in the store or a particular application"
    def __init__(self, driver, sessionID, app, manager):
        if not app:
            raise SessionError('No app name has been specified')
        self.app = app
        self.driver = driver
        self.sessionID = sessionID
        self.manager = manager

    def set(self, key, value):
        "Public method to set a session variable. 'value' can be anything that can be pickled."
        return self.driver.set(self.sessionID, self.app, key, value)

    def get(self, key):#, otherwise):
        "Public method to retrieve a session variable."
        return self.driver.get(self.sessionID, self.app, key)#, otherwise)

    def delete(self, key):
        "Public method to remove a session variable."
        return self.driver.delete(self.sessionID, self.app, key)

    def empty(self):
        "Delete all values in the store for this application"
        return self.driver.empty(self.sessionID, self.app)
        
    def has_key(self, key):
        "Returns True if the key 'key' exists otherwise False."
        try:
            self.get(key)
        except SessionError:
            return False
        else:
            return True

    def keys(self):
        "Returns a list of store keys"
        return self.driver.keys(self.sessionID, self.app)
        
    def items(self):
        "Returns a list of store keys"
        return self.driver.items(self.sessionID, self.app)
        
    def values(self):
        "Returns a list of store keys"
        return self.driver.values(self.sessionID, self.app)
        
    def __getitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        return self.get(key)

    def __setitem__(self, key, value):
        "Allows the use of a dictionary-style interface to the session class."
        return self.set(key,value)
        
    def __delitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        return self.delete(key)
