"""SQLite driver for the PDBC module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import base, mysql, database, datetime, SnakeSQL, SQLParserTools
import os.path
converters = {
        'String':   base.BaseStringConverter(),
        'Text':     base.BaseTextConverter(),
        'Binary':   base.BaseBinaryConverter(),
        'Bool':     mysql.MySQLBoolConverter(),
        'Integer':  base.BaseIntegerConverter(),
        'Long':     base.BaseLongConverter(),
        'Float':    base.BaseFloatConverter(),
        'Date':     base.BaseDateConverter(),
        'Datetime': base.BaseDatetimeConverter(), # Decision already made.
        'Time':     base.BaseTimeConverter(),
}

class Connection(base.Connection):
    
    def makeConnection(self, **params):
        try:
            import sqlite
        except ImportError, e:
            raise ImportError('sqlite could not be imported and is required for SQLite database access. Please check it is correctly installed')
        if not params.has_key('database'):
            raise SnakeSQL.SQLError('No database specified')
        if os.path.exists(params['database']) and  os.path.isdir(params['database']):
            raise SnakeSQL.SQLError('Could not create database, the path "%s" is a directory not a database file'%params['database'])
        return sqlite.connect(**params)

    def commit(self):
        return base.Connection.commit(self)
        
    def rollback(self):
        return base.Connection.rollback(self)

class Cursor(mysql.Cursor):
    def create(self, **params):
        return base.Cursor.create(self, **params)

    #def _checkDeleteConstraints(self, table, where):
    #    pass
    # Only SQLite > 2.5 supports a way of doing this so manual check using the MySQL method
        
    def _checkInsertConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)

    def _checkUpdateConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)

    def drop(self, **params):
        return base.Cursor.drop(self, **params)

    def _setupTypes(self):
        return {
            'String':   "TEXT",
            'Text':     "TEXT",
            'Binary':   'MEDIUMBLOB',
            'Bool':     "INTEGER", # XXX
            'Integer':  "INTEGER",
            'Long':     "TEXT", # XXX
            'Float':    "FLOAT",
            'Date':     "TEXT",
            'Datetime': "TEXT", 
            'Time':     "TEXT",
        }

driver = {
    'converters':converters,
    'columnClass':base.BaseColumn,
    'tableClass':base.BaseTable,
    'cursorClass':Cursor,
}