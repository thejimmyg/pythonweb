"Session Handling"

import web.wsgi.base

class Session(web.wsgi.base.BaseMiddleware):
    """Session handling middleware
    
    The session middleware requires the following environ entries:
    web.envionment.name
    web.environment.type
    web.database.connection
    web.database.cursor
    """
    def __init__(self, application, app=None, setupEnvironment=False, expire=14400, maxAge = None):
        import web.session
        self.application = application
        self.newHeaders = []
        self.setupEnvironment = setupEnvironment
        self.expire = expire
        self.app = app
        self.maxAge = None
    
    def environ(self, environ):
        for key in [
            'web.environment.driver',
            'web.database.connection',
            'web.database.cursor'
        ]:
            if not environ.has_key(key):
                raise web.errors.SessionError('Expected %s key in environ dictionary'%key)
        if self.setupEnvironment:
            if not environ['web.environment.driver'].completeSessionEnvironment():
                environ['web.environment.driver'].removeSessionEnvironment(ignoreErrors=True)
                environ['web.environment.driver'].createSessionEnvironment()
            
        driver = web.session.driver(
            storage='database',
            cursor=environ['web.database.cursor'],
            environment=environ['web.environment.driver'].name,
        )
        manager = web.session.manager(driver=driver, expire=self.expire, maxAge = self.maxAge)
        sid = manager.cookieSessionID(environ)
        if not manager.load(sid):
            manager.create(sendCookieHeaders=False)
            self.newHeaders = [manager.response_headers[-1]]
        environ['web.session.driver'] = driver
        environ['web.session.manager'] = manager
        if self.app <> None:
            environ['web.session.store'] = manager.store(self.app)
        return environ

    def headers(self, headers):
        "This method allows you to make changes to headers. You should return headers"
        for header in headers:
            self.newHeaders.append(header)        
        return self.newHeaders
        