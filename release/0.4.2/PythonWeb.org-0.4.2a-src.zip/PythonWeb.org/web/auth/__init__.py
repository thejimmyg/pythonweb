"""Easy to use authorisation and user management system."""

import web.session, time, os, cgi
from web.errors import AuthError

def start(
    session, 
    storage='database',
    cursor=None,
    expire=0, 
    idle=0, 
    signInForm=None,
    autoSignIn=True,
    autoRedirect=False,
    redirect=None,
    includeQuery=False,
    stickyData={},
    reminderForm=None,
    emailOptions=None,
    app=None,
    errorCodes=None,
    htmlPage=None,
    encryption=None,
    table='Auth',
    dir=None,
    debug=False,
    checkSignInAttempt=False,
    htmlPageRegions={'content':'content','title':'title'},
):
    "The preffered method to start the auth classes."
    
    if storage == 'database':
        import authDatabase
        return authDatabase.AuthDatabase( 
            session, 
            expire, 
            idle, 
            signInForm, 
            autoSignIn, 
            autoRedirect, 
            redirect, 
            includeQuery, 
            stickyData, 
            reminderForm, 
            emailOptions, 
            app, 
            errorCodes, 
            htmlPage,
            encryption,
            cursor,
            table,
            debug,
            checkSignInAttempt,
            htmlPageRegions,
        )
    elif storage == 'file':
        import authFile
        return authFile.AuthFile( 
            session, 
            expire, 
            idle, 
            signInForm, 
            autoSignIn, 
            autoRedirect, 
            redirect, 
            includeQuery, 
            stickyData, 
            reminderForm, 
            emailOptions, 
            app, 
            errorCodes, 
            htmlPage,
            encryption,
            dir,
            debug,
            checkSignInAttempt,
            htmlPageRegions,
        )
    else:
        raise AuthError("You must specify a driver. 'database' is the only driver currently available.")
    
def setup(storage, cursor=None, dir=None, table='Auth'):
    if storage == 'database':
        import authDatabase
        return authDatabase.AuthManagerDatabase(cursor, table)
    elif storage == 'file':
        import authFile
        return authFile.AuthAdminFile(dir)
    else:
        raise AuthError("You must specify a storage driver. 'database' or 'file' are the only drivers currently available.")