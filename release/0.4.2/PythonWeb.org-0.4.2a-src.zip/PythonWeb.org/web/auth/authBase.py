"""Module containing the base class used to implement different Auth drivers.

NB: If autoSignIn is False you may just get a blank screen if login code isn't properly implemented in your own script.
Bugs..

Logining on for the first time doesn't check access rights"""



import web, os, time, md5, templates, web.template, web.mail
from web.errors import AuthError

class AuthBase:
    def __init__(
        self, 
        session, 
        expire=0, 
        idle=0, 
        signInForm=None, 
        autoSignIn=True, 
        autoRedirect=False,
        redirect=None, 
        includeQuery=False, 
        stickyData={}, 
        reminderForm=None, 
        emailOptions=None, 
        app=None, 
        errorCodes=None, 
        htmlPage=None,
        encryption=None,
        debug=False,
        checkSignInAttempt=False,
        htmlPageRegions={'content':'content','title':'title'},
    ):
        """
        Parameters:
            session     - Session from lemon.session.start()
            expire      - Maximum length of time the user is allowed to be logged in for
            idle        - Maximum length of time between user requests
            signInForm   - Function to display get the HTML for the signIn form
            autoSignIn   - Whether or not to automatically signIn the user
            redirect    - Where to go when logged in
            encryption  - Store the password in encrypted form. If chosen, email reminder is disabled.
            email = {
                'system':config.get('general','systemName'),
                'sender':config.get('admin','sender'),
                'reply':config.get('admin','reply'),
                'sendmail':config.get('admin','sendmail'),
                'smtp':config.get('admin','smtp'),
                'method':config.get('admin','method'),
            }
        """
        self.debug = debug
        self.checkSignInAttempt = checkSignInAttempt 
        self.session = session
        self.app = app
        if not app:
            self.app = self.session.app
        self.expire = int(expire)
        self.idle = int(idle)
        if self.idle > self.expire and self.expire > 0:
            raise AuthError('You cannot set the idle timeout to be greater than the expires timeout. To disable the idle timeout set it to 0.')
        if self.expire > session.params['expire']:
            raise AuthError("The 'expire' parameter (%ss) cannot be longer than the session length (%ss)."%(self.expire, self.session.params['expire']))
        self.stickyData = stickyData
        self.emailOptions = emailOptions
            
        if signInForm:
            if type(signInForm) not in [type((1,)), type([])]:
                self.signInFormTemplate = ['python',signInForm]
            else:
                self.signInFormTemplate = signInForm
            if len(self.signInFormTemplate) <> 2:
                raise AuthError('The signInForm template should be a list or tuple of the form [templateType, template].')
        else:
            self.signInFormTemplate = ['python',templates.signInForm]
            
        if reminderForm:
            if type(reminderForm) not in [type((1,)), type([])]:
                self.reminderFormTemplate = ['python',reminderForm]
            else:
                self.reminderFormTemplate = reminderForm
            if len(self.reminderFormTemplate) <> 2:
                raise AuthError('The reminderForm template should be a list or tuple of the form [templateType, template].')
        else:
            self.reminderFormTemplate = ['python',templates.reminderForm]

        if htmlPage:
            if type(htmlPage) not in [type((1,)), type([])]:
                self.htmlPageTemplate = ['python',htmlPage]
            else:
                self.htmlPageTemplate = htmlPage
            if len(self.htmlPageTemplate) <> 2:
                raise AuthError('The htmlPage template should be a list or tuple of the form [templateType, template].')
        else:
            self.htmlPageTemplate = ['python',templates.htmlPage]
            
        if htmlPageRegions.has_key('content') and htmlPageRegions.has_key('title') and htmlPageRegions['content'] <> htmlPageRegions['title']:
            self.htmlPageRegions = htmlPageRegions
        else:
            raise Exception('Invalid dictionary for htmlPageRegions.')

        self.autoSignIn = autoSignIn
        self.redirect = redirect
        self.autoRedirect = autoRedirect
        self.includeQuery = includeQuery
        self.encryption = encryption
        # Block App 'Auth' so it can't be accidently over-written.
        self.session.reserve('AuthRedirectURL')
        self.session.reserve('AuthStarted')
        self.session.reserve('AuthAccessed')
        #session.reserve('AuthIdleLength')
        #session.reserve('AuthExpireLength')
        self.session.reserve('AuthUser')
        
        self.__dict__['signedIn'] = False
        self.error = None
        
        self.errorCodes = {}
        if errorCodes:
            for k in errorCodes.keys():
                if k not in ['EXPIRED','IDLED','NO_USER','NO_SESSION','WRONG_USERNAME','WRONG_PASSWORD',
                    'NO_USER_ENTERED','PASS_REMINDER_SENT','ACCESS_DENIED','EMAIL_NOT_FOUND','NO_PASSWORD','NO_AUTO_SIGN_IN']:
                    raise AuthError("'%s' is not a valid error key."%k)
                else:
                    self.errorCodes[k] = str(errorCodes[k])
        else:
            self.errorCodes = templates.errorCodes

        self.__dict__['username'] = None
        self.__dict__['firstname'] = None
        self.__dict__['surname'] = None
        self.__dict__['password'] = None
        self.__dict__['email'] = None
        self.__dict__['level'] = {}
        self.__dict__['accessLevel'] = None
        
    def __setattr__(self, name, value):
        if name in ['username','password','firstname','surname','email','signedIn','accessLevel']:
            raise AuthError("You cannot set the attribute '%s' in this way."%name)
        else:
            self.__dict__[name] = value
            
    def check(self):
        if self.session.has_key('AuthStarted', block=False):
            started = self.session.get('AuthStarted', block=False)
            if started:
                # Checks the expired and idled times
                accessed     = self.session.get('AuthAccessed', block=False)
                currentTime  = int(time.time())
                if self.expire and ((self.expire + started) <= currentTime): # Session Expired
                    self.error = 'EXPIRED'
                    self.signOut()
                elif self.idle and ((self.idle + accessed) <= currentTime): # Session Idled
                    self.error = 'IDLED'
                    self.signOut()
                else:
                    # Auth session is still valid
                    # Retrieve the information for the User
                    username = self.session.get('AuthUser', block=False)
                    userExists = self.userExists(username) # Check that user exists
                    if not userExists:
                        self.error = 'NO_USER'
                        #self._printPage(self.signInForm('NO_USER', username),self.errorCodes['NO_USER'][0])
                    else:
                        level = self.getAccessLevel(username, self.app)
                        if not level:
                            self.error = 'ACCESS_DENIED'
                            #self._printPage(self.signInForm('ACCESS_DENIED', username),self.errorCodes['ACCESS_DENIED'][0])
                        else:
                            self.session.set('AuthAccessed',  int(time.time()), block=False)
                            self.__dict__['signedIn'] = True
                            self.error = None
                            user = self.getUser(username)
                            self.__dict__['firstname'] = user.firstname
                            self.__dict__['surname'] = user.surname
                            self.__dict__['username'] = user.username
                            self.__dict__['accessLevel'] = user.accessLevel
                            self.__dict__['level'] = user.level
                            self.__dict__['email'] = user.email
                            self.__dict__['password'] = user.password
                            return True
        return False
            
                

    def valid(self):
        "Checks to see if the current user is signed in. Returns True if they are. If the user is not signed in and autoSignIn is True, this function returns a sign in page and will handle subsequent sign in attempts automatically."
        if self.emailOptions and web.cgi.has_key('username') and not encryption:
            self.errorCodes['WRONG_PASSWORD'] = 'The password is incorrect. <a href="%s?mode=reminder&username=%s">Email a reminder</a>.'%(self._buildURL(includeQuery=False), web.cgi['username'].value)
    
    # 
    # Try to signIn and check the user is valid
    #
        
        # If we are in email password mode, deal with it.
        if self.emailOptions and web.cgi.has_key('mode') and web.cgi.has_key('username') and web.cgi['mode'].value == 'reminder':
            if web.cgi.has_key('email'):
                email = web.cgi['email'].value
                if email == self.getEmail(web.cgi['username'].value):
                    
                    firstname = self.getFirstname(web.cgi['username'].value)
                    if not firstname:
                        firstname = 'user'
                    
                    dict = {
                            'firstname' :   firstname,
                            'system'    :   self.emailOptions['system'], 
                            'password'  :   self.getPassword(web.cgi['username'].value),
                            'sender'    :   self.emailOptions['sender'],
                        }
                    msg = web.template.parse(type=self.emailOptions['type'], dict=dict, template=self.emailOptions['template'])
                    
                        
                    if self.emailOptions['method'] == 'sendmail':
                        web.mail.send(msg=msg, to=email, subject='Password Reminder', method='sendmail', sendmail=self.emailOptions['sendmail'], reply=self.emailOptions['reply'], sender=self.emailOptions['sender'])
                    elif self.emailOptions['method'] == 'smtp':
                        web.mail.send(msg=msg, to=email, subject='Password Reminder', method='smtp', smtp=self.emailOptions['smtp'],         reply=self.emailOptions['reply'], sender=self.emailOptions['sender'])
                    
                    self.error = 'PASS_REMINDER_SENT'
                    self._printPage(
                        self.signInForm(
                            username=web.cgi['username'].value,
                            error='PASS_REMINDER_SENT'
                        ),
                        self.errorCodes['PASS_REMINDER_SENT'][0]
                    )
                else:
                    self.error = 'EMAIL_NOT_FOUND'
                    self._printPage(
                        self.reminderForm(
                            stickyData={
                                'username':web.cgi['username'].value,
                                'mode':'reminder'
                            },
                            error='EMAIL_NOT_FOUND'
                        ),
                        self.errorCodes['EMAIL_NOT_FOUND'][0]
                    )
            else:
                self._printPage(
                    self.getReminderForm(
                        stickyData={
                            'username':web.cgi['username'].value,
                            'mode':'reminder'
                        }
                    ),
                    self.errorCodes['REMINDER'][0]
                )
        # Otherwise see if we are logged in
        else:
            # Get signInStatus
            
            # The session has started
            if self.session.has_key('AuthStarted', block=False) and (self.checkSignInAttempt==False or not web.cgi.has_key('username')):

                started = self.session.get('AuthStarted', block=False)
                
                # Checks the expired and idled times
                #expireLength = self.expire#self.session.get('AuthExpireLength', block=False)
                accessed     = self.session.get('AuthAccessed', block=False)
                #idleLength   = self.idle#self.session.get('AuthIdleLength', block=False)
                currentTime  = int(time.time())
                
                if self.expire and ((self.expire + started) <= currentTime): # Session Expired
                    self.error = 'EXPIRED'
                    self._printPage(self.signInForm('EXPIRED', self.session.get('AuthUser', block=False)),self.errorCodes['EXPIRED'][0])
                    self.signOut()
                elif self.idle and ((self.idle + accessed) <= currentTime): # Session Idled
                    self.error = 'IDLED'
                    self._printPage(self.signInForm('IDLED', self.session.get('AuthUser', block=False)),self.errorCodes['IDLED'][0])
                    self.signOut()
                else:
                    # Auth session is still valid
                    # Retrieve the information for the User
                    username = self.session.get('AuthUser', block=False)
                    userExists = self.userExists(username) # Check that user exists
                    if not userExists:
                        self.error = 'NO_USER'
                        self._printPage(self.signInForm('NO_USER', username),self.errorCodes['NO_USER'][0])
                    else:
                        level = self.getAccessLevel(username, self.app)
                        if not level:
                            self.error = 'ACCESS_DENIED'
                            self._printPage(self.signInForm('ACCESS_DENIED', username),self.errorCodes['ACCESS_DENIED'][0])
                        else:
                            self.session.set('AuthAccessed',  int(time.time()), block=False)
                            self.__dict__['signedIn'] = True
                            self.error = None
                            user = self.getUser(username)
                            self.__dict__['firstname'] = user.firstname
                            self.__dict__['surname'] = user.surname
                            self.__dict__['username'] = user.username
                            self.__dict__['accessLevel'] = user.accessLevel
                            self.__dict__['level'] = user.level
                            self.__dict__['email'] = user.email
                            self.__dict__['password'] = user.password
                
            elif not web.cgi.has_key('signIn'):

                # No Session (error 'NO_SESSION')
                self.error = 'NO_SESSION SessionID: '+self.session.params['sessionID']
                self._printPage(self.signInForm('LOGIN', ''),self.errorCodes['LOGIN'][0]) # XXX Again, need a no error code
            else:
                if self.autoSignIn:
                    if web.cgi.has_key('username') and web.cgi['username'].value <> '':
                        if web.cgi.has_key('password'):
                            # Try to signIn - Retrieves the information for the User
                            #status = self._signIn(web.cgi['username'].value,  web.cgi['password'].value)
                            password = web.cgi['password'].value
                            try:
                                realPass = self.getPassword(web.cgi['username'].value)
                            except AuthError, e:
                                if e.value == "No such username '%s'."%web.cgi['username'].value:
                                    self.error = 'WRONG_USERNAME'
                                    self._printPage(self.signInForm('WRONG_USERNAME', web.cgi['username'].value),self.errorCodes['WRONG_USERNAME'][0])
                                else:
                                    raise AuthError(e.value)
                            else:
                                if self.encryption=='md5':
                                    import md5
                                    m = md5.new(password)
                                    password = m.digest()
                                if password == realPass:
                                    level = self.getAccessLevel(web.cgi['username'].value, self.app)
                                    if not level:
                                        self.error = 'ACCESS_DENIED'
                                        self._printPage(self.signInForm('ACCESS_DENIED', web.cgi['username'].value),self.errorCodes['ACCESS_DENIED'][0])
                                    else:
                                        # Sets the Started and Accessed times
                                        self.session.set('AuthStarted',  int(time.time()), block=False)
                                        self.session.set('AuthAccessed',  int(time.time()), block=False)
                                        self.session.set('AuthUser', web.cgi['username'].value, block=False)
                                        self.__dict__['signedIn'] = True
                                        self.error = None
                                        user = self.getUser(web.cgi['username'].value)
                                       
                                        self.__dict__['firstname'] = user.firstname
                                        self.__dict__['surname'] = user.surname
                                        self.__dict__['username'] = user.username
                                        self.__dict__['accessLevel'] = user.accessLevel
                                        self.__dict__['email'] = user.email
                                        self.__dict__['password'] = user.password
                                        self.__dict__['level'] = user.level
                        
                                        if self.autoRedirect:
                                            if self.redirect:
                                                redirect = self.redirect
                                            elif self.includeQuery:
                                                redirect = self.session.get('AuthRedirectURL', block=False)
                                                self.session.delete('AuthRedirectURL', block=False)
                                            else:
                                                redirect = self._buildURL(includeQuery=False)
                                            location = "Location: "+ redirect + '\n\n' # XXX Even if redirect == ''
                                            
                                            # Problems with the lemon webserver.
                                            print location
                                else:
                                    # Wrong password
                                    self.error = 'WRONG_PASSWORD'
                                    self._printPage(self.signInForm('WRONG_PASSWORD', web.cgi['username'].value),self.errorCodes['WRONG_PASSWORD'][0])
                            # End try to signIn.
                        else:
                            self.error = 'NO_PASSWORD'
                            self._printPage(self.signInForm('NO_PASSWORD', web.cgi['username'].value), self.errorCodes['NO_PASSWORD'][0])
                    else:
                        self.session.set('AuthRedirectURL', self._buildURL(), block=False)
                        self.error = 'NO_USER_ENTERED'
                        self._printPage(self.signInForm('NO_USER_ENTERED',''), self.errorCodes['NO_USER_ENTERED'][0])
                else:
                    self.error = 'NO_AUTO_SIGN_IN'
                    self._printPage(self.signInForm('NO_AUTO_SIGN_IN',''), self.errorCodes['NO_AUTO_SIGN_IN'][0]) # XXX Not sure!
        return self.signedIn
        
    def _printPage(self, content, title=None):
        if not title:
            title = self.app
        
        print web.header() + web.template.parse(type=self.htmlPageTemplate[0], dict={self.htmlPageRegions['title']:title, self.htmlPageRegions['content']:content}, template=self.htmlPageTemplate[1])


    def _buildURL(self, includeQuery=True):
        query = ''
        
        if includeQuery and os.environ.has_key('QUERY_STRING') and os.environ['QUERY_STRING']:
            query       = '?' + os.environ['QUERY_STRING']
        
        port        = os.environ['SERVER_PORT']
        host        = os.environ['SERVER_NAME']
        scriptName  = os.environ['SCRIPT_NAME']
        
        if port == '80':
            port = ''
        else:
            port = ':'+str(port)
        
        # "http://%s%s"%(host, port,)
        return "%s%s" %(scriptName, query)

    #def _signIn(self, username, password):


    def signOut(self):
        """Checks to see if their is a valid entry for the session"""

        if self.session.get('AuthUser', block=False):
            #self.session.delete('AuthExpireLength', block=False)
            #self.session.delete('AuthIdleLength', block=False)
            self.session.delete('AuthStarted', block=False)
            self.session.delete('AuthAccessed', block=False)
            if self.session.has_key('AuthRedirectURL', block=False):
                self.session.delete('AuthRedirectURL', block=False)
            self.session.delete('AuthUser', block=False)
            return 1
        else:
            return 0

        
    def signInForm(self, error='', username='', stickyData={}):
        "Displays a form allowing the user to signIn."
        hidden = ''
        if not stickyData:
            stickyData = self.stickyData
        for k,v in stickyData.items():
            hidden += '<input type="hidden" name="%s" value="%s"/>'%(k,v)
        errorStr = ''
        if not error in ['NO_SESSION','',None]:
            errorStr = self.errorCodes[error][1]
        try:
            action = os.environ['SCRIPT_NAME']
        except KeyError:
            action = '' # XXX Needs fixing.
            
        error = ''
        if self.debug:
            error = "<!--%s-->"%self.error
        dict =  {
                    'name':'signIn',
                    'method':'post',
                    'action':action,
                    'username':username,
                    'stickyData': hidden, 
                    'message': errorStr,
                    'error':error,
                }
        return web.template.parse(type=self.signInFormTemplate[0], dict=dict, template=self.signInFormTemplate[1])

    def reminderForm(self, error='', stickyData={}):
        "Displays a form allowing the user to signIn."
        hidden = ''
        if not stickyData:
            stickyData = self.stickyData
        for k,v in stickyData.items():
            hidden += '<input type="hidden" name="%s" value="%s"/>'%(k,v)
        dict =  {
                    'name':'signIn',
                    'method':'post',
                    'action':os.environ['SCRIPT_NAME'],
                    'stickyData': hidden, 
                    'problem':error,
                    
                }
        return web.template.parse(type=self.reminderFormTemplate[0], dict=dict, template=self.reminderFormTemplate[1])

        
    #~ def getEmail(self):
        #~ raise Exception('Should be handled in the derived driver class.')
        
    #~ def getPassword(self, username):
        #~ raise Exception('Should be handled in the derived driver class.')
            
    #~ def getFirstname(self, username):
        #~ raise Exception('Should be handled in the derived driver class.')