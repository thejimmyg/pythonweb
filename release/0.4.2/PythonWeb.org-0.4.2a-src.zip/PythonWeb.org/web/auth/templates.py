"The default HTML templates associated with the Auth module."

signInForm = """
    <form name="%(name)s" method="%(method)s" action="%(action)s">
    <table border="0">
    <tr>
      <td>Username: </td><td><input type="text" name="username" value="%(username)s"></td>
    </tr>
    <tr>
      <td>Password: </td><td><input type="password" name="password"></td>
    </tr>
    <tr>
      <td></td><td><input type="hidden" name="signIn" value="True"><input type="submit" name="submit" value="Sign In"></td>
    </tr>
    </table>
    %(stickyData)s
    </form>
    %(error)s
    %(message)s<br>
"""

reminderForm = """
    %(problem)s
    <form name="%(name)s" method="%(method)s" action="%(action)s">
    <table border="0">
    <tr>
      <td>Email Address: </td><td><input type="text" name="email"></td>
    </tr>
    <tr>
      <td></td><td><input type="submit" name="submit" value="Sign In"></td>
    </tr>
    </table>
    %(stickyData)s

    </form>
"""
            

htmlPage = """
    <html>
    <head>
    <!-- PythonWeb.org web.auth Sign In -->
    <title>%(title)s</title>
    </head>
    <body>
    <h2>%(title)s</h2>
    %(content)s
    </body>
    </html>
"""

errorCodes = {     
    'LOGIN'             : ['Please Sign In',''],
    'REMINDER'          : ['Enter Email Address',''],
    'EXPIRED'           : ['Please Sign In','The session expired and you have been signed out.'],
    'IDLED'             : ['Please Sign In','The session has been left idle for too long and you have been signed out.'],
    'NO_USER'           : ['Please Sign In','The username specified in your session does not exist. Try signing in again.'],
    'NO_SESSION'        : ['Please Sign In','There is no session information for the username you are using. This may be because you have been signed out.'],
    'WRONG_USERNAME'    : ['Please Sign In','The username you have specified does not exist.'],
    'WRONG_PASSWORD'    : ['Please Sign In','The password is incorrect.'],
    'NO_USER_ENTERED'   : ['Please Sign In','Please enter a username.'],
    'PASS_REMINDER_SENT': ['Reminder Sent','A password reminder has been sent. Please check your email.'],
    'ACCESS_DENIED'     : ['Please Sign In','You do not have access rights to use this application.'],
    'EMAIL_NOT_FOUND'   : ['Enter Email Address','Email address not found. Please enter the email address your account was registered with.'],
    'NO_PASSWORD'       : ['Please Sign In','No password entered.'],
    'NO_AUTO_SIGN_IN'   : ['Please Sign In','The user is not signed in and autoSignIn mode is not enabled.'], 
}

