
import sys, os, types, time,  inspect, pydoc, linecache

from cgitb import scanvars, lookup, grey, strong, small, __UNDEF__, reset, enable, Hook, handler
    
tracebackString = ''

def getTraceback((etype, evalue, etb)):
    global tracebackString
    if not tracebackString:
        import traceback
        tracebackString = ''.join(traceback.format_exception(etype, evalue, etb))
    return tracebackString
    
def errorDict((etype, evalue, etb), context):
    d = _errorDict((etype, evalue, etb), context)
    d['html'] = html((etype, evalue, etb), context)
    d['text'] = text((etype, evalue, etb), context)
    return d
    
def _errorDict((etype, evalue, etb), context):
    d={'info':(etype, evalue, etb)}
    # Python Version
    d['pythonVersion'] = ('Python %s : %s' % (sys.version.split()[0], sys.executable))
    # Error Type
    if type(etype) is types.ClassType:
        etype = etype.__name__
    d['type'] = str(etype)
    d['value'] = str(evalue)
    # date
    d['date'] = time.ctime(time.time())
    
    # Exceptions:
    d['textException'] = textException((etype, evalue, etb))
    d['htmlException'] = htmlException((etype, evalue, etb))
    d['textCode'] = textCode((etype, evalue, etb), context)
    d['htmlCode'] = htmlCode((etype, evalue, etb), context)
    
    return d

def buildException((etype, evalue, etb),indent, sep, esep, strongStart, strongEnd, format):
    exception = [sep % (strongStart+str(etype)+strongEnd, str(evalue))]
    if type(evalue) is types.InstanceType:
        for name in dir(evalue):
            if name[:1] == '_': continue
            value = format(getattr(evalue, name))
            exception.append(esep % (indent, name, value))
    return ''.join(exception)

def textException((etype, evalue, etb)):
    indent = " "*4
    sep = '%s: %s'
    esep = '\n%s%s = %s'
    strongStart = ''
    strongEnd = ''
    format = pydoc.text.repr
    return buildException((etype, evalue, etb), indent, sep, esep, strongStart, strongEnd, format)
    
def htmlException((etype, evalue, etb)):
    indent = '<tt>' + small('&nbsp;' * 5) + '&nbsp;</tt>'
    sep = '<p>%s: %s'
    esep = '\n<br>%s%s&nbsp;=\n%s'
    strongStart = '<strong>'
    strongEnd = '</strong>'
    format = pydoc.html.repr
    return buildException((etype, evalue, etb), indent, sep, esep, strongStart, strongEnd, format)
            
def textCode((etype, evalue, etb), context=5):
    
    frames = []
    records = inspect.getinnerframes(etb, context)
    for frame, file, lnum, func, lines, index in records:
        file = file and os.path.abspath(file) or '?'
        args, varargs, varkw, locals = inspect.getargvalues(frame)
        call = ''
        if func != '?':
            call = 'in ' + func + \
                inspect.formatargvalues(args, varargs, varkw, locals,
                    formatvalue=lambda value: '=' + pydoc.text.repr(value))
                        
        highlight = {}
        def reader(lnum=[lnum]):
            highlight[lnum[0]] = 1
            try: return linecache.getline(file, lnum[0])
            finally: lnum[0] += 1
        vars = scanvars(reader, frame, locals)

        rows = [' %s %s' % (file, call)]
        if index is not None:
            i = lnum - index
            for line in lines:
                num = '%5d ' % i
                rows.append(num+line.rstrip())
                i += 1

        done, dump = {}, []
        for name, where, value in vars:
            if name in done: continue
            done[name] = 1
            if value is not __UNDEF__:
                if where == 'global': name = 'global ' + name
                elif where == 'local': name = name
                else: name = where + name.split('.')[-1]
                dump.append('%s = %s' % (name, pydoc.text.repr(value)))
            else:
                dump.append(name + ' undefined')

        rows.append('\n'.join(dump))
        frames.append('\n%s\n' % '\n'.join(rows))
    return ''.join(frames)
        
def htmlCode((etype, evalue, etb), context=5):
    
    
    
    indent = '<tt>' + small('&nbsp;' * 5) + '&nbsp;</tt>'
    frames = []
    records = inspect.getinnerframes(etb, context)
    for frame, file, lnum, func, lines, index in records:
        file = file and os.path.abspath(file) or '?'
        link = '<a href="file://%s">%s</a>' % (file, pydoc.html.escape(file))
        args, varargs, varkw, locals = inspect.getargvalues(frame)
        call = ''
        if func != '?':
            call = 'in ' + strong(func) + \
                inspect.formatargvalues(args, varargs, varkw, locals,
                    formatvalue=lambda value: '=' + pydoc.html.repr(value))

        highlight = {}
        def reader(lnum=[lnum]):
            highlight[lnum[0]] = 1
            try: return linecache.getline(file, lnum[0])
            finally: lnum[0] += 1
        vars = scanvars(reader, frame, locals)

        rows = ['<tr><td bgcolor="#d8bbff">%s%s %s</td></tr>' %
                ('<big>&nbsp;</big>', link, call)]
        if index is not None:
            i = lnum - index
            for line in lines:
                num = small('&nbsp;' * (5-len(str(i))) + str(i)) + '&nbsp;'
                line = '<tt>%s%s</tt>' % (num, pydoc.html.preformat(line))
                if i in highlight:
                    rows.append('<tr><td bgcolor="#ffccee">%s</td></tr>' % line)
                else:
                    rows.append('<tr><td>%s</td></tr>' % grey(line))
                i += 1

        done, dump = {}, []
        for name, where, value in vars:
            if name in done: continue
            done[name] = 1
            if value is not __UNDEF__:
                if where in ['global', 'builtin']:
                    name = ('<em>%s</em> ' % where) + strong(name)
                elif where == 'local':
                    name = strong(name)
                else:
                    name = where + strong(name.split('.')[-1])
                dump.append('%s&nbsp;= %s' % (name, pydoc.html.repr(value)))
            else:
                dump.append(name + ' <em>undefined</em>')

        rows.append('<tr><td>%s</td></tr>' % small(grey(', '.join(dump))))
        frames.append('''<p>
    <table width="100%%" cellspacing=0 cellpadding=0 border=0>
    %s</table>''' % '\n'.join(rows))
    return ''.join(frames)

def html((etype, evalue, etb), context=5):
    """Return a nice HTML document describing a given traceback."""
    dict = _errorDict((etype, evalue, etb), context)
    if type(etype) is types.ClassType:
        etype = etype.__name__
    pyver = 'Python ' + sys.version.split()[0] + ': ' + sys.executable
    date = time.ctime(time.time())
    head = '<body bgcolor="#f0f0f8">' + pydoc.html.heading(
        '<big><big><strong>%s</strong></big></big>' % dict['type'],
        '#ffffff', '#6622aa', dict['pythonVersion'] + '<br>' + dict['date']) + '''
<p>A problem occurred in a Python script.  Here is the sequence of
function calls leading up to the error, in the order they occurred.'''

    htmlCode = dict['htmlCode']
    htmlException = dict['htmlException']

    return head + htmlCode + htmlException + '''

<!-- The above is a description of an error in a Python program, formatted
     for a Web browser because the 'cgitb' module was enabled.  In case you
     are not reading this in a Web browser, here is the original traceback:

%s
-->
''' % getTraceback((etype, evalue, etb))

def text((etype, evalue, etb), context=5):
    """Return a plain text document describing a given traceback."""
    dict = _errorDict((etype, evalue, etb), context)
    head = "%s\n%s\n%s\n" % (dict['type'], dict['pythonVersion'], dict['date']) + '''
A problem occurred in a Python script.  Here is the sequence of
function calls leading up to the error, in the order they occurred.
'''
    textCode = dict['textCode']
    textException = dict['textException']

    
    return head + textCode + textException + '''

The above is a description of an error in a Python program.  Here is
the original traceback:

%s
''' % getTraceback((etype, evalue, etb))

class customHook(Hook):
    
    def __init__(self, function, params):
        self.function = function
        self.params = params
        if self.params.has_key('context'):
            self.context = self.params['context']
            del self.params['context']
        else:
            self.context = 5
        #Hook.__init__(self, context=context)
        
    def handle(self, info=None):
        
        info = info or sys.exc_info()
        if len(self.params) == 0:
            self.function(errorDict(info, self.context))
        else:
            self.function(errorDict(info, self.context), self.params)
        
    
def handle(customHandler=None, **params):
    if not customHandler:
        import handler
        customHandler = handler.html
    sys.excepthook = customHook(customHandler, params)
