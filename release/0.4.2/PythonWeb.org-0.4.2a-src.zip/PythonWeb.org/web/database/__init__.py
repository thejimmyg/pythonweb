"""web.database -- SQL database layer"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

"""Database module extends DB-2.0 API offering a cross platform database layer compatible with MySQL, ODBC, Gadfly and a sophisticated yet extremely easy to use ORM with automatic HTML generation for forms and tables from the datbase itself.

For more information view the README.txt, USERGUIDE.txt, and DEVELOPERGUIDE.txt files in the module directory or
visit http://lemon.sf.net/docs/ for HTML versions of the same files.

Points to note:

    - Results aren't automatically committed.
    - You can alter the fetch and execute modes.

    - Seconds must be whole seconds.

    - Should be able to call the ColTypes table something else and block the use of the name ColTypes.
    - Important to commit() changes before and after creating/altering/dropping code.
"""

#import drivers

class DBError(Exception):
    """Error Class for the DB Module. Use as follows:

    try:
        raise DBError(ERROR_PASSWORD)
    except SessionError, e:
        print 'DB exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return self.value
        
class DateError(Exception):
    """Error Class for the Date Module. Use as follows:

    try:
        raise DateError(ERROR_PASSWORD)
    except SessionError, e:
        print 'Date exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return self.value
   
def connect(type, database, dir='', startup='', user='', password='', host='', socket='', port=''):
    
    """Connects to the appropriate database and returns a web.database cursor (which is derived from a normal cursor).
    Options available are: type, syntax, user, password, protocol, host, socket, port, database
    
    Specifying no options or setting defaults=True loads the default settings.
    """
    if type == 'mysql':
        if dir:
            raise DBError("The MySQL driver does not take the parameter 'dir'."%dir)
        else:
            from drivers.mysql import mysqlConnection
            return mysqlConnection(database, user, password, host, socket, port)
    elif type == 'sqlite':
        from drivers.SQLite import sqliteConnection
        return sqliteConnection(database)
    elif type == 'odbc':
        if dir:
            raise DBError("The ODBC driver does not take the parameter 'dir'.")
        if startup:
            raise DBError("The ODBC driver does not take the parameter 'startup'.")
        if user:
            raise DBError("The ODBC driver does not take the parameter 'user'.")
        if password:
            raise DBError("The ODBC driver does not take the parameter 'password'.")
        if host:
            raise DBError("The ODBC driver does not take the parameter 'host'.")
        if socket:
            raise DBError("The ODBC driver does not take the parameter 'socket'.")
        if port:
            raise DBError("The ODBC driver does not take the parameter 'port'.")
        else:
            import drivers.odbc
            return drivers.odbc.odbcConnection(database)
    elif type == 'gadfly':
        if user:
            raise DBError("The Gadfly driver does not take the parameter 'user'.")
        if password:
            raise DBError("The Gadfly driver does not take the parameter 'password'.")
        if host:
            raise DBError("The Gadfly driver does not take the parameter 'host'.")
        if socket:
            raise DBError("The Gadfly driver does not take the parameter 'socket'.")
        if port:
            raise DBError("The Gadfly driver does not take the parameter 'port'.")
        else:
            import drivers.gc
            if startup == True:
                return drivers.gc.gadflyStartupConnection(database, dir)
            elif not startup:
                return drivers.gc.gadflyConnection(database, dir)
            else:
                raise DBError("The parameter 'startup' should be True or False, not '%s'."%startup)
    else:
        raise DBError("There is no such database type '%s'."%type)
