"""MySQL driver for the web.database module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import MySQLdb
if not MySQLdb.version_info == (
    0,
    9,
    2,
    "final",
    1):
    raise Exception('The MySQL driver is designed to work with MySQL 0.9.2 and has not been tested on other versions. If you want to give it a go try commenting this line out.')
import base

class mysqlConnection(base.baseConnection):
    def __init__(self, database, user='', password='', host='', socket=None, port=''):
        'Set up the database connection'
        if port:
            port = int(port)
            if socket:
                self.connection = MySQLdb.connect  (  
                    db=database, 
                    user=user, 
                    passwd=password, 
                    host=host, 
                    port=port,
                    unix_socket=socket,
                )
            else:
                self.connection = MySQLdb.connect  (  
                    db=database, 
                    user=user, 
                    passwd=password, 
                    host=host, 
                    port=port,
                )
        else:
            if socket:
                self.connection = MySQLdb.connect  (  
                    db=database, 
                    user=user, 
                    passwd=password, 
                    host=host, 
                    unix_socket=socket,
                )
            else:
                self.connection = MySQLdb.connect  (  
                    db=database, 
                    user=user, 
                    passwd=password, 
                    host=host,
                )
                
    def cursor(self, autoExecute=True, convertMode='description', colTypesName='ColTypes', types={}, debug=False):
        "Return our custom cursor rather than the default connection cursor."
        return mysqlCursor(self.connection.cursor(), autoExecute,  convertMode, colTypesName, types, debug)
        
class mysqlCursor(base.baseCursor):

    def _setupOptions(self):
        return [
                    [True, False],              # autoExecute
                    ['tuple','dict','dtuple'],  # fetchMode
                    [True, False],              # autoConvert
                    ['table', 'description'],   # convertMode
                ]

    #
    # Encoding Functions
    #

    def _setupFields(self):

        self.type = 'mysql'
        self.fields = base.Fields(
            [
                base.CharConverter       ('Char',     "CHAR(1)",        (254,)),
                base.StringConverter     ('String',   "VARCHAR(255)",   (253,)),
                base.TextConverter       ('Text',     "MEDIUMBLOB",     (252,)),
                base.IntegerConverter    ('Integer',  "INT(11)",        (3,5,)),
                base.FloatConverter      ('Float',    "FLOAT",          (4,)),
                base.DateConverter       ('Date',     "DATE",           (10,)),
                base.TimeConverter       ('Time',     "TIME",           (11,)),
                base.DateTimeConverter   ('DateTime', "DATETIME",       (12,)),
            ]
        )

    def alter(self, table, mode, name, type=None, autoExecute=None):
        columnName = name
        if mode.upper() == 'ADD':
            columnType = self.fields[type].codes[0]
        
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
            
        if table == self._colTypesName:
            raise DatabaseError("You cannot alter the '"+self._colTypesName+"' table using this method. It is a reserved table name.")
    
        if mode not in ['add','drop']:
            raise DatabaseError("The 'mode' attribute can only be 'add' or 'drop'.")
    
        if mode == 'add':
            if not columnType:
                raise DatabaseError("You must specify a columnType.")
                
            
            if not self._typesCache.has_key(table.upper()):
                self._typesCache[table.upper()] = {}
            self._typesCache[table.upper()][columnName.upper()] = columnType
            if self._autoConvert == True and self._convertMode == 'table':
                if type(columnType) in [type([]), type((1,))]:
                    d = columnType[0]
                else:
                    d = columnType
                self._addColumnType(table, columnName, d)
            
            sql = "ALTER TABLE %s ADD %s %s" % (table, columnName, self.fields.getByCode(columnType).createSQL)

        else:
            del self._typesCache[table.upper()][columnName.upper()]
            if self._autoConvert == True and self._convertMode == 'table':
                self._removeColumnType(table, columnName)
            sql = "ALTER TABLE %s DROP %s" % (table, columnName)

        if autoExecute == True:
            self.execute(sql)
        return sql
            