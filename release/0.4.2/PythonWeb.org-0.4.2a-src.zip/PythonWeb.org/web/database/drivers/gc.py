"""Gadfly driver for the  web.database module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import base

class gadflyConnection(base.baseConnection):
    "Gadfly conncetion object."
    
    def __init__(self, database, dir):
        'Set up the database connection'
        import os
        import gadfly
        try:
            self.connection = gadfly.gadfly(database, os.path.abspath(dir.replace('/',os.sep)))
        except ImportError:
            raise Exception("The Gadfly module could not be imported. Gadfly requires that the directory in which it resides be included first in sys.path even if the module can be found. Importing the web module sets this up automatically.")

    def cursor(self, autoExecute=True, convertMode='table', colTypesName='ColTypes', types={}, debug=False):
        "Return our custom cursor rather than the default connection cursor."
        return gadflyCursor(self.connection.cursor(), autoExecute, convertMode, colTypesName, types, debug)

class gadflyStartupConnection(gadflyConnection):
    "Special Gadlfy mode for setting up a database."
    def __init__(self, database, dir):
        'Set up the database connection'
        import os, os.path, gadfly
        try:
            self.connection = gadfly.gadfly()
        except ImportError:
            raise Exception("The Gadfly module could not be imported. Gadfly requires that the directory in which it resides be included in sys.path. Importing the web module sets this up automatically.")

        self.connection.startup(database, os.path.abspath(dir))
        cursor = self.cursor()
        if not cursor.tableExists('ColTypes'): # XXX
            cursor._createColTypesTable()
        self.connection.commit()

class gadflyCursor(base.baseCursor):
    
    def _setupOptions(self):
        return [
                    [True, False],              # autoExecute
                    ['tuple','dict','dtuple'],  # fetchMode
                    [True, False],              # autoConvert
                    ['table'],                  # convertMode
                ]

    def _setupFields(self):
        """For this to work the definitions must be tuples containing just one integer, otherwise the integer field
        causes problems when adding a column definition"""
        self.type = 'gadfly'
        self.fields = base.Fields(
            [
                base.CharConverter       ('Char',     "varchar",    (1,)),
                base.StringConverter     ('String',   "varchar",    (2,)),
                base.TextConverter       ('Text',     "varchar",    (3,)),
                base.IntegerConverter    ('Integer',  "integer",    (4,)),
                base.FloatConverter      ('Float',    "float",      (5,)),
                base.DateConverter       ('Date',     "varchar",    (6,)),
                base.TimeConverter       ('Time',     "varchar",    (7,)),
                base.DateTimeConverter   ('DateTime', "varchar",    (8,)),
            ]
        )

    #~ def alter(self, conn, table, mode, columnName, columnType=None, default=None):
        #~ """
        #~ Note: The code has been re-written and seems to work well so the info below may not be relevant.
              #~ Also no commits are used.

        #~ Manually performs a table alteration in Gadfly.
        
        #~ WARNING: The function is not robust and may fail, make sure you read the docstring for the Gadfly ALTER()
                 #~ command and that you make a proper backup as described in the docstring for this module.
                 
        #~ NOTE:    This function has a different syntax to ALTER(). This is because Gadfly doesn't suppot NULLs so you
                 #~ must specify a default value of the correct type for the column.
                 
        #~ ALTER() does not have the same effect in the Gadfly cursor as in other cursors.
        
        #~ Differences:
            #~ 1. Gadfly doesn't support ALTER.
                    #~ This means that the implementation has been done manually by reading all the results
                    #~ from the table, deleting the table, creating a new table and putting all the results
                    #~ back in. This is not reliable. several self.commit() calls are made which menas 
                    #~ transactions could behave strangely. Also gadfly tends to like being disconnected from and
                    #~ reconnected to before any further calls are made.
                    
        #~ If you really need to alter a gadfly table, make a backup and then connect to Gadfly in the 
        #~ way you would if you were creating a table for the first time (as described in the gadfly documentation)
        #~ then perform the alter, commit, and disconnect. The table should have been altered successfully.
        #~ """
        #~ # Find a free temporary table name
        #~ counter = 0
        #~ found = True
        #~ while found == True:
            #~ if counter == 10:
                #~ raise Exception("Problem with Gadfly Cursor... 10 temporary tables used in the table ALTER command already exist. This probably means the ALTER function isn't correctly deleting tables. You can comment out this line as a temporary fix and the database will just get full of un-needed tables or try to fix the faulty code.")
            #~ found = self.tableExists('temp_'+table+str(counter))
            #~ counter += 1
        #~ tempTableName = 'temp_'+table+str(counter)
        
        #~ if mode == 'add':
            #~ if not columnType:
                #~ raise Exception("You must specify a columnType.")
            
            #~ if default == None:
                #~ raise Exception("With Gadfly connections You must specify a default value to the ALTER command when adding columns since the database doesn't support NULLs.")
                
            #~ # Get the field names and values
            #~ fields = []
            #~ fieldNames = []
            
            #~ # Do all this manually.
            #~ self.execute("select ColumnName, ColumnType from "+self._colTypesName+" where TableName='"+table+"'")
            #~ rows = self.baseCursor.fetchall()
            #~ for r in rows:
                #~ fields.append((r[0], (r[1],)))                      # name, tuple of the type.
                #~ fieldNames.append(r[0])
                
            #~ # Get current fields
            #~ sql = 'SELECT '+ ', '.join(fieldNames) +' FROM '+ table
            #~ self.execute(sql)
            #~ current = self.baseCursor.fetchall()
        
            #~ # Add the new column to the fields definition
            #~ fields.append((columnName, columnType))   # Adding notNULL = None, default
            
            #~ # Add the new column to the fieldNames list
            #~ fieldNames.append(columnName)

            #~ # Add the default value to each of the rows in the current table.
            #~ newValues = []
            #~ for row in current:
                #~ newRow = list(row)
                #~ newRow.append(default)
                #~ newValues.append(tuple(newRow))
            #~ newValues = tuple(newValues)
            
            #~ self.drop(table)
            #~ conn.commit()
            #~ self.create(table, fields)
            #~ conn.commit()
            
            #~ string_ = ''
            #~ for i in newValues[0]:
                #~ string_ += ', ?'
            #~ sql = 'INSERT INTO '+table+' ('+', '.join(fieldNames)+') VALUES ('+string_[2:]+')'

            #~ for values in newValues:
                #~ self.execute(sql,values)
            #~ conn.commit()
            
        #~ elif mode == 'drop':

            #~ # Get the field names and values
            #~ # Do all this manually.
            #~ fieldNames = []
            #~ fieldTypes = []
            #~ self.execute("select ColumnName, ColumnType from "+self._colTypesName+" where TableName='"+table+"'")
            #~ rows = self.baseCursor.fetchall()
            #~ for r in rows:
                #~ fieldNames.append(r[0])
                #~ fieldTypes.append(r[1])

            #~ # Get current fields
            #~ sql = 'SELECT '+ ', '.join(fieldNames) +' FROM '+ table
            #~ self.execute(sql)
            #~ current = self.baseCursor.fetchall()
            
            
            #~ # Do all this manually.
            #~ fields = []
            #~ newFieldNames = []
            
            #~ counter = index = 0
            #~ for r in range(len(fieldNames)):
                #~ if fieldNames[r] == columnName:
                    #~ index = counter
                #~ else:
                    #~ fields.append((fieldNames[r], (fieldTypes[r],)))
                    #~ newFieldNames.append(fieldNames[r])                    # name, tuple of the type.
                #~ counter += 1

            #~ newValues = []
            #~ for row in current:
                #~ newRow = list(row)
                #~ newRow.pop(index)
                #~ newValues.append(tuple(newRow))
            #~ newValues = tuple(newValues)

            #~ #print newFieldNames
            #~ #print newValues
            
            #~ self.drop(table)
            #~ conn.commit()
            #~ self.create(table, fields)
            #~ conn.commit()
            
            #~ string_ = ''
            #~ for i in newValues[0]:
                #~ string_ += ', ?'
            #~ sql = 'INSERT INTO '+table+' ('+', '.join(newFieldNames)+') VALUES ('+string_[2:]+')'
            #~ for values in newValues:
                #~ self.execute(sql,values)
            #~ conn.commit()
        #~ else:
            #~ raise Exception("The 'mode' attribute can only be 'add' or 'drop'.")
            
    #~ def create(self, table, fields, autoExecute=None):
        #~ for field in fields:
            #~ if type(field) in [type([]), type(())]:
                #~ if len(field) >2:
                    #~ raise Exception("Gadfly doesn't support these table options.")
        #~ return self._create(table, fields, autoExecute)
        
    #def function(self, func, field, table, where=None):
    #    """Warning: Please note.. no conversion is done here."""
    #    raise Exception("Gadfly doesn't support functions")
        #~ if func.upper() in ['MAX', 'MIN', 'SUM', 'AVG']:
            #~ self.table = table
            #~ self.fields = field
            #~ #result = "SELECT %s(%s) AS %s FROM %s" % (func, field, field, table)
            #~ result = "SELECT * FROM %s" % (table)
            #~ if where:
                #~ result += " WHERE %s" % where
            #~ self.execute(result)
            #~ if self.baseCursor.fetchall():
                #~ result = "SELECT %s(%s) FROM %s" % (func, field, table)
                #~ if where:
                    #~ result += " WHERE %s" % where
                    
                #~ if self._autoExecute is True:
                    #~ self.execute(result)
                    #~ val = self.baseCursor.fetchall()[0][0]
                    #~ return val
                #~ else:
                    #~ return result
            #~ else:
                #~ return None
        #~ else:
            #~ raise Exception("The function '%s' is not supported by the database module."%func)
            