"Basic Field Classes"

class Field:
    """Abstract base class from which other fields are derived. Shouldn't be treated as a real field"""
    def __init__(self, name, default, description="", error="", required=False, requiredError='Please enter a value'):
       

        self.__dict__['_name'] = name
        self.__dict__['htmlName'] = name
        
        #~ list = []
        #~ if type(default) == type([]) or type(default) == type(()):
            #~ for item in default:
                #~ if item:
                    #~ list.append(str(item))
                #~ else:
                    #~ list.append('')
        #~ else:
            #~ list = str(default)
        self.__dict__['default'] = default # XXX list
        self.__dict__['requiredError'] = requiredError
        self.__dict__['value'] = default
        self.__dict__['_description'] = description
        self.__dict__['_error'] = error
        self.__dict__['_type'] = self.__class__.__name__
        self.__dict__['required'] = required
        
    def populate(self, values):
        "Populates the field from a dictionary of cgi variables."

        if form.has_key(self.htmlName):
            self.set(form[self.htmlName].value)
        else:
            self.set('')
        
    def set(self, value):
        "Sets the value of the field manually."
        self.value = value
        
    def valid(self, value=None):
        if value == None:
            value = self.value
        if self.required:
            if not value:
                self.setError(self.requiredError)
                return False
        return True
        
    def html(self):
        "Should be overridden."
        raise Exception('The html() function should have been overridden in the derived class.') 
        
    def frozen(self):
        "Should be overridden."
        raise Exception('The frozen() function should have been overridden in the derived class.') 

    def hidden(self):
        "Should be overridden."
        raise Exception('The hidden() function should have been overridden in the derived class.') 
        
    #~ def builderValue(self):
        #~ """Perform any final changes on the finished value then return."""
        #~ return self.value

    def get(self):
        return self.value
        
    def type(self):  # Unneccessary
        return self._type
        
    def error(self):
        return str(self._error)
        
    def setError(self, value):
        self._error = value
        
    def description(self):
        return self._description
    
    def __getattr__(self, name):
        if name == 'value':
            return self.value
        else:
            raise AttributeError("Object does not have a '%s' attribute."%(name))
        
    def __str__(self):
        return self.__repr__()
        
    def __repr__(self):
        return '<%s Class. Name=\'%s\'>'%(self.__class__.__name__, self.htmlName)
        
    def name(self):
        return self._name
    #def isValid(self):
    #    return self.valid(self.value)
        
class Input(Field):
    """Text Input Field."""
    def __init__(self, name, default='', description='', error='', size=40, maxlength=None, required=False, requiredError='Please enter a value'):
        """Initialisation code"""
        Field.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['size'] = size
        self.__dict__['maxlength'] = maxlength

    def populate(self, form):
        if form.has_key(self.htmlName):
            if type(form[self.htmlName]) == type([]):# and len(form[self.htmlName])>1:
                raise KeyError("More than one field named %s has been submitted" % (self.htmlName))
            else:
                value = form[self.htmlName].value
                if value:
                    self.set(str(value))
                else:
                    self.set('')
        else:
            self.set('')
        
    def html(self):
        output = ""
        if self.type() == "Password":
            inputType='password'
        elif self.type() == "File":
            inputType='file'
        elif self.type() == "Price":
            output += self.currency + " "
            inputType='text'
        else: 
            inputType='text'
            
        output+='<input type="%s" name="%s"'% (inputType, self.htmlName)
        if type(self.size) <> type(None):
            output+=' size="%s"'% self.size
        if type(self.maxlength) <> type(None):
            output+=' maxlength="%s"'% self.maxlength
        output+=' value="%s">'% self.value
        return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s">'% (self.htmlName, self.value)

    def frozen(self):
        return self.value
        
    def set(self, value, dataType=None):
        "Sets the value of the field manually."
        if self.maxlength:
            Field.set(self, value[:self.maxlength])
        else:
            Field.set(self, value)
        
    def valid(self, value=None):
        if value == None:
            value = self.value
        if self.required:
            if not value:
                self.setError(self.requiredError)
                return False
        if self.maxlength:
            if len(value)>self.maxlength:
                self.setError("Text must be less then %s characters"%self.maxlength)
                return False
        return True

    def get(self):
        if self.maxlength:
            return self.value[:self.maxlength]
        else:
            return self.value
        
class File(Input):
    """File Input Field."""
    pass
    
class Password(Input):
    """Password Field."""
    pass
    
   
class Hidden(Field):
    """Hidden Field"""
   
   
    def populate(self, form):
        raise Exception("You cannot populate %s fields."%self.type())
        
    def __init__(self, name, default='', description='', error='', required=False, requiredError='Please enter a value'):
        "Initialisation code"
        Field.__init__(self, name, default, description, error, required, requiredError)
        
    def html(self):
        if self.type() == "CheckBox":
            checked=''
            if self.value == 'on':
                checked=' checked' 
            output='<input type="checkbox" name="%s"%s>'%(self.htmlName,checked)
            return output
        else:
            if self.type() == "Button":
                inputType='button'
            elif self.type() == "Submit":
                inputType='submit'
            elif self.type() == "Reset":
                inputType='reset'
            else: 
                inputType='hidden'
                
            output='<input type="%s" name="%s"'% (inputType, self.htmlName)
            output+=' value="%s">'% self.value
            return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s">'% (self.htmlName, self.value)

    def frozen(self):
        return self.value
        
  
class CheckBox(Hidden): 
    """CheckBox Field."""
    def frozen(self):
        if self.value == 'on':
            return "True"
        else:
            return "False"

    def populate(self, form):
        if form.has_key(self.htmlName):
            
            if type(form[self.htmlName]) == type([]):# and len(form[self.htmlName])>1:
                raise KeyError("More than one field named %s has been submitted" % (self.htmlName))
            else:
                value = form[self.htmlName].value
                if (value <> '') or (overWrite == True):
                    if value:
                        self.set(str(value))
                    else:
                        self.set('')
                else:
                    self.set('')
        else:
            self.set('')
                        
    def valid(self, value=None):
        if value == None:
            value = self.value
        if value in ['on','']:
            return True
        self.setError('Please leave the box checked or unchecked.')
        return False
        
class Button(Hidden):
    """Custom Button."""
    pass

class Submit(Hidden):
    """Submit Button."""
    pass

class Reset(Hidden):
    """Reset Button."""
    pass
    
class TextArea(Field):
    """TextArea Field."""
    
    def __init__(self, name, default='', description='', error='', cols=None, rows=None, required=False, requiredError='Please enter some text'):
        """Initialisation code"""
        Field.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['cols'] = cols
        self.__dict__['rows'] = rows

    def populate(self, form):
        if form.has_key(self.htmlName):
            
            if type(form[self.htmlName]) == type([]):# and len(form[self.htmlName])>1:
                raise KeyError("More than one field named %s has been submitted" % (self.htmlName))
            else:
                value = form[self.htmlName].value
                if value:
                    self.set(str(value).replace('\r\n','\n'))
                else:
                    self.set('')
        else:
            self.set('')
                        
    def html(self):
        output='<textarea name="%s"'% (self.htmlName)
        if type(self.cols) <> type(None):
            output+=' cols="%s"'% self.cols
        if type(self.rows) <> type(None):
            output+=' rows="%s"'% self.rows
        output+='>%s</textarea>'% self.value
        return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s">'% (self.htmlName, self.value)

    def frozen(self):
        return self.value.replace('\n','<br>')

class Select(Field):
    """Select Field."""
    def __init__(self, name,  options, default='', description='', error='', required=False, requiredError='Please choose an option'):
        """Initialisation code"""
        Field.__init__(self, name, default, description, error, required, requiredError)
        pairs = []
        for pair in options:
            k,v = pair
            pairs.append((str(k), str(v)))
        
        self.__dict__['options'] = pairs
        if type(default) not in [type(''), type(1), type(1L)]:
            raise Exception('Select fields can only take integer or string values as a default.')
        #self.__dict__['size'] = size
                
    # XXX Maybe override the set method to ensure the value is properly set
    # XXX Rewrite the . access attribute methods.
    
    def populate(self, form):
        if form.has_key(self.htmlName):
            
            if type(form[self.htmlName]) == type([]):
                raise TypeError("Multiple values recieved for '%s' when it is set as a single field."%self.htmlName)
            else:
                value = form[self.htmlName].value
                if value:
                    self.set(str(value))
                else:
                    self.set('')
        else:
            self.set('')
                            
    def valid(self, value=None):
        if value == None:
            value = self.value
        if value == None:
            self.setError("None is not a valid value. This a bug in the software.")
            return False
        elif not value:
            if self.required:
                self.setError(self.requiredError)
                return False
            else:
                return True
        else:
            for option in self.__dict__['options']:
                if str(option[0]) == value:
                    return True
            self.setError("'%s' wasn't one of the options."%value)
            return False

        
        
    def html(self):
    
        output='<select name="%s">\n'%(self.htmlName)

        if len(self.options) > 0:
            for items in self.options:
                selected=''
                k=items[1]
                v=items[0]
                if (type(self.value) == type(())) or (type(self.value) == type([])):
                    if v in self.value:
                        selected=" selected"
                else:
                    if v == self.value:
                        selected=" selected"
                output+='  <option value="%s"%s>%s</option>\n'%(v,selected,k)   

        output+='</select>'
        return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s">'% (self.htmlName, self.value)

    def frozen(self):
        if type(self.value) == type([]):
            results = []
            for option in self.options:
                if str(option[0]) in self.value:
                    results.append(str(option[1]))
            return ", ".join(results)
        else:
            for option in self.options:
                if str(option[0]) == str(self.value):
                    return str(option[1])
        return self.value # XXX was return 'XXX Error' but doesn't work with float rounding errors.
            
class Menu(Field):
    """Select Field."""
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please choose at least one option', size=None):
        """Initialisation code"""
        Field.__init__(self, name, default, description, error, required, requiredError)
        pairs = []
        for pair in options:
            k,v = pair
            pairs.append((str(k), str(v)))
        
        self.__dict__['options'] = pairs
        self.__dict__['size'] = size
                
    # XXX Maybe override the set method to ensure the value is properly set
    # XXX Rewrite the . access attribute methods.
    
    def populate(self, form):
        if form.has_key(self.htmlName):
            value = form[self.htmlName]
            if type(value) == type([]):
                list = []
                for v in value:
                    list.append(str(v.value))
                self.set(list)
            else:
                if value:
                    self.set([str(value.value)])
                else:
                    self.set([])
        else:
            self.set([])
        
    def valid(self, value=None):
        if value == None:
            value = self.value
        if len(value) > 0:
            matched = 0
            for val in value:
                for option in self.__dict__['options']:
                    if option[0] == val:
                        matched += 1
            if matched == len(self.value):
                return True
            else:
                self.setError("One of the options selected is not valid.")
                return False
        elif self.required:
            self.setError(self.requiredError)
            return False
        else:
            return True
        
    def html(self):
        multiple = ' multiple'
        size=' size="%s"'%(self.size)
        output='<select name="%s"%s%s>\n'%(self.htmlName, size, multiple)
        if self.options > 0:
            for items in self.options:
                selected=''
                k=items[1]
                v=items[0]
                if (type(self.value) == type(())) or (type(self.value) == type([])):
                    if v in self.value:
                        selected=" selected"
                else:
                    if v == self.value:
                        selected=" selected"
                output+='  <option value="%s"%s>%s</option>\n'%(v,selected,k)   
        output+='</select>'
        return output

    def hidden(self):
        output = ''
        for value in self.value:
            output += '<input type="hidden" name="%s" value="%s">'% (self.htmlName, value)
        return output 

    def frozen(self):
        if type(self.value) == type([]):
            results = []
            for option in self.options:
                if str(option[0]) in self.value:
                    results.append(str(option[1]))
            return ", ".join(results)
        else:
            for option in self.options:
                if str(option[0]) == str(self.value):
                    return str(option[1])
        return self.value # XXX was return 'XXX Error' but doesn't work with float rounding errors.
            
            
class RadioGroup(Select):
    """Radio Group Field."""
    
    def __init__(self, name, options, default='', description='', error='', required=False, requiredError='Please choose an option', align='horiz', cols=4):
        """Initialisation code"""
        Select.__init__(self, name, options, default, description, error, required, requiredError)
        self.__dict__['align'] = align
        self.__dict__['cols'] = cols

    def populate(self, form):
        if form.has_key(self.htmlName):
            
            if type(form[self.htmlName]) == type([]):# and len(value)>1:
                raise KeyError("More than one field named %s has been submitted" % (self.htmlName))
            else:
                value = form[self.htmlName].value
                if (value <> '') or  (overWrite == True):
                    if value:
                        self.set(str(value))
                    else:
                        self.set('')
                else:
                    self.set('')


        
        
    def html(self):
        output=''
        if len(self.options)>0:
            if self.align <> 'table':
                for option in self.options:
                    checked=''
                    align=''
                    k=option[1]
                    v=option[0]
                    if str(v)==str(self.value):
                        checked=" checked"
                    if self.align == 'vert':
                        align='<br>'
                    output+='  <input type="radio" name="%s" value="%s"%s>%s%s\n'%(self.htmlName, v, checked, k,align)

            else:
                output += '\n\n    <table border="0" width="100%" cellpadding="0" cellspacing="0">\n    <tr>\n'
                counter = -1
                for option in self.options:
                    counter += 1
                    if ((counter % self.cols) == 0) and (counter <> 0):
                        output += '    </tr>\n    <tr>\n'
                    output += '      <td>'
                    checked=''
                    align=''
                    k=option[1]
                    v=option[0]
                    if v in self.value:
                        checked=" checked"
                    
                    output += '<input type="radio" name="%s" value="%s"%s>%s%s'%(self.htmlName, v, checked, k,align)
                    output += '</td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                    
                counter += 1
                while (counter % self.cols):
                    counter += 1
                    output += '      <td></td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                output += '    </tr>\n    </table>\n\n'
        return output
        
        
class CheckBoxGroup(Menu):
    """Check Box Group Field."""
    def __init__(self, name, options, default=None, description='', error='', required=False, requiredError='Please choose at least one option', align='vert', cols=4):
        """Initialisation code"""
        Menu.__init__(self, name, options, default, description, error, required, requiredError)
        self.__dict__['align'] = align
        self.__dict__['cols'] = cols


    def populate(self, form):
        if form.has_key(self.htmlName):
            value = form[self.htmlName]
            if type(value) == type([]):
                list = []
                for v in value:
                    list.append(str(v.value))
                self.set(list)
            else:
                if value:
                    self.set([str(value.value)])
                else:
                    self.set([])
        else:
            self.set([])


    def valid(self, value=None):
        if value == None:
            value = self.value
        if (type(value) == type(())) or (type(value) == type([])):
            if len(value) == 0:
                if self.required == True:
                    self.setError(self.requiredError)
                    return False
                else:
                    return True
            else:
                # Check results
                for val in value:
                    strOptions = []
                    for option in self.options:
                        strOptions.append(str(option[0]))
                        
                    if str(val) not in strOptions:
                        self.setError("'%s' is not a valid option."%val)
                        return False
                return True
        raise TypeError('Expected a list object.')
        
    def html(self):
        output = ''
        if len(self.options) > 0:
            if self.align <> 'table':
                for option in self.options:
                    checked=''
                    align=''
                    k=option[1]
                    v=option[0]
                    if v in self.value:
                        checked=" checked"
                    if self.align == 'vert':
                        align='<br>'
                    output+='  <input type="checkbox" name="%s" value="%s"%s>%s%s\n'%(self.htmlName, v, checked, k,align)
        
            else:
                output += '\n\n    <table border="0" width="100%" cellpadding="0" cellspacing="0">\n    <tr>\n'
                counter = -1
                for option in self.options:
                    counter += 1
                    if ((counter % self.cols) == 0) and (counter <> 0):
                        output += '    </tr>\n    <tr>\n'
                    output += '      <td>'
                    checked=''
                    align=''
                    k=option[1]
                    v=option[0]
                    if v in self.value:
                        checked=" checked"
                    
                    output += '<input type="checkbox" name="%s" value="%s"%s>%s%s'%(self.htmlName, v, checked, k,align)
                    output += '</td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                    
                counter += 1
                while (counter % self.cols):
                    counter += 1
                    output += '      <td></td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                output += '    </tr>\n    </table>\n\n'
        return output
