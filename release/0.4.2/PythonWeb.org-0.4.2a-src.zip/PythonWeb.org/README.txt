
                         +-------------------------+
                         |                         |
                         |    Python Web Modules   |
                         |                         |
                         +-------------------------+

                          http://www.pythonweb.org
                Technology Preview - Modules Version 0.4.2
                     James Gardner - 18th November 2004


 Installation
 -------------

 To install the modules:

    > python setup.py install

 Other ways to install the modules are in the Getting Started Guide


 Getting Started
 ---------------

 Read the Getting Started Guide:

     doc/html/overview/overview.html

 Full documentation in:

     doc/html/index.html


 Directory Structure
 -------------------

  + doc           Full documentation for the modules
  + scripts       Useful scripts
  + web           The modules themselves
    + external      Software written by 3rd parties

 Licence
 -------

 Full licence and copyright information is in doc/html/licence/index.html
