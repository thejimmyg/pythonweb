#!/usr/bin/env python

import shutil, sys, os, os.path
useage="""Useage: setup.py [option]

Options
 install   Install the modules
 bdist     Create a binary distribution"""

if not len(sys.argv)>1:
    print useage
elif sys.argv[1] == 'install':
    def choosePath(inst):
        while not(os.path.exists(inst) and (not os.path.exists(inst+os.sep+'web'))):
            if not os.path.exists(inst):
                print "There is no such path '%s'."%inst
            else:
                print "There is already a 'web' directory at the location '%s'. Are the modules already installed?"%(inst+os.sep+'web')
                
            if raw_input('Would you like to install the modules somewhere else? [y/n]: ') == 'y':
                inst = raw_input('Please enter a directory into which to install the web modules: ')
            else:
                print "Install aborted."
                raw_input('Press ENTER to exit.')
                sys.exit(1)
        return inst
    
    from distutils import sysconfig
    inst = sysconfig.get_python_lib()
        
    if raw_input("The default install directory is '%s'. Is this OK? [y/n]: "%inst) == 'y':
        inst = choosePath(inst)
    else:
        inst = choosePath(raw_input('Enter install directory: '))
        
    if inst not in sys.path:
        print "The installation directory '%s' is not on your sys.path. This means that if the web modules were to be installed there you would not be able to import them unless you modified your path with code as follows:"%inst
        print "import sys; sys.path.append('%s')\n"%inst
    
    if raw_input('Continue with installation? [y/n]: ') == 'y':
        print "Installing the modules to '%s'..."%(inst+os.sep+'web')
        shutil.copytree('web', inst+os.sep+'web')
        print "Web modules successfully installed."
    else:
        print "Install aborted."
    raw_input('Press ENTER to exit.')
elif sys.argv[1] == 'bdist':

    
    __revision__ = "$Id: setup.py,v 1.17.2.14 2004/11/15 20:00:54 thejimmyg Exp $"
    
    import os
    from distutils.errors import DistutilsExecError
    from distutils.spawn import spawn
    from distutils.dir_util import mkpath
    
    def make_tarball (base_name, base_dir, compress="gzip",
                      verbose=0, dry_run=0):

        compress_ext = { 'gzip': ".gz",
                         'bzip2': '.bz2',
                         'compress': ".Z" }
    
        # flags for compression program, each element of list will be an argument
        compress_flags = {'gzip': ["-f9"],
                          'compress': ["-f"],
                          'bzip2': ['-f9']}
    
        if compress is not None and compress not in compress_ext.keys():
            raise ValueError, \
                  "bad value for 'compress': must be None, 'gzip', or 'compress'"
    
        archive_name = base_name + ".tar"
        mkpath(os.path.dirname(archive_name), verbose=verbose, dry_run=dry_run)
        cmd = ["tar", "-cf", archive_name, base_dir]
        spawn(cmd, verbose=verbose, dry_run=dry_run)
    
        if compress:
            spawn([compress] + compress_flags[compress] + [archive_name],
                  verbose=verbose, dry_run=dry_run)
            return archive_name + compress_ext[compress]
        else:
            return archive_name
    
    def make_zipfile (base_name, base_dir, verbose=0, dry_run=0):
        try:
            import zipfile
        except ImportError:
            raise DistutilsExecError, \
                  ("unable to create zip file '%s': " +
                   "could neither find a standalone zip utility nor " +
                   "import the 'zipfile' module") % zip_filename
        if verbose:
            print "creating '%s' and adding '%s' to it" % \
                  (zip_filename, base_dir)

        def visit (z, dirname, names):
            for name in names:
                path = os.path.normpath(os.path.join(dirname, name))
                if os.path.isfile(path):
                    z.write(path, path)

        if not dry_run:
            z = zipfile.ZipFile(zip_filename, "w",
                                compression=zipfile.ZIP_DEFLATED)

            os.path.walk(base_dir, visit, z)
            z.close()
    
        return zip_filename
    
    ARCHIVE_FORMATS = {
        'gztar': (make_tarball, [('compress', 'gzip')], "gzip'ed tar-file"),
        'bztar': (make_tarball, [('compress', 'bzip2')], "bzip2'ed tar-file"),
        'ztar':  (make_tarball, [('compress', 'compress')], "compressed tar file"),
        'tar':   (make_tarball, [('compress', None)], "uncompressed tar file"),
        'zip':   (make_zipfile, [],"ZIP file")
        }
    
    def check_archive_formats (formats):
        for format in formats:
            if not ARCHIVE_FORMATS.has_key(format):
                return format
        else:
            return None
    
    def make_archive (base_name, format,
                      root_dir=None, base_dir=None,
                      verbose=0, dry_run=0):
        """Create an archive file (eg. zip or tar).  'base_name' is the name
        of the file to create, minus any format-specific extension; 'format'
        is the archive format: one of "zip", "tar", "ztar", or "gztar".
        'root_dir' is a directory that will be the root directory of the
        archive; ie. we typically chdir into 'root_dir' before creating the
        archive.  'base_dir' is the directory where we start archiving from;
        ie. 'base_dir' will be the common prefix of all files and
        directories in the archive.  'root_dir' and 'base_dir' both default
        to the current directory.  Returns the name of the archive file.
        """
        save_cwd = os.getcwd()
        if root_dir is not None:
            if verbose:
                print "changing into '%s'" % root_dir
            base_name = os.path.abspath(base_name)
            if not dry_run:
                os.chdir(root_dir)
    
        if base_dir is None:
            base_dir = os.curdir
    
        kwargs = { 'verbose': verbose,
                   'dry_run': dry_run }
    
        try:
            format_info = ARCHIVE_FORMATS[format]
        except KeyError:
            raise ValueError, "unknown archive format '%s'" % format
    
        func = format_info[0]
        for (arg,val) in format_info[1]:
            kwargs[arg] = val
        filename = apply(func, (base_name, base_dir), kwargs)
    
        if root_dir is not None:
            if verbose:
                print "changing back to '%s'" % save_cwd
            os.chdir(save_cwd)
    
        return filename
        
    def copytree(src, dst, symlinks=0):
        
        excludeAllDirs = ['CVS']
        excludeDirs = [
            'html',
            'dist',
            'toSort', 
            'website',
            'doc/src/commontex',
            'doc/0.4.0',
            'doc/src/dev',
            'doc/src/html',
            'doc/src/info',
            'doc/src/inst',
            'doc/src/licence',
            'doc/src/overview',
            'doc/src/paper-a4',
            'doc/src/paper-letter',
            'doc/src/perl',
            'doc/src/templates',
            'doc/src/texinputs',
            'doc/src/tools',
            'doc/src/web',
            'doc/src/whatsnew',
        ]
        excludeFiles = [
            'doc/src/ACKS',
            'doc/src/libunittest.tex',
            'doc/src/Makefile',
            'doc/src/Makefile.deps',
            'doc/src/README.txt',
            'doc/src/lib/pie.jpg',
            'doc/src/lib/scatter.ps',
            'doc/src/lib/bar.png',
            'doc/src/lib/file-web-xml.html',
            'Build.bat',
            'BUGS.txt',
            'zip.py',
            'TODO.txt',
        ]

        binaries = [
            'win32-2_2',
            'win32-2_3',
        ]
        binaries.remove(str(sys.platform+'-'+sys.version[:3].replace('.','_')))
        #print binaries
        names = os.listdir(src)
        
        if os.path.normpath(dst).replace(os.sep,'/') not in excludeDirs:
            #print "Not Excluded: %s"%srcname
            if dst not in excludeAllDirs:
                #print "Not All Excluded: %s"%os.path.split(srcname)[1]
                os.mkdir(dst)
            else:
                pass#print "Skipping %s"%srcname
        else:
            pass#print "Skipping %s"%srcname
                        
                        
        for name in names:
            srcname = os.path.normpath(os.path.join(src, name)).replace(os.sep,'/')
            dstname = os.path.normpath(os.path.join(dst, name)).replace(os.sep,'/')
            try:
                if symlinks and os.path.islink(srcname):
                    linkto = os.readlink(srcname)
                    os.symlink(linkto, dstname)
                elif os.path.isdir(srcname):
                    #print "Directory: %s"%srcname
                    if srcname not in excludeDirs:
                        #print "Not Excluded: %s"%srcname
                        if os.path.split(srcname)[1] not in excludeAllDirs:
                            #print "Not All Excluded: %s"%os.path.split(srcname)[1]
                            if os.path.split(srcname)[1] not in binaries:
                                #print "Not All Excluded: %s"%os.path.split(srcname)[1]
                                copytree(srcname, dstname, symlinks)
                            else:
                                pass#print "Skipping %s"%srcname
                        else:
                            pass#print "Skipping %s"%srcname
                    else:
                        pass#print "Skipping %s"%srcname
                elif srcname in excludeFiles:
                    pass#print "Skipping %s"%dstname
                elif srcname[-4:] in ['.dat','.pyc','.tex']:
                    pass#print "Skipping %s"%dstname
                elif srcname[-3:] in ['.pl','.in','.db']:
                    pass#print "Skipping %s"%dstname
                else:
                    print "Copying %s"%srcname
                    shutil.copy2(srcname, dstname)
                
                    
            except (IOError, os.error), why:
                print "Can't copy %s to %s: %s" % (`srcname`, `dstname`, str(why))

                        
                        
    import web, sys
    version = '%s-%s-%s'%(web.name,web.version,str(sys.platform+'-'+sys.version[:3]))
    
    print "Building a new binary distribution..."
    if os.path.exists('build'):
        print "Removing old builds..."
        shutil.rmtree('build')
    print "Copying directories..."
    os.mkdir('build')
    #os.mkdir('build/PythonWeb.org')
    copytree('./','build/PythonWeb.org')
    
    zip_filename = '../dist/'+version+'.zip'
    if not os.path.exists('dist'):
        print "Creating dist directory..."
        os.mkdir('dist')
    if os.path.exists(zip_filename):
        print "Removing old version..."
        os.remove(zip_filename)
        
    os.chdir('build')
    make_archive(version, 'zip', root_dir=None, base_dir='PythonWeb.org',verbose=0, dry_run=0)
    print "\nPythonWeb.org distribution created successfully."
    
else:
    print useage


