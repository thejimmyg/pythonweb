#!/usr/bin/env python

"""
PythonWeb.org WSGI Server 
   based on wsgiServer
"""

version = '1.0'

import sys; sys.path.append('../')
import web
    
def pathMap():
    sys.path.append('../doc/src/lib')
    import wsgiAuth, wsgiError, wsgiSession, wsgiSimple, wsgiDebug
    return {
        '/auth'    : wsgiAuth.application,
        '/error'   : wsgiError.application,
        '/session' : wsgiSession.application,
        '/simple'  : wsgiSimple.application,
        '/debug'   : wsgiDebug.application,
    }
    
if __name__ == '__main__':
    from optparse import OptionParser, OptionGroup
    useage = "usage: %prog [options] database"
    parser = OptionParser(usage=useage, version="%%prog %s"%(version))
    parser.add_option("-l", "--launch",
        action="store_true", dest="launch", default=False,
        help="launch a web browser when started",
    )
    parser.add_option("-p", "--port",
        action="store", dest="port", default=8000,
        help="port on which to start the server", type="int",
    )
    (options, args) = parser.parse_args()
    print __doc__
    import wsgiServer
    class myServer(wsgiServer.WSGIServer):
        def handle_error(self, request, client_address):
            """Handle an error gracefully.  May be overridden.
    
            The default is to print a traceback and continue.
    
            """
            import web.error, sys
            error = sys.exc_info()
            if error[0] ==web.error.Breakpoint:
                print '-'*40
                print 'Handling breakpoint\n',
                import pdb
                class Debug(pdb.Pdb):
                    def __init__(self):
                        pdb.Pdb.__init__(self)
                        self.prompt = 'debug> '
                    def do_quit(self, arg):
                        self.set_quit()
                        return 1
                t = error[2]
                p = Debug()
                p.reset()
                while t.tb_next is not None:
                    t = t.tb_next
                p.interaction(t.tb_frame, t)
                print '-'*40
                print "Returned to server mode\n"
            else:
                print '-'*40
                print 'Exception happened during processing of request from',
                print client_address
                import traceback
                traceback.print_exc() # XXX But this goes to stderr!
                print '-'*40
    
    server = myServer(('localhost', options.port), pathMap())
    
    while 1:
            print "Serving HTTP on %s port %s ..." % server.socket.getsockname()[0:2]
            sys.stdout.flush()
            server.handle_request()
    #server.serve_forever()
