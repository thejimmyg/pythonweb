"""Typed Field Classes

# XXX Possible issues:
 - Custom date formats on non-windows platforms
 - Dates use strptime. Buggy and not available on Windows.
 - setError on populate for invalid fields.
 - Auto set the size and maxlength for date fields.
"""



# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)
    
import time, datetime, sys, os
import basic

###########################################################################
#
# Typed Field Classes
#

class TypedField(basic.Field):
    """TypedField Same as a Field except that no conversion to strings is done. Used as the base class for typed fields."""

    def __init__(self, name, default, description="", error="", required=False, requiredError='Please enter a value'):
        if default == '':
            raise Exception('Default cannot be a NULL string.')
        if not requiredError:
            raise Exception('You must specify a requiredError as a string with at least one character.')
        self.__dict__['_name'] = name
        self.__dict__['htmlName'] = name
        self.__dict__['default'] = default
        self.__dict__['requiredError'] = requiredError
        self.__dict__['value'] = default
        self.__dict__['_description'] = description
        self.__dict__['_error'] = error
        self.__dict__['_type'] = self.__class__.__name__
        self.__dict__['required'] = required
        
        if not self.__dict__['_description']:
            self.__dict__['_description'] = self.__dict__['_name'].capitalize()
        
    def set(self, value, strict=False):
        if value == '':
            raise Exception('Value %s cannot be a NULL string.'%value)
        error = self.invalid(value)
        if error:
            if strict:
                raise Exception(error)
            else:
                self.setError(error)
        basic.Field.set(self, value)

class String(TypedField):
    "String Field for strings of 255 characters or less."
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=40, treatNullStringAsNone=True):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['size'] = size
        self.__dict__['maxlength'] = 255
        self.__dict__['treatNullStringAsNone'] = treatNullStringAsNone
        error = self.invalid(default)
        if error:
            raise Exception(error)

    def str2value(self, value):
        if value == '' and self.treatNullStringAsNone:
            return None
        else:
            return str(value)
        
    def value2str(self, value):    
        if value == None :
            return ''
        else:
            return str(value)
        
    def set(self, value, strict=False):
        error = self.invalid(value)
        if error:
            if strict:
                raise Exception(error)
            else:
                self.setError(error)
        basic.Field.set(self, value)

    def valid(self, value={'dummy':''}):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.required:
            if value == '' or value == None:
                self.setError(self.requiredError)
                return False
        error = self.invalid(value)
        if not error:
            return True
        else:
            self.setError(error)
            return False
            
    def invalid(self, value):
        if value == None:
            return False
        elif type(value) <> type(''):
            return "Invalid value. Values should be strings or None. Null stings '' are not allowed. Use None instead."
        elif self.maxlength:
            if len(value)>self.maxlength:
                return "Text must be less then %s characters"%self.maxlength
        return False

    def populate(self, form):
        if form.has_key(self.htmlName):
            if type(form[self.htmlName]) == type([]) and len(form[self.htmlName])>1:
                raise KeyError("More than one field named %s has been submitted" % (self.htmlName))
            else:
                value = form[self.htmlName].value
                #if value:
                v = self.str2value(value)
                self.set(v)
                #else:
                    #self.set(None)
        else:
            self.set(None)
            #self.setError("Programming Error: This field was not submitted.") # XXX could remove?

    def html(self):
        output='<input type="text" name="%s"'% ( self.htmlName)
        if type(self.size) <> type(None):
            output+=' size="%s"'% self.size
        if type(self.maxlength) <> type(None):
            output+=' maxlength="%s"'% self.maxlength
        output+=' value="%s" />'% self.value2str(self.value)
        return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s" />'% (self.htmlName, self.value2str(self.value))

    def frozen(self):
        return self.value2str(self.value)

class StringSelect(TypedField):
    """StringSelect Field. Differs from a normal Select field in that it only takes the strings as the options.
    The values are assigned by the program."""
        
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', displayNoneAs=''):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['maxlength'] = 255
        self.__dict__['options'] = options
        self.__dict__['displayNoneAs'] = displayNoneAs
        
        for option in options:
            error = self.invalid(option)
            if error:
                raise Exception(error)
        if default <> [] and default not in options: # XXX not too sure this is really what we want.
            raise Exception('The default option must be a one of the options.')

    def populate(self, form):
        if form.has_key(self.htmlName):
            value = form[self.htmlName].value
            if value:
                try:
                    self.set(self.options[int(value)])
                except:
                    self.setError('Invalid option selected.')
                    self.set(None)
            else:
                self.set(None)
        else:
            self.set(None)
            #self.setError("Programming Error: This field was not submitted.") # XXX could remove?

    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        if self.maxlength:
            if len(value)>self.maxlength:
                return "Text must be less then %s characters"%self.maxlength
        return False
            
    def valid(self, value={'dummy':''}):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.required:
            if value == '':
                self.setError(self.requiredError)
                return False
        
        if value in self.options:
            return True
        else:
            self.setError("'%s' wasn't one of the options."%value)
            return False

    def html(self):
        output='<select name="%s">\n'%(self.htmlName)
        if len(self.options) > 0:
            counter = 0
            for value in self.options:
                selected=''
                if self.value == value:
                    selected=" selected"
                if value == None:
                    output+='  <option value="%s"%s>%s</option>\n'%(counter,selected,self.displayNoneAs)   
                else:
                    output+='  <option value="%s"%s>%s</option>\n'%(counter,selected,value)   
                counter += 1
        output+='</select>'
        return output

    def hidden(self):
        return '<input type="hidden" name="%s" value="%s" />'% (self.htmlName, self.value)
        
    def frozen(self):
        if self.value == None:
            return ''
        else:
            return str(self.value)
        
class StringCheckBoxGroup(StringSelect):
    "StringCheckBoxGroup Field."
    def __init__(self, name, options, default=[], description='', error='', required=False, requiredError='Please select a value', align='vert', cols=4, removeDuplicates=False, displayNoneAs=''):
        if type(default) <> type([]):
            raise Exception('The default option must be a list of strings.')

        TypedField.__init__(self, name, default, description, error, required, requiredError)

        self.__dict__['options'] = options
        self.__dict__['displayNoneAs'] = displayNoneAs
        self.__dict__['align'] = align
        self.__dict__['cols'] = cols
        self.__dict__['maxlength'] = 255

        for option in options[:]:
            duplicates = options.count(option) - 1
            if duplicates > 0:
                if removeDuplicates:
                    for x in range(duplicates):
                        self.__dict__['options'].pop(self.__dict__['options'].index(option))
                else:
                    raise Exception("The option '%s' has been specified more than once.")
            error = self.invalid(option)
            #raise Exception((option,error))
            if error:
                raise Exception(error)
        for d in default:
            if d not in options:
                raise Exception('The default option must be a one of the options.')

    def set(self, value, strict=False):
        list = []
        error = ''
        for v in value:
            if value == '':
                raise Exception('Value cannot be a NULL string.')
            error = self.invalid(v)
            if error:
                if strict:
                    raise Exception(error)
                else:
                    self.setError(error)
            else:
                list.append(v)
        basic.Field.set(self, list) # XXX NOT SURE??
            
    def populate(self, form):
        if form.has_key(self.htmlName):
            value = form[self.htmlName]
            if type(form[self.htmlName]) == type([]):
                list = []
                for v in value:
                    try:
                        list.append(self.options[int(v.value)])
                    except:
                        self.setError('Please choose an option.')
                self.set(list)
            else:
                if form[self.htmlName].value:
                    self.set([self.options[int(form[self.htmlName].value)]])
                else:
                    self.set([]) # XXX Not sure about this.
        else:
            self.set([])
            #self.setError("Programming Error: This field was not submitted.") # XXX could remove?

    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        if self.maxlength:
            if len(value)>self.maxlength:
                return "Text must be less then %s characters"%self.maxlength
        return False
            
    def valid(self, value={'dummy':''}):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if (type(value) == type(())) or (type(value) == type([])):
            if len(value) == 0:
                if self.required == True:
                    self.setError(self.requiredError)
                    return False
                else:
                    return True
            else:
                # Check results
                for val in value:
                    if val not in self.options:
                        self.setError("'%s' is not a valid option."%val)
                        return False
                return True
        raise TypeError('Expected a list object.')
        
    def html(self):
        output = ''
        if len(self.options) > 0:
            if self.align <> 'default':
                counter = 0
                for option in self.options:
                    checked=''
                    align=''
                    k=option
                    v=counter
                    if self.options[v] in self.value:
                        checked=" checked"
                    if self.align == 'vert':
                        align='<br>'
                    output+='  <input type="checkbox" name="%s" value="%s"%s />%s%s\n'%(self.htmlName, v, checked, k,align)
                    counter+=1
            else:
                output += '\n\n    <table border="0" width="100%" cellpadding="0" cellspacing="0">\n    <tr>\n'
                counter = -1
                for option in self.options:
                    counter += 1
                    if ((counter % self.cols) == 0) and (counter <> 0):
                        output += '    </tr>\n    <tr>\n'
                    output += '      <td>'
                    checked=''
                    align=''
                    k=option
                    v=counter
                    if self.options[v] in self.value:
                        checked=" checked"
                    
                    output += '<input type="checkbox" name="%s" value="%s"%s />%s%s'%(self.htmlName, v, checked, k,align)
                    output += '</td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                    
                counter += 1
                while (counter % self.cols):
                    counter += 1
                    output += '      <td></td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                output += '    </tr>\n    </table>\n\n'
        return output
        
    def frozen(self):
        va = ''
        for v in self.value:
            va = va + ', ' + str(v)
        if va:
            return va[2:]
        else:
            return ''
        
class Text(String):
    "Text Field."
    
    def __init__(self, name, default=None, description='', error='', cols=10, rows=10, required=False, requiredError='Please enter a value', treatNullStringAsNone=True):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['treatNullStringAsNone'] = treatNullStringAsNone
        self.__dict__['maxlength'] = 16,384 
        self.__dict__['cols'] = cols
        self.__dict__['rows'] = rows
        
        error = self.invalid(default)
        if error:
            raise Exception(error)
            
    def str2value(self, value):
        if value == '' and self.treatNullStringAsNone:
            return None
        else:
            return str(value).replace('\r\n','\n')

    def value2str(self, value):    
        if value == None :
            return ''
        else:
            return str(value).replace('\r\n','\n')

    def set(self, value, strict=False):
        error = self.invalid(value)
        if error:
            if strict:
                raise Exception(error)
            else:
                self.setError(error)
        if value == None:
            basic.Field.set(self, value)
        else:
            basic.Field.set(self, value.replace('\r\n','\n'))

    def html(self):
        output='<textarea name="%s"'% (self.htmlName)
        if type(self.cols) != None:
            output+=' cols="%s"'% self.cols
        if type(self.rows) != None:
            output+=' rows="%s"'% self.rows
        output+='>%s</textarea>'% self.value2str(self.value)  
        return output

    def frozen(self):
        if self.value == None:
            return ''
        return self.value.replace('\n','<br />')
        
            

# Deprecated
class Char(String):
    "Char Field."
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', treatNullStringAsNone=True):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['treatNullStringAsNone'] = treatNullStringAsNone
        self.__dict__['size'] = 1
        self.__dict__['maxlength'] = 1
        
        error = self.invalid(default)
        if error:
            raise Exception(error)
        
    def invalid(self, value):
        if value == None:
            return False
        elif type(value) <> type(''):
            return "Invalid value. Values should be strings or None. Null stings '' are not allowed. Use None instead."
        elif self.maxlength:
            if len(value)>self.maxlength:
                return "Characters must be %s character in length."%self.maxlength
        return False

# Deprecated
class CharSelect(StringSelect):
    "CharSelect Field."
    
    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        if len(value)>1:
            return "Characters can only be one character long."
        return False

# Deprecated
class CharCheckBoxGroup(StringCheckBoxGroup):
    "CharCheckBoxGroup Field."
    
    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        if len(value)>1:
            return "Text must be no more than 1 character in length."
        return False
        
class Integer(Char):
    "Integer Field."
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', max=2147483647, min=-2147483647, minError="The number must be greater than or equal to -2147483647", maxError="The number must be less than or equal to 2147483647"):     
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self.__dict__['size'] = 11
        self.__dict__['maxlength'] = 11
        
        try:
            int(max)
        except (OverflowError, ValueError):
            raise Exception(maxError)
        try:
            int(min)
        except (OverflowError, ValueError):
            raise Exception(minError)

        self.__dict__['max'] = max
        self.__dict__['min'] = min
        
        if type(maxError) <> type('') or type(minError) <> type('') or not maxError or not minError:
            raise Exception("maxError and minError should be strings of at least one character in length.")
        self.__dict__['maxError'] = maxError
        self.__dict__['minError'] = minError
        
        error = self.invalid(default)
        if error:
            raise Exception(error)
        
    def invalid(self, value):
        if value == None:
            return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        elif type(value) <> type(1):
            return "Invalid value. Values should be Integers or None. Null stings '' are not allowed. Use None instead."
        if value > self.max:
            return self.maxError
        if value < self.min:
            return self.minError
        return False
 
    def str2value(self, value):
        if value == '':
            return None
        else:
            try:
                value = long(value)

            except:
                self.setError('Please enter a valid integer.')
                return None
            else:
                if value > self.max:
                    self.setError(self.maxError)
                    return None
                if value < self.min:
                    self.setError(self.minError)
                    return None
                return int(value)

    def value2str(self, value):    
        if value == None:
            return ''
        else:
            return str(value)

class IntegerSelect(StringSelect):
    """IntegerSelect Field. Differs from a normal Select field in that it only takes the integers as the options.
    The values are assigned by the program."""
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value'):
        return StringSelect.__init__(self, name,  options, default, description, error, required, requiredError)

    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            int(value)
        except:
            return "Please enter a valid integer."
        return False
        
        
class Bool(StringSelect):
    """BoolSelect Field. Differs from a normal Select field in that it only takes the Bools as the options.
    The values are assigned by the program."""
                               #name, default, description, error, required, requiredError, displayNoneAs, displayTrueAs, displayFalseAs
    def __init__(self, name, default=[], description='', error='', required=False, requiredError='Please enter a value', displayNoneAs='', displayTrueAs='True', displayFalseAs='False'):
        #if not required:
        options = [0, 1, None]
        #if default == []:
        #    default = None
        #else:
        #    options = [0, 1]
        self.__dict__['displayFalseAs'] = displayFalseAs
        self.__dict__['displayTrueAs'] = displayTrueAs
        return StringSelect.__init__(self, name, options, default, description, error, required, requiredError, displayNoneAs)


    def invalid(self, value):
        if value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        return False

    def valid(self, value={'dummy':''}):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.required:
            
            if value == None:
                self.setError(self.requiredError)
                return False
        
        if value in self.options:
            return True
        else:
            self.setError("'%s' wasn't one of the options."%value)
            return False

    #~ def invalid(self, value):
        #~ #raise Exception(value)
        #~ if value == None:
            #~ if self.required:
                #~ return "Please specify a value"
            #~ else:
                #~ return False
        #~ elif value == '':
            #~ return "Programming Error. Null stings '' are not allowed. Use None instead."
        #~ try:
            #~ value = int(value)
        #~ except:
            #~ return "Please choose True or False"
        #~ else:
            #~ if value not in [0,1,2]:
                #~ return "Please choose True or False"
        #~ return False

    #~ def populate(self, form):
        #~ if form.has_key(self.htmlName):
            #~ value = form[self.htmlName].value
            #~ if value <> '':
                #~ try:
                    #~ self.set(self.options[int(value)])
                #~ except IndexError:
                    #~ self.setError('Invalid option selected.')
                    #~ self.set(None)
            #~ else:
                #~ self.set(None)
        #~ else:
            #~ self.set(None)
            
    def html(self):
        rep = {'1':self.displayTrueAs,'0':self.displayFalseAs}
        output='<select name="%s">\n'%(self.htmlName)
        if len(self.options) > 0:
            
            for value in [2,0,1]:
                selected=''
                if str(self.value) == str(value):
                    selected=" selected"
                if value == 2:
                    output+='  <option value="%s"%s>%s</option>\n'%(value,selected,self.displayNoneAs)   
                else:
                    output+='  <option value="%s"%s>%s</option>\n'%(value,selected,rep[str(value)])   

        output+='</select>'
        return output
    
class IntegerCheckBoxGroup(StringCheckBoxGroup):
    "IntegerCheckBoxGroup Field."
    
    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            int(value)
        except:
            return "'%s' is not a valid integer."%value
        return False

class Float(Integer):
    "Float Field."
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value'):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        
        self.__dict__['size'] = 40          # XXX NOT SURE ABOUT WHAT THESE VALUES SHOULD BE
        self.__dict__['maxlength'] = 255
        
        error = self.invalid(default)
        if error:
            raise Exception(error)
       
    def invalid(self, value):
        if value == None:
            return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            float(value)
        except:
            return 'Please enter a valid number.'
        return False
 
    def str2value(self, value):
        if value == '':
            return None
        else:
            try:
                return float(value)
            except:
                self.setError('Please enter a valid number.')
                return value
        
    def value2str(self, value):    
        if value == None:
            return ''
        else:
            return str(value)

class FloatSelect(IntegerSelect):
    """FloatSelect Field. Differs from a normal Select field in that it only takes the integers as the options.
    The values are assigned by the program."""
    
    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            float(value)
        except:
            return "Please enter a valid float."
        return False

class FloatCheckBoxGroup(StringCheckBoxGroup):
    "FloatCheckBoxGroup Field"
    
    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            float(value)
        except:
            return "'%s' is not a valid number."%value
        return False

class Date(String):
    "Date Field."
       
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=10, maxlength=10, format='%d/%m/%Y'):
        TypedField.__init__(self, name, default, description, error, required, requiredError)
        self._checkFormat(format)
        self.__dict__['format'] = format
        self.__dict__['size'] = size
        self.__dict__['maxlength'] = maxlength

        error = self.invalid(default)
        if error:
            raise Exception(error)
            
    def _checkFormat(self, format):
        "For Date, Time and DateTime objects only. Not their derived classes."
        if format<>'%d/%m/%Y' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y' as the time.strptime() function is not defined.")

    def str2value(self, value):
        if value == '':
            return None
        try:
            t = time.strptime(value, self.format)
        except (AttributeError, ValueError):
            # Assume we are on win32 Python 2.2 or below and therefore use dd/mm/yyyy format.
            try:
                v = datetime.date(int(value[6:10]),int(value[3:5]),int(value[0:2]))
            except:
                self.setError('The value is not a valid date. %s'%sys.exc_info()[1])
                return None
            else:
                return v
        else:
            try:
                v = datetime.date(t[0],t[1],t[2])
            except:
                self.setError('The value is not a valid date. %s'%sys.exc_info()[1])
                return None
            else:
                return v
            
    def value2str(self, value):    
        if value == None:
            return ''
        else:
            return str(self.value.strftime(self.format))
            
    def invalid(self, value):
        if value == None:
            return False
        try:
            datetime.date(value.year, value.month, value.day)
        except (AttributeError, ValueError):
            return 'The value is not a valid date.'
        return False

    def html(self):
        return String.html(self) + ' &nbsp; <small>eg.&nbsp;'+str(time.strftime(self.format, time.gmtime()))+'</small>'

class DateSelect(StringSelect):
    "DateSelect Field"
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%d/%m/%Y'):
        self._checkFormat(format)
        self.__dict__['format'] = format
        return StringSelect.__init__(self, name,  options, default, description, error, required, requiredError)

    def _checkFormat(self, format):
        "For Date, Time and DateTime objects only. Not their derived classes."
        if format<>'%d/%m/%Y' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y' as the time.strptime() function is not defined.")

    def value2str(self, value):    
        if value == None:
            return ''
        else:
            return str(self.value.strftime(self.format))
            
    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            raise Exception(value)
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            datetime.date(value.year, value.month, value.day)
        except (AttributeError, ValueError):
            return 'The value is not a valid date.'
        return False
        
class DateCheckBoxGroup(StringCheckBoxGroup):
    "DateCheckBoxGroup Field."
    
    def __init__(self, name, options, default=[], description='', error='', required=False, requiredError='Please select a value', format='%d/%m/%Y', align='vert', cols=4, removeDuplicates=False):
        if type(default) <> type([]):
            raise Exception('The default option must be a list of strings.')

        TypedField.__init__(self, name, default, description, error, required, requiredError)

        self.__dict__['options'] = options
        self.__dict__['align'] = align
        self.__dict__['cols'] = cols
        self.__dict__['format'] = format

        for option in options:
            duplicates = options.count(option) - 1
            if duplicates > 0:
                if removeDuplicates:
                    for x in range(duplicates):
                        self.__dict__['options'].pop(self.__dict__['options'].index(option))
                else:
                    raise Exception("The option '%s' has been specified more than once.")
            error = self.invalid(option)
            if error:
                raise Exception(error)
        for d in default:
            if d not in options:
                raise Exception('The default option must be a one of the options.')

    def _checkFormat(self, format):
        "For Date, Time and DateTime objects only. Not their derived classes."
        if format<>'%d/%m/%Y' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y' as the time.strptime() function is not defined.")

    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            datetime.date(value.year, value.month, value.day)
        except (AttributeError, ValueError):
            return 'The value is not a valid date.'
        return False

    def html(self):
        output = ''
        if len(self.options) > 0:
            if self.align <> 'default':
                counter = 0
                for option in self.options:
                    checked=''
                    align=''
                    k=option
                    v=counter
                    if self.options[v] in self.value:
                        checked=" checked"
                    if self.align == 'vert':
                        align='<br>'
                    output+='  <input type="checkbox" name="%s" value="%s"%s />%s%s\n'%(self.htmlName, v, checked, k.strftime(self.format),align)
                    counter+=1
        
            else:
                output += '\n\n    <table border="0" width="100%" cellpadding="0" cellspacing="0">\n    <tr>\n'
                counter = -1
                for option in self.options:
                    counter += 1
                    if ((counter % self.cols) == 0) and (counter <> 0):
                        output += '    </tr>\n    <tr>\n'
                    output += '      <td>'
                    checked=''
                    align=''
                    k=option
                    v=counter
                    if self.options[v] in self.value:
                        checked=" checked"
                    
                    output += '<input type="checkbox" name="%s" value="%s"%s />%s%s'%(self.htmlName, v, checked, k.strftime(self.format) ,align)
                    output += '</td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                    
                counter += 1
                while (counter % self.cols):
                    counter += 1
                    output += '      <td></td>\n      <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n'
                output += '    </tr>\n    </table>\n\n'
        return output

    def frozen(self):
        va = ''
        for v in self.value:
            va = va + ', ' + str(v.strftime(self.format))
        if va:
            return va[2:]
        else:
            return ''
            
class Time(Date):
    "Time Field."

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=10, maxlength=10, format='%H:%M:%S'):
        Date.__init__(self, name, default, description, error, required, requiredError, size, maxlength, format)
        
    def _checkFormat(self, format):
        if format<>'%H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%H:%M:%S' as the time.strptime() function is not defined.")

    def str2value(self, value):
        if value == '':
            return None
        try:
            t = time.strptime(value, self.format)
        except (AttributeError, ValueError):
            # Assume we are on win32 Python 2.2 or below and therefore use hh:mm:ss format.
            try:
                v = datetime.time(int(value[0:2]),int(value[3:5]),int(value[6:8]))
            except:
                self.setError('The value is not a valid time. %s'%sys.exc_info()[1])
                return None
            else:
                return v
        else:
            try:
                v = datetime.time(t[3],t[4],t[5])
            except:
                self.setError('The value is not a valid time. %s'%sys.exc_info()[1])
                return None
            else:
                return v
                
    def invalid(self, value):
        if value == None:
            return False
        try:
            datetime.time(value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid time.'
        return False
        

class TimeSelect(DateSelect):
    "TimeSelect Field."
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%H:%M:%S'):
        return DateSelect.__init__(self, name,  options, default, description, error, required, requiredError, format)

    def _checkFormat(self, format):
        if format<>'%H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%H:%M:%S' as the time.strptime() function is not defined.")

    def invalid(self, value):
        if value == None:
            if self.required:
                return "You cannot specify None as a possible option and specify required=True."
            else:
                return False
        elif value == '':
            raise Exception(value)
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            datetime.time(value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid time.'
        return False
        
class TimeCheckBoxGroup(DateCheckBoxGroup):
    "TimeCheckBoxGroup Field."
    
    def __init__(self, name, options, default=[], description='', error='', required=False, requiredError='Please select a value', format='%H:%M:%S', align='vert', cols=4, removeDuplicates=False):
        return DateCheckBoxGroup.__init__(self, name, options, default, description, error, required, requiredError, format, align, cols, removeDuplicates)
    
    def _checkFormat(self, format):
        if format<>'%H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%H:%M:%S' as the time.strptime() function is not defined.")


    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            datetime.time(value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid time.'
        return False
        
class DateTime(Date):
    "DateTime Field."
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=19, maxlength=19, format='%d/%m/%Y %H:%M:%S'):
        Date.__init__(self, name, default, description, error, required, requiredError, size, maxlength, format)
        
    def _checkFormat(self, format):
        if format<>'%d/%m/%Y %H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y %H:%M:%S' as the time.strptime() function is not defined.")

    def str2value(self, value):
        if value == '':
            return None
        try:
            t = time.strptime(value, self.format)
        except (AttributeError, ValueError):
            # Assume we are on win32 Python 2.2 or below and therefore use dd/mm/yyyy hh:mm:ss format.
            try:
                v = datetime.datetime(int(value[6:10]),int(value[3:5]),int(value[0:2]),int(value[11:13]),int(value[14:16]),int(value[17:19]))
            except:
                self.setError('The value is not a valid datetime. %s'%sys.exc_info()[1])
                return None
            else:
                return v
        else:
            try:
                v = datetime.datetime(t[0],t[1],t[2],t[3],t[4],t[5])
            except:
                self.setError('The value is not a valid datetime. %s'%sys.exc_info()[1])
                return None
            else:
                return v
                
    def invalid(self, value):
        if value == None:
            return False
        try:
            datetime.datetime(value.year, value.month, value.day, value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid datetime.'
        return False
        
        
class DateTimeSelect(DateSelect):
    "DateTimeSelect Field."
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%d/%m/%Y %H:%M:%S'):
        """Initialisation code"""
        return DateSelect.__init__(self, name,  options, default, description, error, required, requiredError, format)

    def _checkFormat(self, format):
        if format<>'%d/%m/%Y %H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y %H:%M:%S' as the time.strptime() function is not defined.")

    def invalid(self, value):
        if value == None:
            return False
        try:
            datetime.datetime(value.year, value.month, value.day, value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid datetime.'
        return False
        
class DateTimeCheckBoxGroup(DateCheckBoxGroup):
    "DateTimeCheckBoxGroup Field"
    
    def __init__(self, name, options, default=[], description='', error='', required=False, requiredError='Please select a value', format='%d/%m/%Y %H:%M:%S', align='vert', cols=4, removeDuplicates=False):
        return DateCheckBoxGroup.__init__(self, name, options, default, description, error, required, requiredError, format, align, cols, removeDuplicates)
        
    def _checkFormat(self, format):
        if format<>'%d/%m/%Y %H:%M:%S' and os.name <> 'posix' and sys.version_info < (2,3): # XXX windows
            raise Exception("For non posix OSs and Python < 2.3 format must be '%d/%m/%Y %H:%M:%S' as the time.strptime() function is not defined.")
    
    def invalid(self, value):
        if value == None:
            return "None is not a valid option for a checkbox group. The user can choose to check no boxes rather than choose an None option."
        elif value == '':
            return "Programming Error. Null stings '' are not allowed. Use None instead."
        try:
            datetime.datetime(value.year, value.month, value.day, value.hour, value.minute, value.second)
        except (AttributeError, ValueError):
            return 'The value is not a valid datetime.'
        return False
        
fields = {
    'String':String,
    'StringSelect':StringSelect,
    'StringCheckBoxGroup':StringCheckBoxGroup,
    'Text':Text,
    #'TextSelect':TextSelect,
    #'TextCheckBoxGroup':TextCheckBoxGroup,
    #'Char':Char,
    'Bool':Bool,
    'Integer':Integer,
    'IntegerSelect':IntegerSelect,
    'IntegerCheckBoxGroup':IntegerCheckBoxGroup,
    'Float':Float,
    'FloatSelect':FloatSelect,
    'FloatCheckBoxGroup':FloatCheckBoxGroup,
    'Date':Date,
    'DateSelect':DateSelect,
    'DateCheckBoxGroup':DateCheckBoxGroup,
    'DateTime':DateTime,
    'DateTimeSelect':DateTimeSelect,
    'DateTimeCheckBoxGroup':DateTimeCheckBoxGroup,
    'Time':Time,
    'TimeSelect':TimeSelect,
    'TimeCheckBoxGroup':TimeCheckBoxGroup,
}