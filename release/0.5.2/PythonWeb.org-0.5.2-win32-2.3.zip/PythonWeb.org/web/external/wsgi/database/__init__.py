"Database Access"

import wsgi.base
import web.database

class Database(wsgi.base.BaseMiddleware):
    
    def __init__(self, application, **params):
        import web.database
        self.params = params
        self.application = application
    
    def environ(self, environ):
        for key in ['web.database.connection', 'web.database.cursor']:
            if environ.has_key(key):
                raise Exception('environ already has database keys')
        connection = web.database.connect(**self.params)
        environ['web.database.connection'] = connection
        environ['web.database.cursor'] = connection.cursor()
        # XXX Defaults
        return environ