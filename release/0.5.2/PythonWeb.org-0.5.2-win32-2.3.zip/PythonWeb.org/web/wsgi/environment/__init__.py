"Environment Class"

import web.wsgi.base

class Environment(web.wsgi.base.BaseMiddleware):
    
    def __init__(self, application, name, storage, **params):
        self.name = name
        self.storage = storage
        self.application = application
        self.params = params
    
    def environ(self, environ):
        import web.environment
        if not self.params.has_key('cursor'):
            if not environ.has_key('web.database.cursor'):
                raise web.errors.EnvironmentError('Expected %s key in environ dictionary or for the cursor to be specified'%'web.database.cursor')
            else:
                self.params['cursor'] = environ['web.database.cursor']
        environ['web.environment.driver'] = web.environment.driver(name=self.name, storage=self.storage, **self.params)
        return environ
