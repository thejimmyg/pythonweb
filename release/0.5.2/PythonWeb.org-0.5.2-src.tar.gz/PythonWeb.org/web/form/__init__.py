"""Class to handle Persistant HTML forms."""


# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)

from web.errors import FormError
import field

def dictAsHiddenFields(stickyData):
    """Changes a dictionary such as lemon.get into a string containing hidden fields HTML."""
    fields = ''
    for k,v in stickyData.items():
        if type(v) <> type([]):
            fields += '<input type="hidden" name="%s" value="%s" />\n' % (str(k),str(v)) # No _plus
        else:
            for item in v:   
                fields += '<input type="hidden" name="%s" value="%s" />\n' % (str(k),str(item)) # No _plus
    return fields

###########################################################################
#
# Form Classes
#

#~ class Fields(list):
    #~ def __getattr__(self, name):
        #~ if name == '__bases__':
            #~ return self.__bases__
            
        #~ for item in self:
            #~ if item.name() == name:
                #~ return item
        #~ raise AttributeError("There is no field named '%s' in the form."%name)
        
    #~ def __setattr__(self, name, value):
        #~ counter = 0
        #~ found = False
        #~ for item in self:
            #~ counter += 1
            #~ if item.name() == name:
                #~ found = True
                #~ break
        
        #~ if found and counter <= len(self):
            #~ self[counter-1] = value
        #~ else:
            #~ raise AttributeError("There is no field named '%s' in the form."%name)
    
                
class Form:
    """Form Class - Designed to be over-ridden to form custom forms made up of html.Field derivatives.
    
    enctype can be '' or 'multipart/form-data'.
    """
    
    def __init__(self, name='form', action='', method='get', stickyData={}, enctype='', populate=None):#, includeName=None):
        #if includeName and not name:
        #    raise Exception('You cannot include the name of the form before the field because no form name is specified.')
        self.__dict__['name'] = name
        #self.__dict__['includeName'] = includeName # Not used
        self.__dict__['action'] = action
        self.__dict__['method'] = method
        self.__dict__['fields'] = []#Fields()
        self.__dict__['actions'] = []
        self.__dict__['stickyData'] = stickyData
        self.__dict__['enctype'] = enctype
        
        self.setup()
        # Error checking
        if enctype == 'multipart/form-data' and method.upper() == 'GET':
            raise Exception("If you wish to use an enctype of 'multipart/form-data' you must specify action='post'.")
        elif enctype <> 'multipart/form-data':
            for field in self.fields:
                if field.type() in ['File']:
                    raise Exception("This form contains File fields so the you must set enctype='multipart/form-data' and action='post'.")
        # Name mangling
        #if includeName:
        #    for field in self.fields:
        #        field.htmlName = name + '.' + field.name()
        if populate:
            self.populate(populate)
        
    def setup(self):
        "Constructor to be overridden in derived classes to construct a form object"
        pass #raise lemon.LemonError('The setup() function should be overridden in the base class.')
        
    def valid(self):
        """Internal function to make sure no wierd values have been set. Populate should take care
        of the standard ones."""
        validates = True
        for field in self.fields:
            if not field.valid():
            #if not field.valid(field.get()):
                validates = False 
        return validates

    def populate(self, form):
        """Sets up the form with the values in the form dictionary. the dictionary should be
        in the form of the return from the cgi.FieldStorage() 
        function is.
        """
        for field in self.fields:
            if field.type() not in ['Button','Submit','Reset','Hidden']:
                field.populate(form)
            
    #~ def isValid(self):
        #~ """Function designed to be over-ridden in the derived classes to provide custom validation for
        #~ each individual form."""
        #~ return True
        
    # start deprecated
    def add(self, **params):
        "Generic method to add an object to a form by specifying its values"
        if params.has_key('object'):
            for param in ['field','action']:
                if params.has_key(param):
                    raise FormError("You cannot specify 'object' and %s when adding a field."%(repr(param)))
            return self.addField(params['object'])
        elif params.has_key('field'):
            for param in ['action']:
                if params.has_key(param):
                    raise FormError("You cannot specify 'object' and %s when adding a field."%(repr(param)))
            return self.addField(field.field(**params))
        elif params.has_key('action'):
            return self.addAction(params['action'])
        else:
            raise FormError("No 'field' or 'object' keys found.")
    # end deprecated

    def addMany(self, fields):
        for field in fields:
            self.add(field)
            
    def addField(self, object=None, **params):
        """Adds the field specified in the method to the fields array of the form."""
        if object<>None:
            if params <> {}:
                raise FormError('If object is specified as a field object, addField() cannot take extra parameters')
            if object.type() == 'File':
                if self.method.upper() <> 'POST':
                    raise Exception("You must specify the form method as 'POST' to use file upload fields.")
                if self.enctype.lower() <> 'multipart/form-data':
                    raise Exception("You must specify the form enctype as 'multipart/form-data' to use file upload fields.")
                        
            for f in self.fields:
                if f.name() == object.name():
                    raise KeyError("The field name '%s' is already in use in this form." % (object.name()))
            
        else:
            object = field.field(**params)
        #if field.name() in dir(self):
        #    raise KeyError("The field name '%s' is reserved; please choose another name for the field." % (field.name()))
        self.__dict__['fields'].append(object)
        
    def addFields(self, fields):
        for field in fields:
            self.addField(field)

    def addAction(self, action):
        """Add a submit button to the actions part of the form with the name 'action'. This is the preferred way
        to add submit buttons rather than specifying them as field objects and calling addField()."""
        for f in self.actions:
            if action == f:
                raise KeyError("The action name '%s' is already in use in this form." % (action))
        self.__dict__['actions'].append(action)
    
    def __getitem__(self, name):
        if type(name) == type(1):
            return self.fields[name]
        else:
            return self.get(name)#.get()#builderValue()
            
    def get(self, name):
        "Deprecated"
        return self.field(name)
        
    def field(self, name):
        """If name is a string ,retruns the field object named 'item'.
        Otherwise treats the form as a list of fields in the order they were added and and returns form.fields[item]."""
        stri = ''
        if type(name) == type(1):
            return self.__dict__['fields'][name]
        else:
            for f in self.__dict__['fields']:
                if f.name() == name:
                    return f
                else:
                    stri += ' '+f.name()
                    
        raise ValueError("Field %s was not found." %(repr(name)))
 
    def delete(self, name):
        return self.remove(name)

    # Deprecated
    def remove(self, name):
        counter = 0
        for f in self.__dict__['fields']:
            if f.name() == name:
                break
            counter += 1
        if counter < len(self.__dict__['fields']):
            self.__dict__['fields'].pop(counter)
        else:
            raise Exception("No field named '%s' found."%name)


    def has_key(self, item):
        for f in self.__dict__['fields']:
            if f.name() == item:
                return True
        return False
                    
#
# Value Retrival Functions
#

    def values(self):#, fields=None):
        "Return a tuple containing the values of the form fields in the order they were added."
        return tuple(self.fields)
        #~ names = fields
        #~ valuesList = []
        #~ if names:
            #~ for name in names:
                #~ value = self.get(name).get()#builderValue()
                #~ if value:
                    #~ valuesList.append(value)
                #~ else:
                    #~ valuesList.append('')
        #~ else:
            #~ for field in self.fields:
                #~ value = field.get()#builderValue()
                #~ if value:
                    #~ valuesList.append(value)
                #~ else:
                    #~ valuesList.append('')

        #~ return tuple(valuesList)
        
    def keys(self):
        return self.names()
    
    # deprecated
    def names(self):
        "Return a tuple containing the names of the form fields in the order they were added."
        namesList = []
        for field in self.fields:
            #if self.includeName:
            #    namesList.append(self.name+'.'+field.name())
            #else:
            namesList.append(field.name())
        return tuple(namesList)

    def dict(self):
        "Return a dictionary containing the names and values of the fields."
        d = {}
        for field in self.fields:
            d[field.name()] = field.get()#builderValue()
        return d

    def items(self):
        keys = self.keys()
        values = self.fields
        r = []
        for k in range(len(keys)):
            r.append((keys[k],values[k]))
        return tuple(r)
   
#
# HTML Output Functions
#

    def html(self, text=None, showActions=True):
        "Return an HTML representation of the form."
        if text == None:
            text = self._asFieldsHTML()
        enctype = ''
        if self.enctype <> None:
            enctype = ' enctype="%s"' % self.enctype
        output =  '<form id="%s" class="pythonweb" action="%s" method="%s"%s>\n'%(self.name, self.action, self.method, enctype)
        output += dictAsHiddenFields(self.stickyData) 
        output += '<table border="0">\n<tr><td>%s</td></tr>\n'% text
        if showActions:
            for action in self.actions:
                output += '<tr><td>&nbsp;</td></tr>\n<tr><td><input type="submit" value="%s" name="%s" /></td></tr>'%  (action , 'action')
        output += '\n</table>\n</form>'
        return output
        
    def hidden(self):
        return self.html(text=self._asFieldsHidden(), showActions=True)
        
        
    def frozen(self, action=None):
        showActions = True
        if not action:
            showActions = False
        else:
            self.actions = ([action])
        return self.html(self._asFieldsText() + self._asFieldsHidden(), showActions)
        
    #def frozen(self):
    #    return self._asFieldsText()

    def templateDict(self):
        "Return a dictionary suitable for use in a lemon.html.template class."
        fieldsList = []
        for field in self.fields:
            fieldData = {}
            fieldData['name'] = field.name()
            fieldData['error'] = field.error()
            fieldData['description'] = field.description()
            fieldData['value'] = field.get()#builderValue())
            fieldData['html'] = field.html()
            fieldsList.append(fieldData)
            
        enctype = ''
        if self.enctype <> None:
            enctype = ' enctype="%s"' % self.enctype

        dict = {}
        dict['name'] = self.name()
        dict['action'] = self.action
        dict['method'] = self.method
        dict['enctype'] = enctype
        dict['fields'] = fieldsList
        dict['actions'] = self.actions
        dict['stickyData'] = lemon.dictAsHiddenFields(self.stickyData)
        return dict

    def _asFieldsHTML(self):
        """Outputs the HTML of the form. Desinged to be over-ridden in the derived classes to implement custom
        form output to the web-browser.
        
        Can be accessed either by using the instance attribute .html or using the defualt __str__() method.
        """
        output = '<table border="0" cellpadding="3" cellspacing="0">\n'
        hidden = ''
        #raise TypeError(dir(self.fields[0]))
        for field in self.fields:
            if field.type() <> 'Hidden':
                description  = ''
                errors       = ''
                if type(field.error) == type('') and field.error: # XXX Horible Hack
                        output += '<tr class="error">\n'
                elif type(field.error) <> type('') and field.error():
                        output += '<tr class="error">\n'
                else:
                    output += '<tr>\n'
                output += '  <td valign="top">'
                output += field.description() + ' '
                output += '</td>\n'
                output += '  <td>&nbsp;&nbsp;&nbsp;</td>\n'
                output += '  <td valign="top">' + field.html() + '</td>\n'
                output += '  <td valign="top">'
                if type(field.error) == type(''): # XXX Horrible hack for bad planning
                    if field.error:
                        output += field.error
                else:
                    if field.error():
                        output += field.error()
                output += '</td>\n'
                output += '</tr>\n'
            else:
                hidden += field.html()
        output += '</table>\n' + hidden
        return output
        
    def _asFieldsText(self):
        output = '<table border="0" cellpadding="3" cellspacing="0">\n'
        for field in self.fields:
            if field.type() <> 'Hidden':
                description  = ''
                errors       = ''
                output += '<tr>\n'
                output += '  <td valign="top">'
                output += field.description() + ' '
                output += '</td>\n'
                output += '  <td>&nbsp;&nbsp;&nbsp;</td>\n'
                output += '  <td valign="top">' + field.frozen() + '</td>\n'
                output += '  <td valign="top">'
                output += field.error()
                output += '</td>\n'
                output += '</tr>\n'
        output += '</table>\n'

        return output
        
    def _asFieldsHidden(self):
        """Outputs the HTML of the form. Desinged to be over-ridden in the derived classes to implement custom
        form output to the web-browser.
        Can be accessed either by using the instance attribute .html or using the defualt __str__() method.
        """
        output = ''
        for field in self.fields:
            output += str(field.hidden()) + '\n'
        return output
        

