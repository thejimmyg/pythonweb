"""HTML Fields

The idea is that you can create field values in a standard way and then
you derive a form from the form class to look and behave exactly as you want your form to
behave with your own validation, export, import functions etc. Use a class for each field in the form.

See the doc/examples/code/forms.py example and all will become transparently clear

Developer Ideas
===============

It doesn't matter what the fields do internally but they must expose the following interface:

TIP: It isn't really worth trying to maintain complex data types inside the classes because often the values
come back as strings and your class may expect integers, doing a conversion could lead to an error before the
validation is done and just cause problems. It works out easier just to get the string values from the fields,
maintain them as a list of values and then convert them in the valid() funciton where you can let the user know
if things go wrong. This means clever inheritance is nearly impossible but will proabably save you any hassle.

builderValue() is for other applications to get the final value.


New Ideas
---------

Internally the fields keep their values as string representations. These values are set ant retrieved using the 
set() and value methods. Fields taking multiple values are kept as an array of strings.

An empty string is treated as a NULL value for single fields. An empty array is treated as NULL for multiple
fields.

The populate() method is used to retrieve information from a dictionary (such as a cgi.FieldStorage() and populate
the field with the appropriate string representation value using the set() method. This way fields don't have to 
have make sure that they submit their string representation when a user clicks submit.

The retrieve() method is used in derived classes to convert from the string representation to a representation
suitatble for the value being represented.

Derived Classes
---------------

Derived from the base classes should be fields with types. For example integer fields, multiple time fields, date
fields etc. These should implement the retrieve() method explained above and the populate() method should also
accept the value output by retrieve().

Attribute Access
----------------

All classes should have private member variables with value and set() methods. Attribute access should then be
emulated by overriding the __getattr__ () methods. This leads to robust code and a simple interface between the 
variables exposed to the user and the actual variables required.

Typed Fields
============

Public Access
-------------

Only the set() value and valid() methods should really be used from outside the class. set() and value can take
the type attribute to over-ride the type of the data in used by these public methods. The type attribute can also
be set in the class constructor.

Formats
-------

Certain fields such as the Time, Date and DateTime fields can display their value in a variety of ways. The format
attribute specified in the constructor or in the html() or frozen() methods defines how these fields display their
values. Eg Time could be an input box requiring strings entered in the format hh:mm. Alternatively it could be two
drop-down boxes, one for hour and one for minute.


Internal Workings
-----------------

Typed fields have a different way of working to the non-typed ones. You specify the values in the correct type
and the field returns that value.

Valid Ideas
-----------

make the valid() option work without value.
"""
__author__ = "James Gardner <james@xecos.com>"
__date__ = "9th April 2003"
__version__ = "0.1"
__credits__ = """Guido van Rossum, for an excellent programming language."""

def field(**params):
    from web.errors import FormError
    import basic, typed, extra
    fields = {}
    for field, object in basic.fields.items():
        if field.lower() in fields.keys():
            raise FormError("The fields module already contains a field named %s"%(repr(field)))
        fields[field.lower()] = object
    for field, object in typed.fields.items():
        if field.lower() in fields.keys():
            raise FormError("The fields module already contains a field named %s"%(repr(field)))
        fields[field.lower()] = object
    for field, object in extra.fields.items():
        if field.lower() in fields.keys():
            raise FormError("The fields module already contains a field named %s"%(repr(field)))
        fields[field.lower()] = object
    if not params.has_key('type'):
        raise FormError("'type' parameter not specified.")
    elif not params['type'].lower() in fields.keys():
        raise FormError("No such field %s"%(repr(params['field'])))
    else:
        f = params['type'].lower()
        del params['type']
        #~ spec = inspect.getargspec(fields[f.lower()].__init__.im_func)
        #~ # Check we have no extra parameters
        #~ for param in params.keys():
            #~ if param not in spec[0]:
                #~ raise FormError("The field %s does not take the parameter %s"%(repr(f), repr(param)))
        #~ # Add the default values
        #~ defargs = spec[0][-len(spec[3]):]
        #~ for i in range(len(spec[3])):
            #~ if not params.has_key(defargs[i]):
                #~ params[defargs[i]] = spec[3][i]
        #~ # Check required values are there
        #~ reqargs = spec[0][:-len(spec[3])]
        #~ for i in range(len(reqargs)):
            #~ if not params.has_key(reqargs[i]):
                #~ FormError("Required parameter %s not specified."%(repr(reqargs[i])))
        return fields[f](**params)


    
        