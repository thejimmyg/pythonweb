"Implementation of PEP 333 Web Server Gateway Interface for PythonWeb.org"

import web
from wsgiref.handlers import CGIHandler

__all__ = ['runCGI', 'base', 'cgi', 'database', 'environment', 'error', 'session', 'auth']

def runCGI(application):
    "Wrapper function to enable WSGI applications to run in a CGI environment"
    return CGIHandler().run(application)

