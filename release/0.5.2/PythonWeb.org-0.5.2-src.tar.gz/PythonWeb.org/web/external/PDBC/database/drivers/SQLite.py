"""SQLite driver for the PDBC module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import base, mysql, database, datetime, SnakeSQL, SQLParserTools
import os.path
converters = {
        'String':   base.BaseStringConverter(),
        'Text':     base.BaseTextConverter(),
        'Binary':   base.BaseBinaryConverter(),
        'Bool':     mysql.MySQLBoolConverter(),
        'Integer':  base.BaseIntegerConverter(),
        'Long':     base.BaseLongConverter(),
        'Float':    base.BaseFloatConverter(),
        'Date':     base.BaseDateConverter(),
        'Datetime': base.BaseDatetimeConverter(), # Decision already made.
        'Time':     base.BaseTimeConverter(),
}

class Connection(base.Connection):
    
    def makeConnection(self, **params):
        try:
            import sqlite
        except ImportError, e:
            raise ImportError('sqlite could not be imported and is required for SQLite database access. Please check it is correctly installed')
        if not params.has_key('database'):
            raise SnakeSQL.SQLError('No database specified')
        if os.path.exists(params['database']) and  os.path.isdir(params['database']):
            raise SnakeSQL.SQLError('Could not create database, the path "%s" is a directory not a database file'%params['database'])
        return sqlite.connect(**params)

    def commit(self):
        return base.Connection.commit(self)
        
    def rollback(self):
        return base.Connection.rollback(self)

class Cursor(mysql.Cursor):
    def create(self, **params):
        return base.Cursor.create(self, **params)

    #def _checkDeleteConstraints(self, table, where):
    #    pass
    # Only SQLite > 2.5 supports a way of doing this so manual check using the MySQL method
        
    def _checkInsertConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)

    def _checkUpdateConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)

    # Limit Emulation
    def _doDelete(self, sql, table, where, limit):
        if limit:
            columns = self.columns(table)
            results = self.select(columns=columns, tables=[table], where=where)
            if len(results) > limit:
                self._execute(sql[:-(len('limit ')+len(str(limit)))])
                results = results[limit:]
                self.insertMany(table, columns=columns, values=results)
            else:
                self._execute(sql[:-(len('limit ')+len(str(limit)))])
        else:
            self._execute(sql)
        
    # Limit Emulation
    def _doUpdate(self, sql, table, where, limit, colUpdate, newValues):
        if limit:
            #if not len(colUpdate) == len(newValues)
            columns = list(self.columns(table))

            results = self.select(columns=columns, tables=[table], where=where)
            if len(results) > limit:
                self.delete(table=table, where=where)
                updated = results[:limit]
                same = results[limit:]
                self.insertMany(table, columns=columns, values=same)
                newVals = []
                for record in updated:
                    record = list(record)
                    for i in range(len(colUpdate)):
                        newVal = self.connection.tables[table].get(colUpdate[i]).converter.sqlToValue(newValues[i])
                        record[columns.index(colUpdate[i])] =  newVal
                    newVals.append(record)
                self.insertMany(table, columns=columns, values=newVals)
            else:
                self._execute(sql[:-(len('limit ')+len(str(limit)))])
        else:
            self._execute(sql)
            
    def drop(self, **params):
        return base.Cursor.drop(self, **params)

    def _setupTypes(self):
        return {
            'String':   "TEXT",
            'Text':     "TEXT",
            'Binary':   'MEDIUMBLOB',
            'Bool':     "INTEGER", # XXX
            'Integer':  "INTEGER",
            'Long':     "TEXT", # XXX
            'Float':    "FLOAT",
            'Date':     "TEXT",
            'Datetime': "TEXT", 
            'Time':     "TEXT",
        }

driver = {
    'converters':converters,
    'columnClass':base.BaseColumn,
    'tableClass':base.BaseTable,
    'cursorClass':Cursor,
}