"""
Ready-to-use custom error handler functions.

What happens here is that all of the functions are given the traceback info dictionary as thier first argument
and a load of extra parameters as the second arguments

Cecil Westerhof
I generalized the code. This makes it more readable and easier to
maintain.
      * I use sys.stdout.write. In this way you do not get an extra
        newline.
      * The HTML code that is generated will pass certification now.
        Konqueror still has a problem with it. It is strange. When I
        save the file and then open it in Konqueror, it is displayed
        okay.
      * When you do not use a filename, the error logging is done in the
        directory LOGS in the current directory. Every day has his own
        file. Every message starts with a line with hashes.
      * When you do use a filename, this is used for logging. In the
        future I will change it, so that you can use a directory other
        as LOGS.
      * Logging is now done with append.
      * I will also change it so that you can log to a database.

James Gardner 12-Jan-04
      * Changed the style to normal PythonWeb
      * Refactored the code so some of Cecil's generalisations were no longer 
        necessary
      * Tidied up remaining funcitons
      * Appending is optional (but defaults to True)

James Gardner 18-Jan-04
      * Refactored everything again into more clearly defined handlers and info
        consequently there isn't much left here!
      
"""

import sys, time, os
import web, web.error

def debug(error, alternative=None):
    if error[0] == web.error.Breakpoint:
        import pdb
        pdb.post_mortem(error[2])
    else:
        if alternative == None:
            raise error[0]
        elif handlers.has_key(alternative):
            handlers['alternative'](error)
        else:
            raise Exception('An error occured which was not a Breakpoint and the alternative handler specified in web.error.handle() does not exist')

def browser(error, context=5, format='html', output='debug', header='text/html'):
    info = web.error.info(
        error=error, 
        context=context, 
        format=format, 
        output=output, 
    )
    if header:
        sys.stdout.write(web.header(header))
    sys.stdout.write(info)

def file(error, context=5, format='html', output='debug', filename=None, append=True, dir='', message=''):
    info = web.error.info(
        error=error, 
        context=context, 
        format=format, 
        output=output, 
    )
    if dir and not dir[-1:] == '/':
        dir += '/'
    if filename == None:
        filename = "%s%s.log" % (dir, time.strftime('%Y-%m-%d'))
    if append:
        fp = open(filename, 'a')
        fp.write("##########\n")
    else:
        fp = open(filename, 'w')
    print filename
    
    fp.write(info)
    fp.write("\n")
    fp.close()
    if message:
        print message

def send(error, context=5, format='text', output='debug'):
    info = web.error.info(
        error=error, 
        context=context, 
        format=format, 
        output=output, 
    )
    print info

handlers = {
    'browser':browser,
    'file':file,
    'send':send,
    'print':send,
    'debug':debug,
}