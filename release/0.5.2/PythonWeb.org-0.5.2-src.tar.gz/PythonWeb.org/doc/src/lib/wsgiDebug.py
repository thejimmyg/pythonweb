from web.wsgi import *

class simpleApp(base.BaseApplication):
    def start(self):
        import web.error
        value = 5
        raise web.error.Breakpoint('Test Exception')

application = simpleApp()


