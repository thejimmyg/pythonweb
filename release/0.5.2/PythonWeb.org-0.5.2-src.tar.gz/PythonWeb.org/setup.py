#!/usr/bin/env python

"""Useage: setup.py [option]

Options
 install    Install the modules
 bdist 2.2  Create a win32 python 2.2 binary distribution
 bdist 2.3  Create a win32 python 2.3 binary distribution
 sdist      Create a source distribution"""

if __name__ == '__main__':

# This is ames change

    import sys, os, os.path
    if os.path.exists('scripts/sql.py'):
        os.remove('scripts/sql.py')

    fp = open('web/external/PDBC/scripts/console.py', 'r')
    data = fp.read()
    fp.close()
    fp = open('scripts/sql.py','w')
    fp.write(data)
    fp.close()

    import web, database, SnakeSQL
    from distTools import install, bdist
    excludeAllDirs = ['CVS']
    excludeDirs = [
        'doc/chm',
        'doc/dist',
        'doc/html',
        'doc/html_multipage',
        'doc/pdf-a4',
        'doc/pdf-letter',
        'doc/ps-a4',
        'doc/ps-letter',
        'doc/text',
        'doc/src/html',
        'doc/src/licence',
        'doc/src/overview',
        'doc/src/web',
        'doc/src/whatsnew',
        'doc/src/external',
        'doc/src/lib/webserver-auth',
        'doc/src/lib/environment',
        'doc/src/lib/lib',
        'doc/src/lib/database',
        'doc/src/lib/database-object-multiple',
        'doc/src/lib/database-object-others',
        'doc/src/lib/database-object-query',
        'doc/src/lib/database-object-related',
        'doc/src/lib/database-object-simple',
        'build',
        'dist',
        'doc/src/lib/example-web-auth',
        'doc/src/lib/example-web-session',
        'doc/src/lib/example-web-auth-session',
        'test',
        'web/external/PDBC/build',
        'web/external/PDBC/dist',
        'web/external/PDBC/test',
        'web/external/PDBC/doc',
        'web/external/PDBC/database/compat', # Duplicated in web.compat
        'web/external/PDBC/database/external/SnakeSQL/build',
        'web/external/PDBC/database/external/SnakeSQL/dist',
        'web/external/PDBC/database/external/SnakeSQL/test',
        'web/external/PDBC/database/external/SnakeSQL/doc',
        'web/external/PDBC/database/external/SnakeSQL/SnakeSQL/compat', # Duplicated in web.compat
        'scripts/database-object-form',
        'scripts/webserver-auth',
        'scripts/webserver-auth-simple',
        'scripts/webserver-session',
        'scripts/webserver-session-simple',
        'scripts/wsgi-auth',
        'scripts/wsgi-session',
        'scripts/others',
    ]
    excludeFiles = [
        'scripts/WSGI_mod_python.py',
        'doc/src/Makefile',
        'doc/src/README.txt',
        'doc/src/make_chm.py',
        'doc/src/lib/pie.jpg',
        'doc/src/lib/scatter.ps',
        'doc/src/lib/test.pdf',
        'doc/src/lib/bar.png',
        'doc/src/lib/file-web-xml.html',
        'BUGS.txt',
        'TODO.txt',
        'CHANGES.txt',
        'test.py',
        'web/external/PDBC/setup.py',
        'web/external/PDBC/database/external/SnakeSQL/setup.py',
    ]
    scriptDirs = [
        'scripts'
    ]
    excludeExtensions = ['.pyc','.csv','.dat','.pl','.hhc','.hhp','.hhk','.tex','.bat','Makefile','~']
    build = False
    pyVer = ''
    if not len(sys.argv)>1 or  sys.argv[1] == 'install':
        install(directory='web', name='web', scriptDirs=scriptDirs )
    elif sys.argv[1] == 'bdist':
        excludeDirs.pop(excludeDirs.index('doc/chm'))
        excludeFiles.append('doc/chm/make_chm.py')
        if not len(sys.argv) > 2:
            excludeDirs.append('web/external/build/win32-2_3')
            print __doc__
            print 'Error: Python version not specified'
            sys.exit(0)
        if sys.argv[2] == '2.2':
            excludeDirs.append('web/external/build/win32-2_3')
            excludeDirs.append('web/external/PDBC/database/external/build/win32-2_3')
        elif sys.argv[2] == '2.3':
            excludeDirs.append('web/external/build/win32-2_2')
            excludeDirs.append('web/external/PDBC/database/external/build/win32-2_2')
        else:
            raise Exception('Unsupported python version %s'%sys.argv[2])
        pyVer = sys.argv[2]
        build = True
    elif sys.argv[1] == 'sdist':
        excludeDirs.pop(excludeDirs.index('doc/html_multipage'))
        excludeDirs.append('web/external/build')
        excludeDirs.append('web/external/PIL')
        excludeFiles.append('web/external/drv_libxml2.py')
        excludeFiles.append('web/external/libxml2.py')
        excludeFiles.append('web/external/libxslt.py')
        excludeDirs.append('web/external/PDBC/database/external/build')
        excludeDirs.append('web/external/PDBC/database/external/MySQLdb')
        excludeDirs.append('web/external/PDBC/database/external/sqlite')
        excludeFiles.append('web/external/PDBC/database/external/CompatMysqldb.py')
        excludeFiles.append('web/external/PDBC/database/external/_mysql_exceptions.py')

        build = True
    else:
        print __doc__
    if build:
        archiveTypes = ['zip','gztar','bztar']#,'ztar','tar'],
        if pyVer:
            pyVer = '-win32-'+pyVer
            archiveTypes = ['zip']
        else:
            pyVer='-src'
        bdist(
            archiveName = 'PythonWeb.org-'+web.version+pyVer,
            dirName = 'PythonWeb.org',
            archiveTypes = archiveTypes,
            excludeExtensions = excludeExtensions,
            excludeAllDirs = ['CVS'],
            excludeDirs=excludeDirs,
            excludeFiles=excludeFiles,
        )
