"""Base PDBC driver

ToDo:

- Write commit() rollback() test.
- Write max
- Define how tableExists() deals with structureTableName
- Reload table structure (creating structure table if necessary) after every rollback()
"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import datetime, database, SnakeSQL, SQLParserTools

#
# Table and column classes
#

from SnakeSQL.driver.base import BaseTable, BaseColumn, BaseConverter, BaseStringConverter, BaseTextConverter
from SnakeSQL.driver.base import BaseBinaryConverter, BaseBoolConverter, BaseIntegerConverter, BaseLongConverter
from SnakeSQL.driver.base import BaseFloatConverter, BaseDateConverter, BaseDatetimeConverter, BaseTimeConverter


# Database classes
#

# Useage

#1. execute                                 passes to underlying cursor
#2. execute in portable mode                parsers and passes to the abstraction methods
#3. execute in portable abstraction mode    portably executes code

class Connection:

    def makeConnection(self, **params):
        raise Exception('This method should be overridden in the derived class')

    # Problems with tables and fetchall
    #~ def __getattr__(self, name):
        #~ return getattr(self._cursor,name)

    def __init__(self, driver, debug=False, structureTableName='StructureTable', createStructureTable=True, **params):
        self.baseConnection = self.makeConnection(**params)
        self.structureTableName = structureTableName
        self.converters = driver['converters']
        self.cursorClass = driver['cursorClass']
        self.tableClass = driver['tableClass']
        self.columnClass = driver['columnClass']
        self.parser = SQLParserTools.Transform()
        self.tables = {}
        self.debug = debug
        self._cursor = self.cursor()
        self.createStructureTable = createStructureTable
        self.loadStructureTable()

    def loadStructureTable(self):
        self.tables = {}
        if not self._cursor.tableExists(self.structureTableName, mode='direct'):
            #print self.baseConnection._tables()
            #print self.baseConnection._tables()
            #try:
            #    self._cursor.baseCursor.execute('select * from %s'%self.structureTableName)
            #except:
            #    pass
            #else:
            #    raise SnakeSQL.Bug("PDBC thinks table %s doesn't exist but it does."%table)
                
                
            if self.createStructureTable:  
                self._cursor.create(
                    table=self.structureTableName, 
                    columns = [
                        self._cursor.column(name='TableName', type='String', required=True),
                        self._cursor.column(name='ColumnName', type='String', required=True),
                        self._cursor.column(name='ColumnType', type='String', required=True),
                        self._cursor.column(name='IsRequired', type='Bool'),
                        self._cursor.column(name='IsUnique', type='Bool'),
                        self._cursor.column(name='IsPrimaryKey', type='Bool'),
                        self._cursor.column(name='ForeignKeyTable', type='Text'),
                        self._cursor.column(name='DefaultValue', type='Text'),
                        self._cursor.column(name='Position', type='Integer', required=True),
                    ],
                    execute=True,
                )
            else:
                raise Exception('Structure table %s does not exist and automatic creation of the table has been disabled'%repr(structureTableName))
        else:
            
            values = [
                [self.structureTableName, 'TableName',  'String', 1, 0, 0, None, None,0],
                [self.structureTableName, 'ColumnName', 'String', 1, 0, 0, None, None,1],
                [self.structureTableName, 'ColumnType', 'String', 1, 0, 0, None, None,2],
                [self.structureTableName, 'IsRequired',   'Bool',   0, 0, 0, None, None,3],
                [self.structureTableName, 'IsUnique',     'Bool',   0, 0, 0, None, None,4],
                [self.structureTableName, 'IsPrimaryKey', 'Bool',   0, 0, 0, None, None,5],
                [self.structureTableName, 'ForeignKeyTable', 'Text',   0, 0, 0, None, None,6],
                [self.structureTableName, 'DefaultValue',    'Text',   0, 0, 0, None, None,7],
                [self.structureTableName, 'Position',   'Integer',1, 0, 0, None, None,8],
            ]
            columns = []
            for value in values:
                columns.append(
                    self.columnClass(
                        table = value[0],
                        name = value[1],
                        type = value[2],
                        required = value[3],
                        unique = value[4],
                        primaryKey = value[5],
                        foreignKey = value[6],
                        default = value[7],
                        position = value[8],
                        converter = self.converters[value[2]],
                    )
                )
            self.tables[self.structureTableName] = self.tableClass(self.structureTableName, columns)
            
            self._cursor.select(
                columns=[
                    'TableName',
                    'ColumnName',
                    'ColumnType',
                    'IsRequired',
                    'IsUnique',
                    'IsPrimaryKey',
                    'ForeignKeyTable',
                    'DefaultValue',
                    'Position',
                ], 
                tables=self.structureTableName, 
                order='TableName, ColumnName',
                fetch=False,
                #where="TableName != '"+self.structureTableName+"'",
            )
            results = self._cursor.fetchall(format='dict')
            tables = {}
            for result in results:
                if result['TableName'] != self.structureTableName:
                    if not tables.has_key(result['TableName']):
                        tables[result['TableName']] = []
                    tables[result['TableName']].append(
                        self.columnClass(
                            table = result['TableName'],
                            name = result['ColumnName'],
                            type = result['ColumnType'].capitalize(),
                            required = result['IsRequired'],
                            unique = result['IsUnique'],
                            primaryKey = result['IsPrimaryKey'],
                            foreignKey = result['ForeignKeyTable'],
                            default = result['DefaultValue'],
                            converter = self.converters[result['ColumnType'].capitalize()],
                            position = result['Position'],
                        )
                    )
            for name, columns in tables.items():
                self.tables[name] = self.tableClass(name, columns)
            for name, table in self.tables.items():
                for column in table.columns:
                    if column.primaryKey:
                        self.tables[name].primaryKey = column.name
                    if column.foreignKey:
                        self.tables[column.foreignKey].childTables.append(name)
                        self.tables[name].parentTables.append(column.foreignKey)

    def close(self):
        return self.baseConnection.close()

    def commit(self):
        return self.baseConnection.commit()
        
    def rollback(self):
        r = self.baseConnection.rollback()
        #print self._cursor.tables()
        self.loadStructureTable()
        #print self._cursor.tables()
        return r

    def cursor(self, debug=None, convert=True, format='tuple', mode='portable', fetch=True, **params):
        if debug == None:
            debug = self.debug
        return self.cursorClass(
            cursor = self.baseConnection.cursor(**params), 
            connection = self, 
            debug = debug,
            convert=convert,
            format = format,
            mode = mode,
        )
        
class Cursor:
    "Base class for database adaptation layer"

    def __init__(self, cursor, connection, debug=False, convert=True, format='tuple', mode='portable', fetch=True):
        self.debug = debug
        self.format = format
        self.sql = []
        self.position = 0
        self.baseCursor = cursor
        self.connection = connection
        self.mode = mode
        self.info = None
        self.convert = convert
        self.fetch = fetch
        self.sql = []
        self.types = self._setupTypes()
        
    def _setupTypes(self):
        return {
            'Date':'Date',
            'Datetime':'Datetime',
            'Time':'Time',
            'Float':'Float',
            'Long':'Long',
            'String':'String',
            'Bool':'Bool',
            'Text':'Text',
            'Integer':'Integer'
        }
        
    def executeMany(self, sql, parameters=[], mode=None):
        for params in parameters:
            self.execute(sql, params, mode)

    def execute(self, sql, parameters=[], mode=None):
        operation = sql
        if (mode == None and self.mode == 'db-api2.0') or mode=='db-api2.0':
            self.info = None
            return self.baseCursor.execute(operation, parameters)
        else:
            if self.debug:
                self.sql.append(sql)
            if type(parameters) not in [type(()), type([])]:
                parameters = [parameters]
            parsedSQL = self.connection.parser.parse(operation)
            if parameters:
                parsedSQL['values'] = parameters
            if parsedSQL['function'] == 'create':
                del parsedSQL['function']
                return self.create(**parsedSQL)
            elif parsedSQL['function'] == 'drop':
                del parsedSQL['function']
                if len(parsedSQL['tables'])>1:
                    raise SnakeSQL.SQLSyntaxError('Only one table can be dropped at once')
                parsedSQL['table'] = parsedSQL['tables'][0]
                del parsedSQL['tables']
                return self.drop(**parsedSQL)
            elif parsedSQL['function'] == 'insert':
                del parsedSQL['function']
                return self.insert(**parsedSQL)
            elif parsedSQL['function'] == 'update':
                del parsedSQL['function']
                return self.update(**parsedSQL)
            elif parsedSQL['function'] == 'select':
                del parsedSQL['function']
                return self.select(fetch=False, **parsedSQL)
            elif parsedSQL['function'] == 'delete':
                del parsedSQL['function']
                return self.delete(**parsedSQL)
            elif parsedSQL['function'] == 'show':
                del parsedSQL['function']
                return self.tables(**parsedSQL)
            else:
                raise Exception("%s is not a supported SQL keyword."%parsedSQL['function'].upper())
        
    def fetchall(self, convert=True, format='tuple'):
        if self.info == None:
            raise Exception('Not supported')
            if convert == True or (convert == None and self.convert == True):
                raise Exception('No conversions can be done since the last execute() did not use compatibility mode SQL')
            else:
                raise Exception('No results to fetch')
        if convert == None:
            convert = self.convert
        results = self.baseCursor.fetchall()
        if convert:
            results = self._convertResults(results)
        #else:
        #    if format == None:
        #        format = self.format
        #print results
        if format == 'tuple':
            return results
        elif format == 'dict':
            final = []
            for result in results:
                fin = {}
                for i in range(len(result)):
                    fin[self.info[i].name] = result[i]
                final.append(fin)
            return tuple(final)
        else:
            raise Exception('Invalid format type %s for conversions'%format)

    def _convertResults(self, results):
        newresults = []
        for record in results:
            newrecord = []
            for i in range(len(record)):
                newrecord.append(self.info[i].converter.storageToValue(record[i]))
            newresults.append(tuple(newrecord))
        return tuple(newresults)

## Table information methods

    def tableExists(self, table, mode=None):
        if mode==None:
            mode=self.mode
        if mode == 'direct':
            #raise Exception('sad')
            return self._tableExists(table)
        else:
            #print table, self.connection.tables.has_key(table), self.connection.tables.keys()
            if self.connection.tables.has_key(table):
                if self.debug:
                    if self._tableExists(table):
                        return True
                    else:
                        raise Exception('Table %s does not exists but is in the table structure. %s'%(table, self.connection.tables.keys()))
                else:
                    return True
            else:
                if self.debug:
                    if self._tableExists(table):
                        raise Exception('Table %s exists but is not in the table structure. %s'%(table, self.connection.tables.keys()))
                    else:
                        return False
                else:
                    return False

    def _tableExists(self, table):

        try:
            self.baseCursor.execute("SELECT * FROM "+table+' where 3=4')
        except:
            #print str(sys.exc_info()[1])
            #~ if mode != 'dbapi2.0':
                #~ if self.connection.tables.has_key(table):
                    #~ raise SnakeSQL.Bug("The table %s doesn't actaully exist but is present in connection.tables()"%table)
            return False
        else:
            #~ if mode != 'dbapi2.0':
                #~ if not self.connection.tables.has_key(table):
                    #~ raise SnakeSQL.Bug("The table %s does actaully exist but isn't present in connection.tables()"%table)
            return True

    def columnExists(self, table, column, mode=None):
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            if not self.connection.tables.has_key(table):
                raise Exception('No such table %s'%repr(table))
            if self.connection.tables[table].has_key(column):
                return True
            else:
                return False
        else:
            try:
                self.baseCursor.execute("SELECT "+column+" FROM "+table+" WHERE 3=4")
                self.baseCursor.fetchall()
            except:
                return False
            else:
                return True

    def tables(self, mode=None):
        "Returns a list of strings of table names in the database including ColTypes"
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            return tuple(self.connection.tables.keys())
        else:
            return tuple(self._tables())
            
    def _tables(self):
        self.baseCursor.execute('SHOW TABLES')
        return self.baseCursor.fetchall()[0]
        
    def columns(self, table, mode=None):
        "Returns a list of all the column names for the table 'table'. Used if autoConvert='table'."
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            if not self.connection.tables.has_key(table):
                raise Exception('No such table %s'%repr(table))
            columns = []
            for column in self.connection.tables[table].columns:
                columns.append(column.name)
            return tuple(columns)
        else:
            raise Exception('Not Tested')
            self.baseCursor.execute("select * from "+table+" where 1=2")
            cols = []
            for col in self.baseCursor.description:
                cols.append(col[0])
            return tuple(cols)
        
## SQL statement generators

    def select(self, columns, tables, values=[], where=None, order=None, execute=None, fetch=None, **fetchParams):
        if fetch == None:
            fetch = self.fetch
        if fetch==True and execute==None:
            execute=True
        #if format == None:
        #    format = self.format
        #if convert == None:
        #    convert = self.convert
        if type(tables) == type(''):
            tables = [tables]
        if type(columns) == type(''):
            columns = [columns]
        if columns == ['*']:
            columns = []
            for table in tables:
                for col in self.columns(table):
                    if len(tables) == 1:
                        columns.append(col)
                    else:
                        columns.append(table+'.'+col)
        if where:
            table = None
            if len(tables) == 1:
                table = tables[0]
            if type(where) == type(''):
                where, used = self._where(where, values, table)
            else:
                if values:
                    self._checkWhereColumns(where, table)
                    where, used = self._substituteWhereValues(where, values, table)
                    if used < len(values):
                        raise Exception('Not enough ? parameters in WHERE clause or too many values specified')
                    elif used > len(values):
                        raise Exception('Not enough values to substitute for all ? parameters in WHERE clause')
        if type(order) == type(''):
            order = self.order(order)
        info = []
        if len(tables) == 1:
            if not self.tableExists(tables[0]):
                raise Exception("Table '%s' doesn't exist."%tables[0])
            for column in columns:
                if '.' in column:
                    raise Exception("Unexpected '.' character found in column name %s"%(repr(column)))
                else:
                    info.append(self.connection.tables[tables[0]].get(column))
        else:
            for column in columns:
                if '.' not in column:
                    raise Exception("Expected table name followed by '.' character before column name %s"%(repr(column)))
                else:
                    table, column = column.split('.')
                    if not self.tableExists(table):
                        raise Exception("Table '%s' doesn't exist."%table)
                    info.append(self.connection.tables[table].get(column))
        sql = self.connection.parser.buildSelect(tables, columns, where, order)
        if execute == False:
            return sql
        else:
            self.info = info
            self.baseCursor.execute(sql)
            if fetch:
                return self.fetchall(**fetchParams)
            else:
                return sql

    def insertMany(self, table, columns, values, sqlValues=[]):
        if type(values) not in [type([]), type((1))]:
            raise Exception("Values must be a sequence of sequences")
        for value in values:
            self.insert(table, columns, values=value, sqlValues=sqlValues, execute=True)
        
    def _checkUpdateConstraints(self, table, columns, internalValues):
        pass
    def _checkInsertConstraints(self, table, columns, internalValues):
        pass
        
    def insert(self, table, columns, values=[], sqlValues=[], execute=None):
        """sqlValues is a list of values as quoted SQL or ?, values is a list of values
        
        We can't use values = None as this is interpreted as values = [None] which is a valid value"""
        internalValues, columns, used = self._internalValues(table, columns, values, sqlValues)
        # Build SQL
        self._checkInsertConstraints(table, columns, internalValues)
        sql = self.connection.parser.buildInsert(table, columns, internalValues)
        if execute == False:                
            return sql
        else:
            self.info = None
            self.baseCursor.execute(sql)
            return sql

    def update(self, table, columns, values=[], sqlValues=[], where=None, execute=None):
        """sqlValues is a list of values as quoted SQL or ?, values is a list of values
        
        We can't use values = None as this is interpreted as values = [None] which is a valid value"""
        internalValues, columns, used = self._internalValues(table, columns, values, sqlValues)
        self._checkUpdateConstraints(table, columns, internalValues)
        usedagain = 0
        if where:
            if type(where) == type(''):
                where, usedagain = self._where(where, values[used:], table)
            else:
                self._checkWhereColumns(where, table)
                where, usedagain = self._substituteWhereValues(where, values[used:], table)
        if sqlValues:
            if used + usedagain < len(values):
                raise Exception('Not enough ? parameters or too many values specified')
            elif used + usedagain > len(values):
                raise Exception('Not enough values to substitute for all ? parameters')
        # Build SQL
        sql = self.connection.parser.buildUpdate(table, columns, internalValues, where)
        if execute == False:                
            return sql
        else:
            self.info = None
            self.baseCursor.execute(sql)
            return sql
            
    def _internalValues(self, table, columns, values, sqlValues):
        #raise Exception(sqlValues)
        # Check table exists
        if not self.tableExists(table):
            raise Exception("Table '%s' doesn't exist."%table)
        # Format the values
        if type(columns) == type(''):
            columns = [columns]
        if type(values) not in [type([]), type((1,))]:
            raise Exception("Expected 'values' to be a list or tuple of values not type %s"%str(type(values))[6:-1])
        if type(sqlValues) not in [type([]), type((1,))]:
            raise Exception("Expected 'sqlValues' to be a list or tuple of values not type %s"%str(type(sqlValues))[6:-1])
        info = []
        for column in columns:
            if '.' in column:
                raise Exception("Unexpected '.' character found in column name %s"%(repr(column)))
            else:
                info.append(self.connection.tables[table].get(column))
        # Get values in the correct format
        used = 0
        internalValues = []
        if len(sqlValues) == 0: # We are using values and they need to be converted
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise Exception("Table '%s' has no column named '%s'."%(table, columns[i]))
                internalValues.append(info[i].converter.valueToSQL(values[i]))
        elif len(sqlValues) == len(values) == 0:
            raise Exception('You must specify either values or sqlValues')
        elif len(values) == 0: # We are only using SQL values
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise Exception("Table '%s' has no column named '%s'."%(table, columns[i]))
                internalValues.append(info[i].converter.valueToSQL(info[i].converter.sqlToValue(sqlValues[i])))
            #internalValues = sqlValues
        else: # We are using both SQL and Python values, they need to be mixed
            if len(columns) != len(sqlValues):
                raise Exception('The number of sqlValues must match the number of columns, even if some values are \'?\'')
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise Exception("Table '%s' has no column named '%s'."%(table, columns[i]))
                if sqlValues[i] == '?':
                    if used == len(values):
                        raise Exception('The number of values must match the number of \'?\' terms in sqlValues')
                    internalValues.append(info[i].converter.valueToSQL(values[used]))
                    used += 1
                else:
                    value = info[i].converter.sqlToValue(sqlValues[i])
                    internalValues.append(info[i].converter.valueToSQL(value))
        return internalValues, columns, used

    def delete(self, table, values=[], where=None, execute=None):
        used = 0
        if where:
            if type(where) == type(''):
                where, used = self._where(where, values, table)
            else:
                self._checkWhereColumns(where, table)
                where, used = self._substituteWhereValues(where, values, table)
            if used < len(values):
                raise Exception('Not enough ? parameters in WHERE clause or too many values specified')
            elif used > len(values):
                raise Exception('Not enough values to substitute for all ? parameters in WHERE clause')
        if used < len(values):
            raise Exception('Not enough ? parameters or too many values specified')
        elif used > len(values):
            raise Exception('Not enough values to substitute for all ? parameters')
        sql = self.connection.parser.buildDelete(table, where)
        if execute == False:
            return sql
        else:
            self.info = None
            self.baseCursor.execute(sql)
            return sql

    def create(self, table, columns, values=[], execute=None): # XXX Needs values for parameter substitutions
       

        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # raise Exception('No values specified') (param substitution)
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        # XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxx
        
        f = []
        for column in columns:
            if type(column) == type(''):
                f.append(self.column(column))
            elif type(column) in [type((1,2)), type([])]: 
                # We are using the previous version of the modules
                if len(column) != 2:
                    raise SnakeSQL.DataError('The create statement no longer takes lists of tuples for column names unless they are length 2. Instead use .column() to build columns')
                f.append(self.column(name=column[0], type=column[1]))
            else:
                f.append(column)
        for column in f:
            for param in ['name','type','required','unique','primaryKey','foreignKey','default']:
                if not column.has_key(param):
                    raise SnakeSQL.DataError('Expected the parameter %s in the column dictionary'%(repr(param)))
            for name in ['name', 'type']:
                if type(column['name']) != type(''):
                    raise SnakeSQL.DataError('Column %ss should be strings. %s is not a valid value.'%(name, repr(column['name'])))
            if column['primaryKey'] and column['default'] <> None:
                raise Exception('A column cannot be a PRIMARY KEY and have a default value')
            if column['foreignKey'] and column['default'] <> None:
                raise Exception('A column cannot be a FOREIGN KEY and have a default value')
            if column['primaryKey'] and column['foreignKey']:
                raise Exception('A column cannot be a PRIMARY KEY and a FOREIGN KEY')
        sql = ['CREATE TABLE ']
        sql.append(table)
        sql.append(' (')
        sql.append(self._buildColumns(f))
        sql.append(')')
        sql = ''.join(sql)
        if execute == False:
            return sql
        else:
            values = []
            counter = 0
            columns = []
            for column in f:
                columns.append(
                    self.connection.columnClass(
                        table = table,
                        name = column['name'],
                        type = column['type'].capitalize(),
                        required = column['required'],
                        unique = column['unique'],
                        primaryKey = column['primaryKey'],
                        foreignKey = column['foreignKey'],
                        default = column['default'],
                        position = counter,
                        converter = self.connection.converters[column['type'].capitalize()],
                    )
                )
                values.append([table, column['name'], column['type'], column['required'], column['unique'], column['primaryKey'], column['foreignKey'], column['default'], counter])
                counter += 1
            #print sql
            self.info = None
            self.baseCursor.execute(sql)
            
            self.connection.tables[table] = self.connection.tableClass(table, columns)
            self.insertMany(
                table=self.connection.structureTableName,
                columns = ['TableName','ColumnName','ColumnType','IsRequired','IsUnique','IsPrimaryKey','ForeignKeyTable','DefaultValue','Position'],
                values = values
            )
            return sql
            
    def _buildColumns(self, columns):
        return self.connection.parser._buildColumns(columns)

    def drop(self, table, execute=None):
        "Remove a table from the database."
        
        sql = self.connection.parser.buildDrop(table)
        if execute == False:
            return sql
        else:
            self.info = None
            del self.connection.tables[table]
            self.baseCursor.execute(sql)
            return sql
            
## Builders

    """
    Note on where functions:
    If table is None it is assumed the where clause only applies to one table and hence the full tableName.columnName
    way of doing things is not being used.
    """
    def where(self, where, values=[], table=None):
        where, used = self._where(where, values, table)
        if len(values) > used:
            raise Exception('Not enough ? in WHERE clause or too many values sepcified')
        elif len(values) < used:
            raise Exception('Not enough values sepcified to substiture all ? params in WHERE clause')
        else:
            return where

    def _where(self, where, values=[], table=None):
        where = self.connection.parser._parseWhere(where)
        self._checkWhereColumns(where, table)
        where, used = self._substituteWhereValues(where, values, table)
        return where, used
        
    def _checkWhereColumns(self, where, table=None):
        for block in where:
            if type(block) == type([]):
                if table == None: # We are using multiple tables
                    if block[0].count('.') == 1:
                        table, column = block[0].split('.')
                        if not self.tableExists(table):
                            raise Exception('Table %s specified in WHERE clause does not exist'%repr(table))
                        elif not self.columnExists(table, column):
                            raise Exception('Column %s in table %s specified in WHERE clause does not exist'%(repr(column),repr(table)))
                    else:
                        raise Exception('Invalid column %s in WHERE clause, expected format tableName.columnName since using multiple tables'%(repr(block[0])))
                else:
                    column = block[0]
                    if column.count('.') > 0:
                        #raise Exception('Invalid column %s in WHERE clause, expected format tableName.columnName since using multiple tables'%(repr(column)))
                        table, column = block[0].split('.')
                        if not self.tableExists(table):
                            raise Exception('Table %s specified in WHERE clause does not exist'%repr(table))
                        elif not self.columnExists(table, column):
                            raise Exception('Column %s in table %s specified in WHERE clause does not exist'%(repr(column),repr(table)))
                    else:
                        if not self.tableExists(table):
                            raise Exception('Table %s specified in WHERE clause does not exist'%repr(table))
                        elif not self.columnExists(table, column):
                            raise Exception('Column %s in table %s specified in WHERE clause does not exist'%(repr(column),repr(table)))
        return True

    def _substituteWhereValues(self, where, values, table=None):
        used = 0
        for block in where:
            if type(block) == type([]):
                if block[2] == '?':
                    if block[1].lower() in ['is', 'is not'] and values[used] <> None:
                        raise Exception('NULL is the only value that can be used after the %s operator in the WHERE clause, not %s'%(repr(block[1].upper()), repr(values[used])))
                    if len(values) <= used:
                        raise Exception('Not enough values to replace ? in WHERE clause')
                    else:
                        if table <> None: # Single table
                            column = block[0]
                            block[2] = self.connection.tables[table].get(column).converter.valueToSQL(values[used])
                        elif '.' in block[0]:
                            table, column = block[0].split()
                            block[2] = self.connection.tables[table].get(column).converter.valueToSQL(values[used])
                        else:
                            raise Exception('Invalid column %s in WHERE clause, expected format tableName.columnName since using multiple tables'%(repr(block[0])))
                        used += 1
        return where, used

    def order(self, order):
        # XXX Chcek values
        return self.connection.parser._parseOrder(order)
        
    def column(self, **params):
        values = {
            'name':None,
            'type':None,
            'required':0,
            'unique':0,
            'primaryKey':0,
            'foreignKey':None,
            'default':None,
        }
        for param in params:
            if not param in values.keys():
                raise Exception('Invalid parameter %s for column definition'%repr(param))
        for key in params.keys():
            values[key] = params[key]
        if values['name'] == None:
            raise SnakeSQL.InterfaceError("Parmeter 'name' not specified correctly for the column")
        if values['type'] == None:
            raise SnakeSQL.InterfaceError("Parmeter 'name' not specified correctly for the column")
        if values['primaryKey'] and values['default'] <> None:
            raise SnakeSQL.InterfaceError("A PRIMARY KEY column cannot also have a default value")
        if values['primaryKey'] and values['foreignKey'] <> None:
            raise SnakeSQL.InterfaceError("A PRIMARY KEY column cannot be a FOREIGN KEY value")
        if values['default'] and values['foreignKey'] <> None:
            raise SnakeSQL.InterfaceError("A FOREIGN KEY column cannot also have a default value")
        for i in ['required', 'unique', 'primaryKey']:
            if values[i] not in [0,1,True,False]:
                raise SnakeSQL.DataError("%s can be True or False, not %s"%([i],repr(values[i])))
        values['type'] = values['type'].capitalize()
        if values['type'].capitalize() not in self.types.keys():
            raise SnakeSQL.DataError("%s is not a recognised type"%(values['type'].capitalize()))
        if values['primaryKey'] and values['type'].upper() not in SQLParserTools.primaryKeyTypes:
            raise SnakeSQL.DataError("%s columns cannot be used as PRIMARY KEYs"%values['type'].capitalize())
        if values['default'] <> None and values['type'].upper() not in SQLParserTools.noDefaults:
            raise SnakeSQL.DataError("%s columns cannot be have a DEFAULT value"%values['type'].capitalize())
        # XXX Type checking of default done later.
        # XXX Extra fields error
        return values
        # XXX Check foreign key details.
        
    def _function(self, type, table, column, where=None, values=[]):
        results = self.select(columns=[column], tables=[table], fetch=True, convert=True, format='tuple', where=where, values=values)
        if not results:
            return None
        else:
            if type=='max':
                r = max(results)
                return r[0]
            elif type=='min':
                r = min(results)
                return r[0]
            elif type == 'count':
                return len(results)
            else:
                raise Exception('Not implemented')
            
    def max(self, table, column, where=None, values=[]):
        return self._function('max', table, column, where)

    def min(self, table, column, where=None, values=[]):
        return self._function('min', table, column, where)
        
    def count(self, table, column, where=None, values=[]):
        return self._function('count', table, column, where, values)
        
        