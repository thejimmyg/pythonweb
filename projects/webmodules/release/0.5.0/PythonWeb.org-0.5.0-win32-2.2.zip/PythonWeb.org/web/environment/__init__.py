"""Tools for preparing an environment for the web modules"""

from web.errors import EnvironmentError

def driver(name='', storage='database', **params):
    if storage not in ['database']:
        raise web.errors.EnvironmentError("%s is not a valid environment type."%(repr(storage)))
        
    from web.session.drivers.database import DatabaseSessionEnvironmentDriver
    from web.auth.drivers.database    import DatabaseAuthEnvironmentDriver
    
    class Environment(DatabaseSessionEnvironmentDriver, DatabaseAuthEnvironmentDriver):

        def createEnvironment(self):
            errors = []
            authErrors = self.createAuthEnvironment()
            sessionErrors = self.createSessionEnvironment()
            if authErrors:
                for error in authErrors:
                    errors.append(error)
            if sessionErrors:
                for error in sessionErrors:
                    errors.append(error)
            if errors:
                raise EnvironmentError(' '.join(errors))
            
        def removeEnvironment(self, ignoreErrors=True):
            errors = []
            authErrors = self.removeAuthEnvironment(ignoreErrors)
            sessionErrors = self.removeSessionEnvironment(ignoreErrors)
            if authErrors:
                for error in authErrors:
                    errors.append(error)
            if sessionErrors:
                for error in sessionErrors:
                    errors.append(error)
            if errors and not ignoreErrors:
                raise EnvironmentError(' '.join(errors))
            
        def completeEnvironment(self):
            if self.completeAuthEnvironment() and self.completeSessionEnvironment():
                return 1
            else:
                return 0

        
    return Environment(name=name, **params)