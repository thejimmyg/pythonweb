#!/usr/bin/env python

import sys; sys.path.append('../../../') # show python where the web modules are
import web.template

dict =  {
    'welcomeMessage':'Welcome to the test page!',
    'testVar':True,
    'title':'Cheetah Example',
}

print web.template.parse(
    type='cheetah', 
    file='file-web-template-cheetah.tmpl', 
    dict=dict
)