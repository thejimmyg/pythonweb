"Useful WSGI Base Classes"

class BaseApplication:
    "Easy HTML application building"
    def __call__(self, environ, start_response):
        self.status = '200 OK'
        self.headers = [('content-type','text/html')]
        self._output = []
        self.environ = environ
        self.start()
        start_response(self.status, self.headers)
        return self._output
        
    def start(self):
        raise Exception('The start() method should be over-ridden in a derived class')
        
    def output(self, *text):
        for item in text:
            self._output.append(str(item))

class BaseMiddleware:
    "Easy middleware building"

    def __init__(self, application):
        self.application = application

    def __call__(self, environ, start_response):
        def app(environ, start_response):
            environ = self.environ(environ)
            def new_response(status, headers, exc_info=None):
                return start_response(*self.response(status, headers, exc_info))
            return self.application(environ, new_response)
        return app(environ, start_response)

    def environ(self, environ):
        "This method allows you to make changes to environ. You should return the environ dictionary"
        return environ

    def response(self, status, headers, exc_info):
        "This method defines the order in which the response parameters are returned"
        status = self.status(status)
        headers = self.headers(headers)
        exc_info = self.exc_info(exc_info)
        return status, headers, exc_info

    def status(self, status):
        "This method allows you to make changes to status. You should return status"
        return status
        
    def headers(self, headers):
        "This method allows you to make changes to headers. You should return headers"
        return headers
        
    def exc_info(self, exc_info):
        "This method allows you to make changes to exc_info. You should return exc_info"
        return exc_info
        
        