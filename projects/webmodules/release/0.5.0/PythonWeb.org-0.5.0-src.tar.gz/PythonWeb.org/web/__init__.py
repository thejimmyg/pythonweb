"""Python Web Modules - http://pythonweb.org/

Summary:        

    Fully object-orientated Python modules designed to make web
    programming easy and intuitive.
                
Author:         

    James Gardner <james@jimmyg.org>

Documentation:  

    Can be found in the ``doc/html`` directory of the source distribution. 

Licence:        

    The parts of this software written by James Gardner are released 
    under the LGPL.

    All software in the ``web/external`` directory is released 
    under its own licence available at ``doc/html/licence/licence.html``

    Python Web Modules - http://www.pythonweb.org
    Copyright (C) 2002-2005 James Gardner

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Installation:

    python setup.py install
"""

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)

# Version Info
version_info = (0,5,0,'','beta')
version = '%s.%s.%s%s'%(version_info[0],version_info[1],version_info[2],version_info[3])
name = 'PythonWeb.org'
date = '2004-09-13'
status = version_info[4]

# Set up the paths
import sys, os.path
#~ if sys.version_info < (2,2):
    #~ path = os.path.join(__path__[0],'compat','2_2')
    #~ if path not in sys.path:
        #~ sys.path.insert(0,path)
if sys.version_info < (2,3):
    path = os.path.join(__path__[0],'compat','2_3')
    if path not in sys.path:
        sys.path.insert(0,path)
path = os.path.join(__path__[0],'external')
if path not in sys.path:
    sys.path.insert(0,path)
path = os.path.join(__path__[0],'external','PDBC')
if path not in sys.path:
    sys.path.insert(0,path)
path = os.path.join(__path__[0],'external','build',sys.platform+'-'+sys.version[:3].replace('.','_'))
if path not in sys.path:
    sys.path.insert(0,path)
del path

# Set up the cgi variable

# Martin Blais fix for mod_python importing cgi
# XXX Not tested, unsure of result.
try:
    sys.argv
except AttributeError:
    sys.argv = ['']
import cgi as cgimodule
# End Martin Blais fix for mod_python importing cgi

cgi = cgimodule.FieldStorage(keep_blank_values=1)

# Define global functions
def header(type='text/html'):
    "Returns an HTTP header"
    return "Content-type: %s\n\n" % (type)
    
def encode(html, mode='url'):
    "Encode a string for use in a URL"
    html = str(html)
    if mode == 'url':
        conv = {
            "$":'24',
            "&":'26',
            "+":'2B',
            ",":'2C',
            "/":'2F',
            ":":'3A',
            ";":'3B',
            "=":'3D',
            "?":'3F',
            "@":'40',
            "{":'7B',
            "}":'7D',
            "|":'7C',
            "\\":'5C',
            "^":'5E',
            "~":'7E',
            "[":'5B',
            "]":'5D',
            "`":'60',
            " ":'20',
            '"':'22',
            "<":'3C',
            ">":'3E',
            "#":'23',
            '\n':'0A',
            '\r':'0D',
        }
        html = html.replace('%','%25')
        for k,v in conv.items():
            html = html.replace(k,'%'+v)
    elif mode == 'form':   
        conv = {
            '"':'&quot;',
            "<":'&lt;',
            ">":'&gt;',
        }
        for k,v in conv.items():
            html = html.replace(k,v)
        
    else:
        raise Exception("'%s' is not a valid mode."%mode)
        
    return html
    
        
