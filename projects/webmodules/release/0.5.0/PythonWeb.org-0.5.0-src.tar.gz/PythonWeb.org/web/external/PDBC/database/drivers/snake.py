"""Snake PDBC driver

Can be improved if converters don't convert from database (already done!)
"""
import base

converters = {
        'String':   base.BaseStringConverter(),
        'Text':     base.BaseTextConverter(),
        'Binary':   base.BaseBinaryConverter(),
        'Bool':     base.BaseBoolConverter(),
        'Integer':  base.BaseIntegerConverter(),
        'Long':     base.BaseLongConverter(),
        'Float':    base.BaseFloatConverter(),
        'Date':     base.BaseDateConverter(),
        'Datetime': base.BaseDatetimeConverter(),
        'Time':     base.BaseTimeConverter(),
}

class Connection(base.Connection):

    def makeConnection(self, **params):
        import SnakeSQL 
        return SnakeSQL.connect(**params)
        
class Cursor(base.Cursor):
    
    def _tableExists(self, table):
        if self.connection.baseConnection.tables.has_key(table):
            return True
        else:
            return False

    def fetchall(self, **params):
        params['convert'] = False
        return base.Cursor.fetchall(self, **params)

driver = {
    'converters':converters,
    'columnClass':base.BaseColumn,
    'tableClass':base.BaseTable,
    'cursorClass':Cursor,
}