"""PDBC -- SQL database layer

Points to note:

    - Results aren't always automatically committed but sometimes are
    - You can alter the fetch and execute modes

    - Seconds must be whole seconds.

    - Should be able to call the ColTypes table something else and block the use of the name ColTypes.
    - Important to commit() changes before and after creating/altering/dropping code."""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)

# Version Info
version_info = (0,5,0,'','alpha')
version = '%s.%s.%s-%s'%(version_info[0],version_info[1],version_info[2],version_info[4])
name = 'PDBC'
date = '2005-01-03'
status = version_info[4]

# Set up the paths
import sys, os.path
if sys.version_info < (2,3):
    path = os.path.join(__path__[0],'compat','2_3')
    if path not in sys.path:
        sys.path.insert(0,path)
path = os.path.join(__path__[0],'external')
if path not in sys.path:
    sys.path.insert(0,path)
path = os.path.join(__path__[0],'external','SnakeSQL')
if path not in sys.path:
    sys.path.insert(0,path)
path = os.path.join(__path__[0],'external','SnakeSQL','SnakeSQL','external')
if path not in sys.path:
    sys.path.insert(0,path)
path = os.path.join(__path__[0],'external','build',sys.platform+'-'+sys.version[:3].replace('.','_'))
if path not in sys.path:
    sys.path.insert(0,path)
del path

def connect(adapter, structureTableName='StructureTable', createStructureTable=True, **params):
    """Empty params can be specified or params which aren't used."""  
    if adapter.lower() == 'mysql':
        import drivers.mysql as driver
    elif adapter.lower() == 'snakesql':
        import drivers.snake as driver
    elif adapter.lower() == 'odbc':
        raise Exception('Not implemented yet')
        import drivers.odbc as driver
    elif adapter.lower() == 'sqlite':
        import drivers.SQLite as driver
    else:
        raise Exception('Unknown datbase type %s'%(repr(type)))
    return driver.Connection(
        structureTableName=structureTableName,
        driver = driver.driver,
        createStructureTable = createStructureTable,
        **params
    )
