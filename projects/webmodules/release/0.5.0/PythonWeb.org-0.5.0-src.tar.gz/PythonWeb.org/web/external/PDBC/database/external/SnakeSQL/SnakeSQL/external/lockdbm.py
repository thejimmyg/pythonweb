"""DBM database based on dumbdbm with built-in file locks
so that only one person can read or modify the data at once.


Note:

Python 2.1 doesn't support the mode parameter.
"""

# Imports
import sys, dumbdbm, lock, os, random

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)
    
# Python 2.1 os.extsep
try:
    extsep = os.extsep
except AttributeError:
    extsep = '.'

_open = open
# Lock DBM
class Database(dumbdbm._Database):
    def __init__(self, file, mode, warn, packProb=0.005):
        if '.' in file:
            raise NameError("Database names should not contain '.' characters.")
        self.locks = lock.Lock(expire=2, timeout=10, warn=warn)
        self.locks.lock(file + extsep + 'dir')
        self.locks.lock(file + extsep + 'dat')
        self.locks.lock(file + extsep + 'bak')
        if sys.version_info < (2,2):
            dumbdbm._Database.__init__(self, file)
        else:
            dumbdbm._Database.__init__(self, file, mode)
        self._keysNeedReloading = True
        self._keys = []
        self.file = file
        if random.random() < packProb:
            self.pack()

    def pack(self):
        newfile = self.file+'.new'
        if os.path.exists(newfile):
            os.remove(newfile)
        new = dumbdbm.open(newfile)
        for key in self.keys():
            new[key] = self[key]
        new.close()
        for ext in ['.dir','.dat','.bak']:
            if os.path.exists(self.file+ext):
                if not os.path.exists(newfile+ext):
                    fp = _open(newfile+ext, 'w')
                    fp.close()
                os.remove(self.file+ext)
                os.rename(newfile+ext,self.file+ext)
            elif ext != '.bak':
                raise Exception('Expected %s file'%(repr(self.file+ext)))
        #print "packed"
        
    def __getitem__(self, name):
        for file in self.locks.files.keys():
            if not self.locks.isLocked(file):
                raise lock.LockError('Lock no longer valid.')
        else:
           return dumbdbm._Database.__getitem__(self, name)

    def __setitem__(self, name, value):
        for file in self.locks.files.keys():
            if not self.locks.isLocked(file):
                raise lock.LockError('Lock no longer valid.')
        else:
            if name not in self._keys:
                self._keys.append(name)
            return dumbdbm._Database.__setitem__(self, name, value)
           
    def __delitem__(self, name):
        for file in self.locks.files.keys():
            if not self.locks.isLocked(file):
                raise lock.LockError('Lock no longer valid.')
        else:
            self._keys.pop(self._keys.index(name))
            return dumbdbm._Database.__delitem__(self, name)
            
    def _loadKeys(self):
        self._keys = []
        try:
            f = _open(self._dirfile)
        except IOError:
            pass
        else:
            while 1:
                line = f.readline().rstrip()
                if not line: break
                key, (pos, siz) = eval(line)
                self._keys.append(key)

    def keys(self):
        "Over-ride keys to provide the keys in the correct order"
        if self._keysNeedReloading:
            self._loadKeys()
            self._keysNeedReloading = False
        return self._keys

    def commit(self):
        for file in self.locks.files.keys():
            self.locks.commit(file)
        self._keysNeedReloading = True
            
    def rollback(self):
        for file in self.locks.files.keys():
            self.locks.rollback(file)
        self._keysNeedReloading = True

    def close(self,commit=False):
        res = dumbdbm._Database.close(self)
        if commit:
            self.commit()
        else:
            self.rollback()
        self.locks.__del__()

    def __del__(self):
        self.rollback()
        
    def sync(self):
        dumbdbm._Database.sync(self)
        self.loadKeys()
        
def open(file, flag=None, mode=None, warn=False):
    if not os.path.exists(file+'.dir') or not os.path.exists(file+'.dat') or not os.path.exists(file+'.bak'):
        if sys.version_info < (2,2):
            if mode <> None:
                raise Exception("'mode' parameter not supported in Python < 2.2")
            fp = dumbdbm._Database(file)
            fp.close()
            fp = dumbdbm._open(file+'.bak','w')
            fp.close()
        else:
            if mode == None:
                mode = 0666
            fp = dumbdbm._Database(file, mode)
            fp.close()
            fp = dumbdbm._open(file+'.bak','w')
            fp.close()
    if mode == None:
        mode = 0666
    return Database(file, mode, warn)