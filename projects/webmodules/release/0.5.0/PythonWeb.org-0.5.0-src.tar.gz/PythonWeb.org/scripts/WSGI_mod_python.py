"""UNTESTED mod_python WSGI integration

XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                  WARNING NOT TESTED
                (Found on mailing list)
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

Sample httpd.conf for Apache

<Directory D:\htdocs\myprog>
  PythonHandler wsgiref.handlers::ModPyHandler.run_app
  PythonOption application myproggie.startup::get_wsgi_app
  # These options are required if you're using a version of mod_python < 3.1
  # multithread = On
  # multiprocess = Off
</Directory>
"""

class ModPythonInputWrapper(object):
    
    def __init__(self, req):
        self.req = req
    
    def read(self, size=-1):
        return self.req.read(size)
    
    def readline(self):
        return self.req.readline()
    
    def readlines(self, hint=-1):
        return self.req.readlines(hint)
    
    def __iter__(self):
        return iter(self.req.readlines())

import sys
from wsgiref.handlers import BaseCGIHandler

class ModPyHandler(BaseCGIHandler):
    
    def __init__(self, req):
        from mod_python import apache
        options = req.get_options()
        
        try:
            q = apache.mpm_query
        except AttributeError:
            # Threading and forking
            threaded = options.get('multithread', '')
            forked = options.get('multiprocess', '')
            if not (threaded and forked):
                raise ValueError("You must provide 'multithread' and "
                                 "'multiprocess' PythonOptions when "
                                 "running mod_python < 3.1")
            threaded = threaded.lower() in ('on', 't', 'true', '1')
            forked = forked.lower() in ('on', 't', 'true', '1')
        else:
            threaded = q(apache.AP_MPMQ_IS_THREADED)
            forked = q(apache.AP_MPMQ_IS_FORKED)
        
        req.add_common_vars()
        env = req.subprocess_env.copy()
        
        if req.path_info:
            env["SCRIPT_NAME"] = req.uri[:-len(req.path_info)]
        else:
            env["SCRIPT_NAME"] = req.uri
        
        env["GATEWAY_INTERFACE"] = "Python-CGI/1.1"
        
        if req.headers_in.has_key("authorization"):
            env["HTTP_AUTHORIZATION"] = req.headers_in["authorization"]
        
        BaseCGIHandler.__init__(self,
                                stdin=ModPythonInputWrapper(req),
                                stdout=None,
                                stderr=sys.stderr,
                                environ=env,
                                multiprocess=forked,
                                multithread=threaded
                                )
        self.request = req
        self._write = req.write
        
        config = req.get_config()
        debug = int(config.get("PythonDebug", 0))
        
        modname, objname = options['application'].split('::')
        module = apache.import_module(modname, autoreload=False, log=debug)
        self.app = apache.resolve_object(module, objname, arg=None, silent=False)
    
    def run_app(self, req):
        self.run(self.app)
        return 0 # = apache.OK
    
    def _flush(self):
        pass
    
    def send_headers(self):
        self.cleanup_headers()
        self.headers_sent = True
        self.request.status = int(self.status[:3])
        for key, val in self.headers.items():
            self.request.headers_out[key] = val
