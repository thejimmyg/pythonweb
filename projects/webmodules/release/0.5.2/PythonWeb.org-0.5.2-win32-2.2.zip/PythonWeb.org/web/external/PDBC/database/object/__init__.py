"""web.database.object -- An object relation mapper built on the web.database and web.form modules"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

"""NB. For all cols any dictionary passed to valid() will be treated as valid() and the value not checked.
Not sure about type({}) is type({}) always returning True."""

#################################################################################################################
#
# Constants
#

sqlReservedWords = [
    'ADD',
    'ALL',
    'ALTER',
    'AND',
    'ANY',
    'AS',
    'ASC',
    'AUTOINCREMENT',
    'AVA',
    'BETWEEN',
    'BINARY',
    'BIT',
    'BOOLEAN',
    'BY',
    'CREATE',
    'BYTE',
    'CHAR',
    'CHARACTER',
    'COLUMN',
    'CONSTRAINT',
    'COUNT',
    'COUNTER',
    'CURRENCY',
    'DATABASE',
    'DATE',
    'DATETIME',
    'DELETE',
    'DESC',
    'DISALLOW',
    'DISTINCT',
    'DISTINCTROW',
    'DOUBLE',
    'DROP',
    'EXISTS',
    'FROM',
    'FLOAT',
    'FLOAT4',
    'FLOAT8',
    'FOREIGN',
    'GENERAL',
    'GROUP',
    'GUID',
    'HAVING',
    'INNER',
    'INSERT',
    'IGNORE',
    'IMP',
    'IN',
    'INDEX',
    'INT',
    'INTEGER',
    'INTEGER1',
    'INTEGER2',
    'INTEGER4',
    'INTO',
    'IS',
    'JOIN',
    'KEY',
    'LEFT',
    'LEVEL',
    'LIKE',
    'LOGICAL',
    'LONG',
    'LONGBINARY',
    'LONGTEXT',
    'MAX',
    'MEMO',
    'MIN',
    'MOD',
    'MONEY',
    'NOT',
    'NOW',
    'NULL',
    'NUMBER',
    'NUMERIC',
    'OLEOBJECT',
    'ON',
    'PIVOT',
    'OPTION',
    'PRIMARY',
    'ORDER',
    'OUTER',
    'OWNERACCESS',
    'PARAMETERS',
    'PERCENT',
    'REAL',
    'REFERENCES',
    'RIGHT',
    'SELECT',
    'SET',
    'SHORT',
    'SINGLE',
    'SMALLINT',
    'SOME',
    'STDEV',
    'STDEVP',
    'STRING',
    'SUM',
    'TABLE',
    'TABLEID',
    'TEXT',
    'TIME',
    'TIMESTAMP',
    'TO',
    'TOP',
    'TRANSFORM',
    'UNION',
    'UNIQUE',
    'UPDATE',
    'VALUE',
    'VALUES',
    'VAR',
    'VARBINARY',
    'VARCHAR',
    'VARP',
    'WHERE',
    'WITH',
    'YESNO',
]
reservedWords = [
    'ROWID',
]
for word in sqlReservedWords:
    reservedWords.append(word)


#################################################################################################################
#
# Imports
#


import web.form, web.form.field.typed, web.form.field.extra, web.database, web.util
# Timestamp, DateFromTicks, TimeFromTicks, TimestampFromTicks Not needed

# import from standard modules
import copy
from types import InstanceType

# import our _driver
import drivers.database as _driver

#################################################################################################################
#
# Errors
#

from web.errors import DatabaseObjectError
    
#################################################################################################################
#
# Query Objects
#



class QueryBuilder:
    
    def AND(self, first, last):
        return Query(str(first)+" AND " + str(last), self.table)
        
    def OR(self, first, last):
        return Query(str(first)+" OR " + str(last), self.table)

    def NOT(self, first):
        return Query('NOT '+str(first), self.table)

    #~ def NOW(self):
        #~ return Query("NOW", self.table)
        
    #~ def LIKE(self, pattern):
        #~ return Query("LIKE " + str(pattern), self.table)
        
    #~ def BETWEEN(self, first, last):
        #~ return Query("BETWEEN " + str(first) + ' AND ' + str(last), self.table)

    def __init__(self, fields, table):
        self.__dict__['_fields'] = fields
        self.__dict__['table'] = table
        
    def __setitem__(self, name, value):
        raise DatabaseObjectError('You can\'t set values.')
        
    def __getitem__(self, name):
        for col in self._fields:
            if col.name() == name:
                return Query(name, self.table, type=col)
        raise DatabaseObjectError("Column named '%s' not found."%name)
        
    def __repr__(self):
        fieldNames = []
        for col in self._fields:
            fieldNames.append(col.name())
        return "<QueryBuilder instance: '%s'>"%(', '.join(fieldNames))
        
class Query:

    def __init__(self, name, table, list=[], type='mixed'):
        self.type = type
        self.name = name
        self.table = table
        self.list = list
        self.param = '%s'
        self.operators =    {
                                '<':'<',
                                '<=':'<=',
                                '==':'=',
                                '<>':'<>',
                                '>':'>',
                                '>=':'>=',
                                '&':' AND ',
                                '|':' OR ',
                                '~':' NOT ',
                                #'abs':'ABS',
                                '**':'POW',
                                '%':'MOD',
                                '+':'+',
                                '-':'-',
                                '*':'*',
                                '/':'/',
                            }
                            
    def merge(self,name,list):
        newList = []
        for l in list:
            if type(l) in[type(1), type(1.0004), type(1L)]:
                newList.append(str(l))
            elif l == None:
                newList.append('NULL')
            else: # Assume string or can be converted to string type.
                newList.append("'"+str(l)+"'")
        return name%tuple(newList)
        
        # XXX NEW RULE... Any derived ColType must use a class constructor.. that way we know how to 
        # handle them in this constructor. eg Email('james@jimmyg.org') rather than 'james@jimmyg.org' which
        # would be handled like a string.
        
    def __str__(self):
        return self.merge(self.name, self.list)
        
    def __repr__(self):
        return "<Query instance: '%s'>"%self.merge(self.name, self.list)
    
    def checkTypes(self, left, right):
        if type(left) == InstanceType and left.__class__.__name__ == 'Query':
            if left.type.valid(right, True) or right == None:
                return True
            else:
                raise TypeError("'%s' is not a valid value for '%s' fields."%(right, left.type.name()))
        raise TypeError("Column names should be Query() objects not '%s'."%type(left))
        
    def operator(self, left, right, operator):
        list = []
        leftString = ''
        rightString = ''
        for l in left.list:
            list.append(l)
        leftString = left.name
        if type(right) == InstanceType and right.__class__.__name__ == 'Query':
            for l in right.list:
                list.append(l)
            rightString = right.name()
        else:
            if self.checkTypes(left, right):
                list.append(right)
                rightString = self.param
            else:
                raise TypeError("'%s' columns should have values of type '%s' not '%s'."%(left.name, left.type, type(right)))
        output = '(' + self.table + '.' + leftString + ' ' + self.operators[operator] + ' ' + rightString +')'
        return Query(output, self.table, list)
        
    def logical(self, left, right, operator):
        list = []
        leftString = ''
        rightString = ''
        for l in left.list:
            list.append(l)
        leftString = left.name
        if type(right) == type(Query('',self.table,())): # XXX More checking reqired
            for l in right.list:
                list.append(l)
            rightString = right.name
        else:
            list.append(right)
            rightString = self.param
        output = '(' + leftString + ' ' + self.operators[operator] + ' ' + rightString +')'
        return Query(output, self.table, list)
        
    def prepend(self, right, operator):
        return Query('('+ self.operators[operator] + ' ' + str(right.name) +')',self.table, right.list) 

    #
    # Comparison Operators
    # <,<=,==,<>,>,>=
    #
    
    def __lt__(self, other):
        return self.operator(self, other, '<')
    def __le__(self, other):
        return self.operator(self, other, '<=')
    def __eq__(self, other):
        return self.operator(self, other, '==')
    def __ne__(self, other):
        return self.operator(self, other, '<>')
    def __gt__(self, other):
        return self.operator(self, other, '>')
    def __ge__(self, other):
        return self.operator(self, other, '>=')
    
    #
    # Logical Operators
    # &,|,~
    #
    
    def __and__(self, other):
        return self.logical(self, other, '&')
    def __or__(self, other):
        return self.logical(self, other, '|')
    def __invert__(self): # WARNING: This one is diferent
        return self.prepend(self, '~')

    #
    # Numeric Operators
    # +,-,*,/,**,%,#abs()
    #
    
    def __add__(self, other):
        return self.operator(self, other, '+')
    def __sub__(self, other):
        return self.operator(self, other, '-')
    def __mul__(self, other):
        return self.operator(self, other, '*')
    def __div__(self, other):
        return self.operator(self, other, '/')
    def __pow__(self, other):
        return self.operator(self, other, '**')
    def __mod__(self, other):
        return self.operator(self, other, '%')


#################################################################################################################
#
# fields
#

        
class String(web.form.field.typed.String):
    """A field for stings of 255 characters or less."""

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=40, treatNullStringAsNone=True, unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.String.__init__(self, name, default, description, error, required, requiredError, size, treatNullStringAsNone)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.String.valid(self, value):
            return True
        else:
            return False

    def type(self):
        return "String"

    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class StringSelect(web.form.field.typed.StringSelect):
    """StringSelect Field."""
        
    def __init__(self, name, options, default=[], description='', error='', required=False, requiredError='Please enter a value', displayNoneAs='', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.StringSelect.__init__(self, name,  options, default, description, error, required, requiredError, displayNoneAs)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.StringSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "String"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver
        
    def _setTable(self, table):
        "Set the database table."
        self.table = table

class Bool(web.form.field.typed.Bool):
    """Bool Field."""
        
    def __init__(self, name, default=[], description='', error='', required=False, requiredError='Please enter a value', displayNoneAs='', displayTrueAs='True', displayFalseAs='False'):
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        self.__dict__['unique'] = False
        self.__dict__['uniqueError'] = ''
        self.__dict__['key'] = False
        return web.form.field.typed.Bool.__init__(self, name, default, description, error, required, requiredError, displayNoneAs, displayTrueAs, displayFalseAs)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if web.form.field.typed.StringSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Bool"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver
        
    def _setTable(self, table):
        "Set the database table."
        self.table = table

class Text(web.form.field.typed.Text):
    """Char Field."""
        
    def __init__(self, name, default=None, description='', error='', cols=None, rows=None, required=False, requiredError='Please enter a value', treatNullStringAsNone=True, unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Text.__init__(self, name, default, description, error, cols, rows, required, requiredError, treatNullStringAsNone)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Text.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Text"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        

# Deprecated
class Char(web.form.field.typed.Char):
    """Char Field."""
    
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', treatNullStringAsNone=True, unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Char.__init__(self, name, default, description, error, required, requiredError, treatNullStringAsNone)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Char.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Char"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table

# Deprecated
class CharSelect(web.form.field.typed.CharSelect):
    """CharSelect Field."""

    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', displayNoneAs='', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.CharSelect.__init__(self, name,  options, default, description, error, required, requiredError, displayNoneAs)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.CharSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Char"        
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class Integer(web.form.field.typed.Integer):
    """Integer Field."""

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', max=2147483647, min=-2147483648, minError="The number must be greater than or equal to -2147483648", maxError="The number must be less than or equal to 2147483647", unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Integer.__init__(self, name, default, description, error, required, requiredError, max, min, minError, maxError)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Integer.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Integer"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class IntegerSelect(web.form.field.typed.IntegerSelect):
    """IntegerSelect Field."""

    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', max=2147483647, min=-2147483648, minError="The number must be greater than or equal to -2147483648", maxError="The number must be less than or equal to 2147483647", unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.IntegerSelect.__init__(self, name,  options, default, description, error, required, requiredError, min, max, minError, maxError)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.IntegerSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Integer"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class Float(web.form.field.typed.Float):
    """Float Field."""
        
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Float.__init__(self, name, default, description, error, required, requiredError)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Float.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Float"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class FloatSelect(web.form.field.typed.FloatSelect):
    """FloatSelect Field."""
        
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.FloatSelect.__init__(self, name,  options, default, description, error, required, requiredError)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.FloatSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Float"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class Date(web.form.field.typed.Date):
    """Date Field."""
        
    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=10, maxlength=10, format='%d/%m/%Y', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Date.__init__(self, name, default, description, error, required, requiredError, size, maxlength, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Date.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Date"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class DateSelect(web.form.field.typed.DateSelect):
    """DateSelect Field."""

    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%d/%m/%Y', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.DateSelect.__init__(self, name,  options, default, description, error, required, requiredError, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.DateSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Date"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class Time(web.form.field.typed.Time):
    """Time Field."""

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=10, maxlength=10, format='%H:%M:%S', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.Time.__init__(self, name, default, description, error, required, requiredError, size, maxlength, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.Time.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Time"
                
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class TimeSelect(web.form.field.typed.TimeSelect):
    """Time Field."""
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%H:%M:%S', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.TimeSelect.__init__(self, name,  options, default, description, error, required, requiredError, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.TimeSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "Time"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class DateTime(web.form.field.typed.DateTime):
    """DateTime Field."""

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=19, maxlength=19, format='%d/%m/%Y %H:%M:%S', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.DateTime.__init__(self, name, default, description, error, required, requiredError, size, maxlength, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.DateTime.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "DateTime"    
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class DateTimeSelect(web.form.field.typed.DateTimeSelect):
    """DateTimeSelect Field."""
    
    def __init__(self, name,  options, default=[], description='', error='', required=False, requiredError='Please enter a value', format='%d/%m/%Y %H:%M:%S', unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.typed.DateTimeSelect.__init__(self, name,  options, default, description, error, required, requiredError, format)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.typed.DateTimeSelect.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "DateTime"      
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class Email(web.form.field.extra.Email):
    "Email Field."

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=40, unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.extra.Email.__init__(self, name, default, description, error, required, requiredError, size)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.extra.Email.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "String"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver

    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
class URL(web.form.field.extra.URL):
    "URL Field."

    def __init__(self, name, default=None, description='', error='', required=False, requiredError='Please enter a value', size=40, unique=False, uniqueError='This is not a unique value for the field.', key=False):
        self.__dict__['unique'] = unique
        self.__dict__['uniqueError'] = uniqueError
        self.__dict__['key'] = key
        if key and not unique:
            if required:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique.')
            else:
                raise DatabaseObjectError('fields to be used as keys must also be specified as unique and required.')
        if key and not required:
            raise DatabaseObjectError('fields to be used as keys must also be specified as required.')
        self.__dict__['_driver'] = None
        self.__dict__['table'] = None
        return web.form.field.extra.URL.__init__(self, name, default, description, error, required, requiredError, size)

    def valid(self, value={'dummy':''}, ignoreRowids=[]):
        if type(value) == type({}) and value.has_key('dummy'):
            value = self.value
            if self.error():
                return False
        if self.unique:
            if not self._driver.colUnique(self.table, self.name(), value, ignoreRowids):
                self.setError(self.uniqueError)
                return False
        if web.form.field.extra.URL.valid(self, value):
            return True
        else:
            return False
            
    def type(self):
        return "String"
        
    def _setDriver(self, _driver):
        "Set the database object _driver."
        self._driver = _driver
        
    def _setTable(self, table):
        "Set the database table."
        self.table = table
        
#################################################################################################################
#
# Database
#

class Database:
    
    def __repr__(self):
        return "<web.database.object.Database: %s>"%(self.name)

    def __init__(self,  name=None):
        self.__dict__['_initialised'] = False
        self.__dict__['_tables'] = []
        if name: 
            self.__dict__['name'] = str(name)
        else:
            self.__dict__['name']  = self.__class__.__name__
        self.setup()

    def init(self, cursor):
        if not self._initialised:
            self.__dict__['_initialised'] = True
            self.__dict__['cursor'] = cursor
            _driver.cursor = self.cursor
            tables = []
            for table in self._tables:
                tables.append(table.name)
            for table in self._tables:
                # Check the table names
                count = 0
                for t in self._tables:
                    if table.name == t.name:
                        count += 1
                    if count > 1:
                        raise DatabaseObjectError("You cannot have more than one table named '%s'."%table.name)
                # Initialise the table
                table.__dict__['cursor'] = cursor
                table._tables = tables
                table._initialised = True
                
                # Initialise the fieldss
                for col in table._fields:
                    col._setDriver(_driver)
                    col._setTable(table.name)
                # Initialise the relationships
                for colName in table._foreignKey.keys():
                    foreignTableObject = self.table(table._foreignKey[colName]['foreignTable'])
                    table._foreignKey[colName]['foreignTableObject'] = foreignTableObject
                    col = None
                    for k,v in foreignTableObject._multipleJoin.items():
                        if v['foreignTable'] == table.name:
                            col = v['_fields']
                    if not col:
                        raise DatabaseObjectError("No MultipleJoin for table '%s' has been found in table '%s'."%(table.name, table._foreignKey[colName]['foreignTable']))
                    table._foreignKey[colName]['_foreignColumn'] = foreignTableObject._multipleJoin[col]['_fields']
                    
                for colName in table._multipleJoin.keys():
                    
                    foreignTableObject = self.table(table._multipleJoin[colName]['foreignTable'])
                    table._multipleJoin[colName]['foreignTableObject'] = foreignTableObject
                    col = None
                    for k,v in foreignTableObject._foreignKey.items():
                        if v['foreignTable'] == table.name:
                            col = v['_fields']
                    if not col:
                        raise DatabaseObjectError("The foreign table '%s' has no corresponding addSingle() method for the '%s' table, this may be because you have misspelt the table names."%(table._multipleJoin[colName]['foreignTable'], table.name))
                    table._multipleJoin[colName]['_foreignColumn'] = foreignTableObject._foreignKey[col]['_fields']
    
                for key in table._relatedJoin.keys():
                    foreignTableObject = self.table(key)
                    if foreignTableObject._relatedTableName(table.name) != table._relatedTableName(foreignTableObject.name):
                        raise DatabaseObjectError("The values returned by _relatedTableName() for the tables '%s' and '%s' do not match. '%s'!='%s'."%(foreignTableObject.name, table.name, foreignTableObject._relatedTableName(table.name), table._relatedTableName(foreignTableObject.table)))
                    table._relatedJoin[key]['_joinTable'] = table._relatedTableName(foreignTableObject.name)
                    table._relatedJoin[key]['foreignTableObject'] = foreignTableObject
                    if not foreignTableObject._relatedJoin.has_key(table.name):
                        raise DatabaseObjectError("No RelatedJoin for table '%s' has been found in table '%s'."%(key, col))
                    table._relatedJoin[key]['_foreignColumn'] = foreignTableObject._relatedJoin[table.name]['_fields']
                table.__dict__['column'] = QueryBuilder(table._fields, table.name)
        else:
            raise DatabaseObjectError('You cannot initialise a database more than once.')
            
    def setup(self):
        pass
        
    def addTable(self, table):
        if not self._initialised:
            self._tables.append(table)
        else:
            raise DatabaseObjectError('You add a table after the database has been initialised.')
        
    def addTables(self, tables):
        if not self._initialised:
            for table in tables:
                self.addTable(table)
        else:
            raise DatabaseObjectError('You add tables after the database has been initialised.')
            
    def table(self, name):
        for table in self._tables:
            if table.name.lower() == name.lower():
                return table
        raise DatabaseObjectError("No table named '%s' in the database object."%(name))

    def createTables(self):
        if self._initialised:
            for table in self._tables:
                if not table.ignoreCreateAndDrop:
                    table.create()
        else:
            raise DatabaseObjectError('You cannot create tables until the database is initialised with a cursor.')
            
    def dropTables(self, ignoreErrors=False):
        if self._initialised:
            for table in self._tables:
                if ignoreErrors:
                    try:
                        if not table.ignoreCreateAndDrop:
                            table.drop()
                    except:
                        pass
                else:
                    if not table.ignoreCreateAndDrop:
                        table.drop()
        else:
            raise DatabaseObjectError('You cannot drop tables until the database is initialised with a cursor.')
            
    def tablesExist(self):
        if self._initialised:
            for table in self._tables:
                if not table.exists():
                    return False
            return True
        raise DatabaseObjectError('You cannot test to see if a table exists until the database is initialised with a cursor.')
            
    def items(self):
        if self._initialised:
            r = []
            for table in self._tables:
                r.append((table.name, table))
            return tuple(r)
        raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    def tables(self):
        'Same as the keys() method.'
        return self.keys()
        
    def keys(self):
        if self._initialised:
            r = []
            for table in self._tables:
                r.append(table.name)
            return tuple(r)
        raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
    def has_key(self, table):
        if table in self.keys():
            return True
        return False
        
    def values(self):
        if self._initialised:
            return tuple(self._tables)
        raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
    def dict(self, tables=False, rows=False):
        if self._initialised:
            if rows and not tables:
                raise DatabaseObjectError('You cannot return the rows of a table as a dictionary without also returning the table as a dictionary.')
            d = {}
            for k,v in self.items():
                if tables:
                    d[k]=v.dict(rows)
                else:
                    d[k]=v
            return d
        raise DatabaseObjectError('Database not initialised with a cursor. Use init().')

    def __setattr__(self, name, value):
        if name == 'tables' and self._initialised:
            raise DatabaseObjectError('You cannot set the tables in this way after the database is initialised.')
        elif name == 'name' and self._initialised:
            raise DatabaseObjectError('You cannot set the name of the database in this way after the database is initialised.')
        else:
            self.__dict__[name] = value
        
    def __getitem__(self, name):
        return self.table(name)
            
    def __setitem__(self, name, value):
        raise DatabaseObjectError('You cannot set a table in this way.')

    def output(self, width=80):
        if self._initialised:
            return web.util.table(columns=["Database '%s'"%self.name], values=[self.keys()], width=width)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
#################################################################################################################
#
# Table
#

columns = {
    'String'.lower():String,
    'StringSelect'.lower():StringSelect,
    'Text'.lower():Text,
    'Bool'.lower():Bool,
    #'Char':Char,                   # Deprecated
    #'CharSelect':CharSelect,       # Deprecated
    'Integer'.lower():Integer,
    'IntegerSelect'.lower():IntegerSelect,
    'Float'.lower():Float,
    'FloatSelect'.lower():FloatSelect,
    'Date'.lower():Date,
    'DateSelect'.lower():DateSelect,
    'Time'.lower():Time,
    'TimeSelect'.lower():TimeSelect,
    'DateTime'.lower():DateTime,
    'DateTime'.lower():DateTimeSelect,
    'Email'.lower():Email,
    'URL'.lower():URL,
}

class Table:
    "Base class for a database table object."
   
    def __repr__(self):
        return "<web.database.object.Table: %s>"%(self.name)
        
    def __init__(self, name=None, ignoreCreateAndDrop=False):
        "Work the magic... Initialise the derived class by setting up the appropriate methods and classes."
        self.__dict__['_fields'] = []
        self.__dict__['_initialised'] = False
        self.__dict__['_multipleJoin'] = {}
        self.__dict__['_foreignKey'] = {}
        self.__dict__['_relatedJoin'] = {}
        self.__dict__['name'] = name
        self.__dict__['_tables'] = None
        self.__dict__['cursor'] = None
        self.__dict__['key'] = 'rowid'
        self.__dict__['column'] = None
        self.__dict__['ignoreCreateAndDrop'] = ignoreCreateAndDrop

        if name <> None:
            self._setTableName(name)
        else:
            self._setTableName(self._tableName())
        self.setup()

        if self.__dict__['name'] == None or self.__dict__['name'] == '':
            raise DatabaseObjectError('No database table specified.')

    def _tableName(self):
        "Can be overridden to provide customised table naming in derived classes."
        return self.__class__.__name__

    def _relatedTableName(self, other):
        "Can be overridden to provide customised table naming in derived classes."
        if self.name < other:
            return self.name+'_'+other
        elif self.name == other:
            raise DatabaseObjectError("The table '%s' cannot have the same name as '%s'."%(self.__class__.__name__,other))
        else:
            return other+'_'+self.name

    def setup(self):
        pass #raise DatabaseObjectError('Should be overridden in derived classes')
        
    def addColumn(self, object=None, **params):
        if not self._initialised:
            if object == None:
                if not params.has_key('type'):
                    raise DatabaseObjectError("'type' parameter not specified.")
                if not params.has_key('name'):
                    raise DatabaseObjectError("'name' parameter not specified.")
                elif not params['type'].lower() in columns.keys():
                    raise DatabaseObjectError("No such column type %s"%(repr(params['type'])))
                else:
                    f = params['type'].lower()
                    del params['type']
                    object = columns[f](**params)
            elif params <> {}:
                raise DatabaseObjectError('If a object is specified as a Column object, addColumn() cannot take extra parameters')

            if object.name().upper() in reservedWords:
                raise DatabaseObjectError("'%s' is a reserved word and should not be used as a column name."%object.name())
            for col in self._fields:
                if col.name().upper() == object.name().upper():
                    raise DatabaseObjectError("A column with the name '%s' has already been added."%object.name())
            if object.key == True:
                if self.key <> 'rowid':
                    raise DatabaseObjectError("Only one column can be specified as being used as a key.")
                else:
                    self.__dict__['key'] = object.name()
            self._fields.append(object)
        else:
            raise DatabaseObjectError('You cannot add a column once a table has been initialised.')
        
    #~ def add(self, **params):
        #~ if not self._initialised:

        #~ else:
            #~ raise DatabaseObjectError('You cannot add a column once a table has been initialised.')

    def addField(self, object=None, **params):
        return self.addColumn(object, **params)
    
    def addColumns(self, columns):
        for column in columns:
            self.addColumn(column)
            
    def addMultiple(self, name, foreignTable):
        if not self._initialised:
            if name.upper() in reservedWords:
                raise DatabaseObjectError("'%s' is a reserved word and should not be used as a column name."%name)
            if self._multipleJoin.has_key(foreignTable): # XXX Was commented out
                raise DatabaseObjectError("A foreign key join has already been made to the '%s' table."%foreignTable)
            if self._colNameExists(name):
                raise DatabaseObjectError("A column named '%s' has already been added to the table."%name)
            else:
                self._multipleJoin[name]={}       
                self._multipleJoin[name]['foreignTableObject'] = None
                self._multipleJoin[name]['foreignTable'] = foreignTable
                self._multipleJoin[name]['name'] = self.name
                self._multipleJoin[name]['_foreignColumn'] = None
                self._multipleJoin[name]['_fields'] = name
        else:
            raise DatabaseObjectError('You cannot add multiple joins once a table has been initialised.')
            
    def addSingle(self, name, foreignTable):
        if not self._initialised:
            if name.upper() in reservedWords:
                raise DatabaseObjectError("'%s' is a reserved word and should not be used as a column name."%name)
            if self._colNameExists(name):
                raise DatabaseObjectError("A column named '%s' has already been added to the table."%name)
            else:
                self._foreignKey[name]={}       
                self._foreignKey[name]['foreignTableObject'] = None
                self._foreignKey[name]['foreignTable'] = foreignTable
                self._foreignKey[name]['name'] = self.name
                #self._foreignKey[name]['_foreignColumn'] = None
                self._foreignKey[name]['_fields'] = name
        else:
            raise DatabaseObjectError('You cannot add single joins once a table has been initialised.')
        
    def addRelated(self, name, foreignTable):
        "NB. self._relatedJoin is indexed by table not by name unlike self._multipleJoin and self._foreignKey"
        if not self._initialised:
            if name.upper() in reservedWords:
                raise DatabaseObjectError("'%s' is a reserved SQL word and should not be used as a column name."%column.name())
            if self._relatedJoin.has_key(foreignTable):
                raise DatabaseObjectError("A join to the table '%s' has already been added."%foreignTable)
            self._relatedJoin[foreignTable]={}
            self._relatedJoin[foreignTable]['_joinTable'] = None
            self._relatedJoin[foreignTable]['foreignTableObject'] = None
            self._relatedJoin[foreignTable]['foreignTable'] = foreignTable
            self._relatedJoin[foreignTable]['name'] = self.name
            self._relatedJoin[foreignTable]['_foreignColumn'] = None
            self._relatedJoin[foreignTable]['_fields'] = name
        else:
            raise DatabaseObjectError('You cannot add related joins once a table has been initialised.')

    def _colNameExists(self, colName, type='all'):
        if type=='all':
            for col in self._fields:
                if col.name().lower() == colName.lower():
                    return True
            for k,v in self._foreignKey.items():
                if v['_fields'].lower() == colName.lower():
                    return True
            for k,v in self._multipleJoin.items():
                if v['_fields'].lower() == colName.lower():
                    return True
            for k,v in self._relatedJoin.items():
                if v['_fields'].lower() == colName.lower():
                    return True
            return False
        elif type == 'field':
            for col in self._fields:
                if col.name().lower() == colName.lower():
                    return True
            return False
        else:
            raise DatabaseObjectError("'type' must be 'all' or 'field' not '%s'"%type) 
        
    def _setTableName(self, name):
        for col in self._fields:
            if col.name().lower() == name.lower():
                raise DatabaseObjectError("The table name cannot be used as a column name.")
        self.__dict__['name'] = name

    def keys(self):
        if self._initialised:
            return _driver.getKeys(self.name, None, None, column=self.key)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
    def values(self):
        if self._initialised:
            r = []
            for k in self.keys():
                r.append(self.__getitem__(k))
            return tuple(r)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
    def items(self):
        if self._initialised:
            r = []
            for k in self.keys():
                r.append((k,self.__getitem__(k)))
            return tuple(r)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        
    def dict(self, rows=False):
        if self._initialised:
            d = {}
            for k,v in self.items():
                if rows:
                    d[k]=v.dict()
                else:
                    d[k]=v
            return d
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    def has_key(self, key):
        if key in self.keys():
            return True
        return False
        
    def __getitem__(self, name):
        if self._initialised:
            if type(name) in [type(1), type(1L), type(1.0)]:
                row = _driver.getKeys(self.name, where="%s=%s"%(self.key,name))
            else:
                row = _driver.getKeys(self.name, where="%s='%s'"%(self.key,name))
            if not row:
                raise DatabaseObjectError("No row found with the column '%s' taking the value %s"%(self.key, name))
            elif len(row) > 1:
                raise DatabaseObjectError("More than one row found with a value %s. This column is not unique and therefore cannot be used as a key."%(name))
            else:
                return self.row(row[0])
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')

    def __setitem__(self, name, value):
        raise DatabaseObjectError('You cannot set a row like this.')

    #
    # Functions testing existence
    #
    
    def exists(self):
        if self._initialised:
            return _driver.exists(self.name)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')

    def rowExists(self, rowid):
        if self._initialised:
            if not rowid:
                raise DatabaseObjectError("You haven't specified a row rowid.")
            if type(rowid) <> type(1):
                raise DatabaseObjectError("'%s' is not an integer so is not a valid rowid."%rowid)
            return _driver.rowExists(self.name, rowid)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')

    def columnExists(self, name):
        if self._initialised:
            for col in self._fields:
                if col.name() == name:
                    return True
            return False
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
    #
    # Create / Remove Tables
    #
    
    def create(self):
        """Create the table with the options specified.
        The fields tuple is in the form (name, type, required, default, unique)"""
        if self._initialised:
            if self.cursor.tableExists(self.name):
                raise DatabaseObjectError("The table '%s' already exists."%self.name)
            fields = [('rowid', 'Integer', False, None, True)]
            for col in self._fields:
                #if col.__class__.__name__ <> 'MultipleJoin':
                name = col.name()
                type = col.type()
                required = False
                if col.required == True:
                    required = True
                default = None
                if default == None:
                    pass
                elif type(col.default) == type(''): # Changed this from self.default.
                    default = "'"+col.default+"'"
                else:
                    default = str(col.default)
                unique = col.unique
                #if self.cursor.__class__.__name__ <> 'gadflyCursor':
                fields.append((name, type, required, default, unique))
                #else:
                #    fields.append((name, type))
            for key in self._foreignKey.keys():
                fields.append((key, 'Integer', True, None, False))
            _driver.create(self.name, tuple(fields))
            for key in self._relatedJoin.keys():
                if not _driver.exists(self._relatedJoin[key]['_joinTable']):
                    fields = [(self._relatedJoin[key]['_fields'], 'Integer', True, None, False)]
                    other = (self._relatedJoin[key]['_foreignColumn'], 'Integer', True, None, False)
                    if self._relatedJoin[key]['_fields'] > self._relatedJoin[key]['_foreignColumn']:
                        fields.insert(0,other)
                    elif self._relatedJoin[key]['_fields'] == self._relatedJoin[key]['_foreignColumn']:
                        raise DatabaseObjectError("The columns cannot have the same name '%s'."%self._relatedJoin[key]['_fields'])
                    else:
                        fields.append(other)
                    _driver.create(self._relatedJoin[key]['_joinTable'], tuple(fields))
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    def drop(self):
        "Drop (remove) the table from the database destroying all its contents."
        if self._initialised:
            if not self.exists():
                raise DatabaseObjectError("The table '%s' doesn't exist."%self.name)
            _driver.drop(self.name)
            for key in self._relatedJoin.keys():
                if _driver.exists(self._relatedJoin[key]['_joinTable']):
                    _driver.drop(self._relatedJoin[key]['_joinTable'])
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    #
    # Add/Remove Rows
    #

    def insert(self, all=None, **params):
        "Add a new row to the table. Maps to the INSERT command. params contains the columnName=value pairs."
        if self._initialised:
            if type(all) == type({}): # All is a reserved word so can't be a fields so there should be no confusion.
                params = all
                
            # Generate a new ID
            rowid = _driver.newID(self.name)
            
            # Check that the params are valid
            names = []
            for col in self._fields:
                names.append(col.name())
            for key in self._foreignKey.keys():
                names.append(key)
                
            for k in params.keys():
                if k not in names:
                    raise DatabaseObjectError("'%s' is not a column in the %s table."%(k,self.name))
                    
            # Setup the variables
            fields = []
            values = []
            
            for col in self._fields:
                # Add the field name
                fields.append(col.name())
                if col.name() in params.keys():
                    # Validate and add any value for the field.
                    n = col.name()
                    if col.valid(params[n]):
                        values.append(params[n])
                    else:
                        raise DatabaseObjectError("'%s' is not a valid value for the column '%s'. %s"%(params[col.name()],col.name(),col.error()))
                else:
                    if col.default:
                        # Add the defaults
                        values.append(col.default)
                    elif col.required:
                        raise DatabaseObjectError("You must specify a '%s' field since it cannot be NULL."%col.name())
                    else:
                        values.append(None)
    
            for key in self._foreignKey.keys():
                fields.append(key)
                if params.has_key(key):
                    values.append(int(params[key]))
                else:
                    raise DatabaseObjectError("No '%s' parameter specified."%key)
            
            # Add the item to the database
            _driver.addRow(self.name, fields, values)
            
            # Retrun the corresponding row object
            return self.row(rowid)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    def delete(self, rowid=None, where=None):
        "Remove the row with the rowid 'rowid' from the table. XXX been changed"
        if self._initialised:
            if rowid and where:
                raise DatabaseObjectError("You cannot specify both a rowid and a where clause.")
            rows = []
            if where <> None:
                rows = _driver.getKeys(self.name, str(where))
            else:
                rows = [rowid]
            for rowid in rows:
                if self.rowExists(int(rowid)):
                    _driver.removeRow(self.name, rowid)
                else:
                    raise DatabaseObjectError("The row with rowid '%s' doesn't exist."%rowid)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
            
    def __delitem__(self, name):
        if self._initialised:
            row = self.__getitem__(name)
            self.delete(int(row))
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
    def __setattr__(self, name, value):
        if name in ['name', 'key', 'cursor', 'column']:
            raise DatabaseObjectError("You cannot set the attribute '%s' in this way."%name)
        else:
            self.__dict__[name] = value
            
    #
    # Get Rows
    #

    def row(self, rowid):
        "Return the Row object with the rowid 'rowid'."
        if self._initialised:
            if self.rowExists(rowid):
                return Row(self.cursor, self.name, self._fields, self._foreignKey, self._multipleJoin, self._relatedJoin, rowid)
            else:
                raise DatabaseObjectError("There is no row in the '%s' table with rowid '%s'."%(self.name, rowid))
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')

    def select(self, where, order=None, rowids=False):
        "Returns row objects for rows matching the criteria."
        if self._initialised:
            rows = _driver.getKeys(self.name, str(where), order)
            if rowids:
                
                return rows
            else:
                res={}
                for rowid in rows:
                    row = self.row(rowid)
                    if self.key == 'rowid':
                        k = row.rowid
                    else:
                        k = row[self.key]
                    res[str(k)] = row
                    
                #raise DatabaseObjectError(res)
                return res
            

        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
    #
    # SQL Funcitons
    #
    
    def max(self, column, rows=False):
        "Returns the highest value in the column 'column'."
        if column == 'rowid' or self._colNameExists(column, type='field'):
            if self._initialised:
                if not rows:
                    return _driver.function(self.name,column,'max')
                else:
                    max = _driver.function(self.name,column,'max')
                    where=self.column[column]==max
                    return self.select(where=where).values()
            else:
                raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        elif self._colNameExists(column):
            raise DatabaseObjectError('max() only works on normal columns, not single, multiple or related joins.')
        else:
            raise DatabaseObjectError("No field named '%s' found."%column)
    
    def min(self, column, rows=False):
        "Returns the lowest value in the column 'column'."
        if column == 'rowid' or self._colNameExists(column, type='field'):
            if self._initialised:
                if not rows:
                    return _driver.function(self.name,column,'min')
                else:
                    min = _driver.function(self.name,column,'min')
                    where=self.column[column]==min
                    return self.select(where=where).values()
            else:
                raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
        elif self._colNameExists(column):
            raise DatabaseObjectError('max() only works on normal columns, not single, multiple or related joins.')
        else:
            raise DatabaseObjectError("No field named '%s' found."%column)
    #
    # Others
    #
    
    def form(self, action='', method='get', stickyData={}, enctype='', submit='Submit'):#, modeDict={'mode':'mode', 'table':'table', 'submode':'submode'}, submode='add'):
        if self._initialised:
            emptyRow = Row(self.cursor, self.name, self._fields, self._foreignKey, self._multipleJoin, self._relatedJoin, None)
            return emptyRow.form(action, method, stickyData, enctype, submit)#, modeDict, submode)
        
    def columns(self):
        if self._initialised:
            c = []
            for field in self._fields:
                c.append(field.name())
            return tuple(c)
        else:
            raise DatabaseObjectError('Database not initialised with a cursor. Use init().')
            
            
#################################################################################################################
#
# Row
#

class Row:
    
    def __int__(self):
        return self.rowid
        
    def __init__(self, cursor, table, fields, _foreignKey, _multipleJoin, _relatedJoin, rowid=None, cache=True):
        
        # WARNING: We need to copy these objects otherwise when one is changed they all are.
        #          There is an issue with the values being set to whatever the self._fields 
        #          variable in Table is at the time but since they are all reset anyway this
        #          shouldn't be a problem.
        
        cols = []
        for col in fields:
            col.rowid = rowid
            cols.append(copy.copy(col))
        self.__dict__['rowid'] = rowid
        self.__dict__['_fields'] = cols
        self.__dict__['_relatedJoin'] = _relatedJoin
        self.__dict__['_foreignKey'] = _foreignKey
        self.__dict__['_foreignKeyValues'] = {}          # Cached to make life easier.
        self.__dict__['_multipleJoin'] = _multipleJoin
        self.__dict__['table'] = table
        self.__dict__['cursor'] = cursor
        self.__dict__['cache'] = cache

        if self.rowid:
            # Prepare 
            fields = []
            for col in self._fields:
                fields.append(col.name())
            for key in self._foreignKey.keys():
                fields.append(key)
            rows = _driver.getRow(table, fields, self.rowid)[0]
            if not rows:
                raise DatabaseObjectError("Row with rowid '%s' does not exist in the '%s' table."%(self.rowid, table))
            else:
                for counter in range(len(fields)):
                    if self._foreignKey.has_key(fields[counter]):
                        self._foreignKeyValues[fields[counter]] = rows[counter]
                    else:
                        self._getField(counter).value = rows[counter]
        else:
            pass # We may want an empty row for the form() function

    #
    # Transformation Methods
    #
            
    def form(self, action='', method='get', stickyData={}, enctype='', submit='Submit'):#, modeDict={'mode':'mode', 'table':'table', 'submode':'submode'}, submode='add'):
        """Generate a web.form.Form object for the row, using the values of the columns in the 
        particular row and the method attributes of this function."""
        a=self
        
        class Form(web.form.Form):
            
            def setup(self):
                # Add the columns in name order. Or you could add each field individually in the order you want them.
                for col in a._fields:
                #    if not col.sql_hidden:
                    self.addField(col)
                    self.get(col.name())._description = self.get(col.name())._description.capitalize()
                # The preffered way of adding submit buttons is as actions so Submit buttons are normally not used.
                self.addAction(submit)
                
            def valid(self):
                """Internal function to make sure no wierd values have been set. Populate should take care
                of the standard ones."""
                validates = True
                ids = []
                if a.rowid:
                    ids = [a.rowid]
                for field in self.fields:
                    if str(field.__class__.__module__) == 'web.database.object':
                        if not field.valid(ignoreRowids=ids):
                            validates = False 
                    else:
                        if not field.valid(field.get()):
                            validates = False 
                return validates
        
        form = Form(self.table, action, method, stickyData, enctype)#, includeName=True)
        for k,v in stickyData.items():
            if k in form.names():
                raise DatabaseObjectError("stickyData cannot contain the key '%s' as it is used as a field name in the form."%v)
        return form
        
    def keys(self):
        r = []
        for col in self._fields:
            r.append(col.name())
        for col in self.__dict__['_foreignKey'].keys():
            r.append(col)
        for col in self.__dict__['_multipleJoin'].keys():
            r.append(col)
        for k, v in self.__dict__['_relatedJoin'].items():
            r.append(v['_fields']) 
        return r
        
    def values(self):
        r = []
        for k in self.keys():
            r.append(self.__getitem__(k))
        return r
        
    def items(self):
        r = []
        for k in self.keys():
            r.append((k,self.__getitem__(k)))
        return r

    def dict(self):
        "XXX Return the row as a dictionary. Note: This method does not turn foreign keys and related joins into dictionaries as this could result in circular references and an infinite loop."
        d = {}
        for k,v in self.items():
            d[k]=v
        return d
        
    def has_key(self, column):
        if column in self.keys():
            return True
        return False
        
    #
    # Representaion
    #
    
    def __repr__(self):
        fields = ''
        for col in self._fields:
            if type(self._getFieldValue(col.name())) == type(''):
                fields += col.name() + '=\'' + self._getFieldValue(col.name()) +'\', '
            else:
                fields += col.name() + '=' + str(self._getFieldValue(col.name()))+', '
        return "<web.database.object.Row from %s table, rowid=%s, %s>"%(self.table,self.rowid, fields[:-2])
    
    #
    # Comparison Operators
    #
    
    def __lt__(self, other):
        raise DatabaseObjectError('A row cannot be less than another row.')
    def __le__(self, other):
        raise DatabaseObjectError('A row cannot be less than another row.')
    def __gt__(self, other):
        raise DatabaseObjectError('A row cannot be greater than another row.')
    def __ge__(self, other):
        raise DatabaseObjectError('A row cannot be greater than another row.')
        
    def __eq__(self, other): 
        if other == None:
            return 0
        # check types
        if type(other) == InstanceType:
            if other.__class__.__name__ == self.__class__.__name__:
                # Check lenghts
                if other.__dict__.has_key('rowid') and self.rowid == other.rowid:
                        
                    if len(other) == len(self):
                        try:
                            for i in range(len(self._fields)):
                                # Check type of ColType
                                if other._fields[i].__class__.__name__ <> self._fields[i].__class__.__name__:
                                    return 0
                                # Check values
                                
                                if other._getFieldValue(self._fields[i].name()) <> self._getFieldValue(self._fields[i].name()):
                                    return 0
                        except:
                            return 0
                        else:
                            return 1 # Same number of columns, type of columns, values => must be the same??
                    else:
                        return 0
                else:
                    return 0
            else:
                return 0
        else:
            return 0

    def __ne__(self, other): 
        return not self.__eq__(other)
        
    def __nonzero__(self):
        if len(self._fields) > 0:
            return True
        return False
        
    def __len__(self):
        return len(self._fields)

    #
    # Core Row methods
    #
    
    def relate(self, row):
        "Relate the row specifed to this row."
        if not self.isRelated(row):
            return _driver.relate(row._relatedJoin[self.table]['_joinTable'],  row._relatedJoin[self.table]['_fields'], row._relatedJoin[self.table]['_foreignColumn'],  self.rowid, row.rowid)
        raise DatabaseObjectError('These objects are already related.')
        
    def unrelate(self, row):
        "Unrelate the row specifed to this row."
        if self.isRelated(row):
            return _driver.unrelate(row._relatedJoin[self.table]['_joinTable'], row._relatedJoin[self.table]['_fields'], row._relatedJoin[self.table]['_foreignColumn'],  self.rowid, row.rowid)
        raise DatabaseObjectError('These objects are not related.')

    def isRelated(self, row):
        "Return True if the row is related to this row, False otherwise."
        return _driver.isRelated(row._relatedJoin[self.table]['_joinTable'], row._relatedJoin[self.table]['_fields'], row._relatedJoin[self.table]['_foreignColumn'],  self.rowid, row.rowid)
        if result:
            return True
        else:
            return False

    def update(self, all=None, **params):
        "Set lots of the values of this row in one go. This is not actually optimised so it makes an SQL call for each column set."
        if type(all) == type({}): # All is a reserved word so can't be a column so there should be no confusion.
            params = all
        for name,value in params.items():
            
            if name == 'rowid':
                raise DatabaseObjectError("You cannot set the '%s' field in this way."%name)
                #return self.rowid
            elif name in self.__dict__['_foreignKey'].keys():
                raise DatabaseObjectError("You cannot set the '%s' field in this way."%name)
            else:
                fields = self._getField(name).name()
                
    
                col = self._getField(fields)
                #if col.unique:
                #    if not _driver.colUnique:
                #        raise DatabaseObjectError("%s is not a unique value for %s."%(value, col.name()))
                if col.valid(value, ignoreRowids=[self.rowid]):
                    col.set(value) # So the get method doesn't need to be called again.
                    _driver.updateRow(self.table, self.rowid, col.name(), col.get())
                else:
                    raise DatabaseObjectError(col.error())
                
                
            
            
    def __getitem__(self, name):
        if name == 'rowid': # XXX remove?
            return self.rowid
        if name in self.__dict__['_foreignKey'].keys():
            return self.__dict__['_foreignKey'][name]['foreignTableObject'].row(self._foreignKeyValues[name])
        elif name in self.__dict__['_multipleJoin'].keys():
            rowids = _driver.getKeys(self.__dict__['_multipleJoin'][name]['foreignTable'], where=self.__dict__['_multipleJoin'][name]['_foreignColumn']+'='+str(self.rowid), order="rowid")
            
            res={}
            for rowid in rowids:
                row = self.__dict__['_multipleJoin'][name]['foreignTableObject'].row(rowid)
                k  = self.__dict__['_multipleJoin'][name]['foreignTableObject'].key
                if k == 'rowid':
                    res[row.rowid] = row
                else:
                    res[row[k]] = row
            return res
        else:
            for k,v in self.__dict__['_relatedJoin'].items():
                if name == v['_fields']:
                    rowids = _driver.relatedRowids(
                        v['_joinTable'], 
                        v['_fields'],
                        v['_foreignColumn'],
                        self.rowid
                    )
                    res={}
                    for rowid in rowids:
                        row = v['foreignTableObject'].row(rowid)
                        res[row[v['foreignTableObject'].key]] = row
                    return res
            return self._getFieldValue(name) 
            
    def __setitem__(self, name, value):
        if name == 'rowid':
            raise DatabaseObjectError("You cannot set the '%s' field in this way."%name)
            #return self.rowid
        elif name in self.__dict__['_foreignKey'].keys():
            raise DatabaseObjectError("You cannot set the '%s' field in this way."%name)
        else:
            self._setFieldValue(self._getField(name).name(), value)
            # XXX Does this work with MultipleJoins

    def delete(self):
        _driver.removeRow(self.table, self.rowid)
        
    def _setFieldValue(self, fields, value):
        col = self._getField(fields)
        # XXX Not necessary?
        if col.unique:
            if not _driver.colUnique:
                raise DatabaseObjectError("%s is not a unique value for %s."%(value, col.name()))
        if col.valid(value):
            col.set(value) # So the get method doesn't need to be called again.
            _driver.updateRow(self.table, self.rowid, col.name(), col.get())
        else:
            raise DatabaseObjectError(col.error())
            
    def _getField(self, name):
        "Finds a column by name or by order in the list. Returns that column object."
        if type(name) == type(1):
            return self._fields[name]
        elif type(name) == type(''):
            for col in self._fields:
                if col.name() == name:
                    return col
            raise DatabaseObjectError("There is no column named '%s'."%name)
        else:
            raise DatabaseObjectError("Colmuns can only be indexed as a string or an integer.")
            
    def _getFieldValue(self, name):
        if self.cache == True:
            col = self._getField(name)
            return col.get()
        else:
            return _driver.getRow(self.table, [name], self.rowid)[0][0]
            
            
class Tree(Table):
    def setup(self):
        self.addColumn(web.database.object.String(name="name", required=True, description="Name"))
        self.addColumn(web.database.object.Integer(name="parent"))

    def getNode(self, rowid):
        return self.get(rowid)

    def getAllChildren(self, rowid, all=[]):
        children = self.getChildrenIDs(rowid)
        for r in children:
            all.append(r)
            self.getAllChildren(r, all)
        return all
        
    def getNodeIDFromPath(self, path, sep='/'):
        path = path.split(sep)
        return self._recursiveGetChildren(1,path)

    def _recursiveGetChildren(self, rowid, path):
        #raise DatabaseObjectError(path)
        children = self.getChildrenIDs(rowid)
        for c in children:
            if self.getNode(c).name == path[0]:
                if len(path) == 1:
                    return c
                else:
                    return self._recursiveGetChildren(c, path[1:])
        raise DatabaseObjectError('No child found.')
        
    def getPath(self, rowid, sep=' > '):
        path=[]
        if rowid == 1:
            return 'root'
        if rowid < 1:
            raise DatabaseObjectError("'%s' is not a valid category id.")
        while(rowid <> 1):
            name = self.getNode(rowid).name
            rowid = self.getParentID(rowid)
            path.append(name)
        path.reverse()
        path.insert(0, 'root')
        return sep.join(path)
        
    def getChildrenIDs(self, rowid):
        "Returns the rowids of child categories of 'rowid'."
        return self.select(where=(self.query().parent == rowid), rowids=True)

    def getParentID(self, rowid):
        "Returns the parent rowid of the category rowid."
        return self.get(rowid).parent

    def updateNode(self, rowid, all):
        c = self.getNode(rowid)
        for k, v in all.items():
            c[k]=v

    def removeNode(self, rowid):
        "Remove the category with id rowid and make all of its children children of the parent category."
        category = self.get(rowid)
        if category.name == 'root':
            raise NodeError('You cannot remove the root.')
        children = self.getChildrenIDs(category.rowid)
        c = []
        for child in children:
            c.append(self.getNode(child).name)
        if not self.checkNoChildren(c, category.parent):
            raise NodeError("You cannot remove this category as the parent category already has children with the same names as this category's children.")
        for child in children:
            self.getNode(child).parent = category.parent
        self.remove(category.rowid)
        
    def renameNode(self, rowid, name):
        category = self.getNode(rowid)
        children = self.getChildrenIDs(category.parent)
        for child in children:
            child = self.getNode(child)
            if child.name == name:
                raise DatabaseObjectError("A category with the name '%s' already exists."%name)
        category.name = name


    def changeParent(self, rowid, parentid):
        raise DatabaseObjectError(self.getAllChildren(4))
        category = self.getNode(rowid)
        # XXX needs to make sure it can't make one of its children a parent!
        category.parent = parentid
        
        
    def addForm(self, stickyData={}):
        form = self.form(method='get', enctype=None, stickyData=stickyData)
        form.remove('parent')      
        options = self.cursor.select(('rowid','name'), self.table)
        op = []
        for o in options:
            op.append((o[0],self.getPath(o[0])))
        parent = web.form.field.basic.Select(name="parent", required=True, options=op, description='Parent')
        form.add(parent)
        return form
        
    def checkNoChildren(self, name, parentid):
        children = self.getChildrenIDs(parentid)
        for child in children:
            if self.getNode(child).name in name:
                return False
        #raise DatabaseObjectError(name, parentid)
        return True
                
    def addNode(self, name, parentid, all={}):
        if not self.checkNoChildren([name], parentid):
            raise DatabaseObjectError("A category named '%s' is already a subcategory of this parent.")
        all['name'] = name
        all['parent'] = parentid
        self.add(all=all)
        
    #~ def updateForm(self, category, stickyData={}):
        #~ category = self.getNode(category)
        #~ form = category.form(stickyData=stickyData)
        #~ form.remove('parent')
        #~ options = self.cursor.select(('rowid','name'), self.table)
        #~ op = []
        #~ for o in options:
            #~ if category.rowid <> o[0]:
                #~ op.append((o[0],self.getPath(o[0])))
        #~ form.remove('name')

        #~ form.add(web.form.field.basic.Hidden(name="oldname", default=category.rowid))
        #~ return form


    #~ def removeForm(self, stickyData={}):
        #~ form = web.form.Form(method='get', enctype=None, stickyData=stickyData)
        #~ form.addAction('Remove')
            
        #~ options = self.cursor.select(('rowid','name'), self.table)
        #~ op = []
        #~ for o in options:
            #~ if o[0] <> 1: # ie the 'root'
                #~ op.append((o[0],self.getPath(o[0])))
                
        #~ if len(op) == 0:
            #~ raise DatabaseObjectError('There are no categories to remove.')
        #~ parent = web.form.field.basic.Select(name="name", required=True, options=op, description='Remove')
        #~ form.add(parent)
        #~ return form

    #~ def renameForm(self, stickyData={}):
        #~ form = web.form.Form(method='get', enctype=None, stickyData=stickyData)
        #~ form.addAction('Rename')
            
        #~ options = self.cursor.select(('rowid','name'), self.table)
        #~ op = []
        #~ for o in options:
            #~ if o[0] <> 1: # ie the 'root'
                #~ op.append((o[0],self.getPath(o[0])))
                
        #~ if len(op) == 0:
            #~ raise DatabaseObjectError('There are no categories to remove.')
        #~ form.add(web.form.field.basic.Select(name="oldname", required=True, options=op, description='Rename'))
        #~ form.add(web.form.field.basic.Input(name="name", required=True, description='To'))
        #~ return form
        
        
    #~ def changeParentForm(self, rowid, stickyData={}):
        #~ options = self.cursor.select('rowid', self.table)
        #~ op2 = []
        #~ cat = self.getNode(rowid)
        #~ for o in options:
            #~ if o[0] <> rowid and o[0] not in self.getAllChildren(rowid):          
                #~ op2.append((o[0],self.getPath(o[0])))
        #~ if len(op2) == 0:
            #~ raise DatabaseObjectError('No categories to move.')
        #~ else:
            #~ form = web.form.Form(method='get', enctype=None, stickyData=stickyData)
            #~ parent = web.form.field.basic.Select(name="parent", required=True, options=op2, description='New Parent')
            #~ form.add(parent)
            #~ form.addAction('Change')
            #~ return form 

    #~ def chooseParentForm(self, stickyData={}):
        #~ options = self.cursor.select('rowid', self.table)
        
        #~ op = []
        #~ for o in options:
            #~ if o[0] <> 1:
                #~ op.append((o[0],self.getPath(o[0])))
        #~ if len(op) == 0:
            #~ raise DatabaseObjectError('No categories to move.')
        #~ elif len(op) == 1:
            #~ raise DatabaseObjectError('There is only one category so it must have the root as its parent.')
        #~ else:
            #~ form = web.form.Form(method='get', enctype=None, stickyData=stickyData)
            #~ category = web.form.field.basic.Select(name="category", required=True, options=op, description='Node To Change')
            #~ form.add(category)
            #~ form.addAction('Choose')
            #~ return form 


