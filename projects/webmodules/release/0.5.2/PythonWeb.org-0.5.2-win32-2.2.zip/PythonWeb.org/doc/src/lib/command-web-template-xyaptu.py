#!/usr/bin/env python

import sys; sys.path.append('../../../') # show python where the web modules are
import web.template

dict =  {
    'welcomeMessage':'Welcome to the test page!',
    'testVar':True,
    'title':'XYAPTU Example',
}
        
print web.template.parse(
    type='xyaptu', 
    file='file-web-template-xyaptu.tmpl', 
    dict=dict
)