"CGI Information"

import web.wsgi.base

class CGI(web.wsgi.base.BaseMiddleware):
    def environ(self, environ):
        import cgi
        environ['web.cgi'] = cgi.FieldStorage(environ=environ, keep_blank_values=1)
        return environ