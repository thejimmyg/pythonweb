"""Implementation of a database storage driver for the session module."""

import pickle, StringIO, time, sys
from web.errors import SessionError

class DatabaseSessionEnvironmentDriver:

    def __init__(self, cursor, name):
        self.cursor = cursor
        self.name = name

    #
    # Environment Methods
    #
    
    def createSessionEnvironment(self):
        errors = []
        if not self.cursor.tableExists(self.name+'SessionStore'):
            self.cursor.create(
                table=self.name+'SessionStore',
                columns=[    
                    ('SessionID',   'String'),
                    ('App',         'String'),
                    ('ItemKey',     'String'),
                    ('ItemValue',   'Text'),
                ]
            )
        else:
            errors.append("The '"+self.name+'SessionStore'+"' table already exists.")
    
        if not self.cursor.tableExists(self.name+'Sessions'):
            self.cursor.create(
                table=self.name+'Sessions',
                columns=[     
                    ('SessionID',   'String'),
                    ('Expire',     'Integer'),
                ]
            )
        else:
            errors.append("The '"+self.name+'Sessions'+"' table already exists.")
        if errors:
            raise SessionError(', '.join(errors))

    def removeSessionEnvironment(self, ignoreErrors=True):
        errors = []
        try:
            self.cursor.drop(self.name+'SessionStore')
        except:
            if not ignoreErrors:
                errors.append("The "+self.name+'SessionStore'+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
        else:
            pass
        try:
            self.cursor.drop(self.name+'Sessions')
        except:
            if not ignoreErrors:
                errors.append("The "+self.name+'Sessions'+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
        else:
            pass
        if errors:
            raise SessionError(', '.join(errors))
        
    def completeSessionEnvironment(self):
        # XXX doesn't check the table structure
        if self.cursor.tableExists(self.name+'SessionStore') and self.cursor.tableExists(self.name+'Sessions'):
            return True
        else:
            return False
        
class DatabaseSessionDriver(DatabaseSessionEnvironmentDriver):
    """Database driver for the web.session module
    
    Driver methods just do what they are asked without error checking therefore you should not use them directly
    unless you are sure what you are doing.
    """

    #
    # Store Methods
    #
    
    def _pickle(self, value):
        "pickle a value for storing in the session store"
        out = StringIO.StringIO()
        pickle.dump(value,out)
        return out.getvalue()
        
    def _unpickle(self, value):
        "unpickle a value from the session store"
        return pickle.load(StringIO.StringIO(value))

    def delete(self, sessionID, app, key):
        "Private method overridden in derived classes. Removes the variable 'key' from the session store."
        rows=self.cursor.select(
            ('ItemValue'),
            self.name+'SessionStore',
            where="SessionID='"+sessionID+"' and ItemKey='"+key+"' and App='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        self.cursor.delete(self.name+'SessionStore',where="SessionID='"+sessionID+"' and ItemKey='"+key+"' and App='"+app+"'")  

    def empty(self, sessionID, app):
        "Empty the values of the session for the current app"
        self.cursor.delete(self.name+'SessionStore', where="SessionID='"+sessionID+"' and app='"+app+"'")

    def get(self, sessionID, app, key):#, **params):
        "Private method overridden in derived classes. Gets the variable 'key' from the session store."
        rows=self.cursor.select(
            ('ItemValue'),
            self.name+'SessionStore',
            where="SessionID='"+sessionID+"' and ItemKey='"+key+"' and App='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            #if params.has_key('otherwise'):
            #else:
            #    return params['otherwise']
                raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        else:
            if type(rows[0]) == type({}):
                read = rows[0]['ItemValue']
            else: # Assume it can be accessed as a tuple
                read = rows[0][0]
            return self._unpickle(read)

    def set(self, sessionID, app, key, value):
        "Private method overridden in derived classes. Sets the variable 'key' to the value 'value'."
        value = self._pickle(value)
        rows = self.cursor.select(
            'ItemValue',
            self.name+'SessionStore',
            where="SessionID='"+sessionID+"' and ItemKey='"+key+"'",
            fetch=True,
            format='tuple',
            convert=True,
        )
        if len(rows) == 0:
            self.cursor.insert(self.name+'SessionStore', ('SessionID','App','ItemKey','ItemValue'), (sessionID, app, key, value))
        else:
            self.cursor.update(self.name+'SessionStore', ('ItemValue',), (value,), where="SessionID='"+sessionID+"' and ItemKey='"+key+"' and App='"+app+"'")

    def keys(self, sessionID, app):
        "Get the keys of the session store for the sessionID and app"
        rows=self.cursor.select(
            ('ItemKey'),
            self.name+'SessionStore',where="SessionID='"+sessionID+"' and App='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            return []
        else:
            itemList = []
            for record in rows:
                itemList.append(record[0])
            return tuple(itemList)
    
    def items(self, sessionID, app):
        "Get the keys and unpickled values of the session store for the sessionID and app"
        rows = self.cursor.select(
            ('ItemKey','ItemValue'),
            self.name+'SessionStore',where="SessionID='"+sessionID+"' and App='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            return []
        else:
            itemList = []
            for record in rows:
                itemList.append((record[0],self._unpickle(record[1])))
            return tuple(itemList)

    def values(self, sessionID, app):
        "Get the unpickled values of the session store for the sessionID and app"
        rows=self.cursor.select(
            ('ItemValue'),
            self.name+'SessionStore',where="SessionID='"+sessionID+"' and App='"+app+"'",
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            return []
        else:
            itemList = []
            for record in rows:
                itemList.append(self._unpickle(record[0]))
            return tuple(itemList)
    #
    # Session Methods
    #
    
    def cleanup(self, min, max):
        "Remove all sessions which expired after the date expired. Raises an error if the time is greater than now()"
        rows = self.cursor.select(
            'SessionID',
            self.name+'Sessions', 
            where="Expire >= %s and Expire < %s"%(min,max),
            fetch=True,
            format='tuple',
            convert=True,
        )
        for row in rows:
            self.cursor.delete(self.name+'Sessions', where="SessionID='"+row[0]+"'")      
            self.cursor.delete(self.name+'SessionStore', where="SessionID='"+row[0]+"'")  

    def create(self, sessionID, expire):
        "Create a new session raising an error if the same ID already exists"
        if self.exists(sessionID):
            raise SessionError('A session with the sessionID %s already exists'%sessionID)
        self.cursor.insert(   
            self.name+'Sessions', 
            ('SessionID', 'Expire'),
            (sessionID, expire),
        )

    def destroy(self, sessionID):
        "Destroy the session, returing True if everything worked, False if the session doesn't exist"
        if self.exists(sessionID):
            self.cursor.delete(self.name+'Sessions', where="SessionID='"+sessionID+"'")
            self.cursor.delete(self.name+'SessionStore', where="SessionID='"+sessionID+"'")
            return True
        else:
            return False

    def exists(self, sessionID):
        "Return True if sessionID exists, even if it has expired, False otherwise"
        rows = self.cursor.select(
            'SessionID',
            self.name+'Sessions', 
            where="SessionID='"+sessionID+"'",# and Expire >"+str(int(time.time())), 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return True
        return False

    def load(self, sessionID):
        "Load the session sessionID returning None if all is ok, error message otherwise"
        rows = self.cursor.select(
            'Expire',
            self.name+'Sessions', 
            where="SessionID='"+sessionID+"'",
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            return ('Session does not exist', None)
        else:
            #raise Exception(rows)
            if rows[0][0] <= time.time():
                return ('Session expired', rows[0][0])
            else:
                return (None, rows[0][0])
        
    def setExpire(self, expireTime, sessionID):
        "Update the expiry time raising an error if the session doesn't exist"
        if not self.exists(sessionID):
            raise SessionError('Session does not exist')
        else:
            self.cursor.update(
                table=self.name+'Sessions', 
                columns=['Expire'],
                values = [int(expireTime)],
                where="SessionID='"+sessionID+"'", 
            )

    def valid(self, sessionID):
        "Return True if sessionID is a valid session, raise an Exception if it doesn't exist"
        rows = self.cursor.select(
            'Expire',
            self.name+'Sessions', 
            where="SessionID='"+sessionID+"'",
            fetch=True,
            format='tuple',
            convert=True,
        )
        if not rows:
            raise SessionError('Session does not exist')
        if rows[0][0] <= time.time():
            return False
        else:
            return True
