"Error Handling"

import web, web.error, sys

class Error:
    def __init__(self, application, ignore=[]):
        self.application = application
        self.ignore = ignore

    def __call__(self, environ, start_response):
        try:
            result = self.application(environ, start_response)
        except:
            t = sys.exc_info()
            
            if t[0] in self.ignore:
                raise
            status, h, error = self.error()
            if not status or not h or not error:
                status = '500 Error'
                h = [('Content-type','text/plain')]
                start_response(status, h, t)
                return ['An error occured and the error handling middleware failed to handle it correctly.']
            else:
                #raise
                start_response(status, h)
                if type(error) == type(''):
                    return [error]
                else:
                    return error
        else:
            return result

    def error(self):
        "Generate an error report"
        #error = []
        #error.append('Error Report\n------------\n')
        #error.append(str(sys.exc_info()[1]))
        #error.append('')
        return '200 Error Handled', [('Content-type','text/html')], web.error.info(output='debug', format='html')


import wsgi.base

class Documents(wsgi.base.BaseMiddleware):
    """Error code handling middleware
    
    The session middleware requires nothing but catches status codes other than 200
    """
    def __init__(self, codes):
        
        self.codes = codes

