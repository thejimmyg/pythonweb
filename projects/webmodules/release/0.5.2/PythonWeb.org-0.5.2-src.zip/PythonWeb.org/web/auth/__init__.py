"""Auth functions

XXX Multiple sign in mode?
"""

import time
import web.auth

from web.errors import AuthError

def session(store, expire=0, idle=0):
    return AuthSession(store, expire, idle)

def driver(storage, environment, **params):
    if storage=='database':
        import web.auth.drivers.database
        return web.auth.drivers.database.DatabaseAuthDriver(name=environment, **params)
    else:
        raise AuthError('Invalid driver type %s'%repr(driver))

def manager(
    driver,
):
    "Return a auth manager object with the options specified"
    return AuthManager(
        driver = driver,
    )

def start(
    
    environmentName,
    environmentType='database',
    sessionManager=None,
    expire=0, 
    idle=0, 
    
    setupSessionEnvironment=0,
    setupAuthEnvironment=0,

    templateDict = {},
    template = '<html><body><h1>Please Sign In</h1>%(form)s</body></html>',
    
    setup = None,
    action = '',
    stickyData = {},
    redirect=None,
    
    **environmentParams
    #signInForm=None, 
    #autoSignIn=True, 
    #autoRedirect=False,
    # 
    #includeQuery=False, 
    #stickyData={}, 
    #reminderForm=None, 
    #emailOptions=None, 
    #errorCodes=None, 
    #htmlPage=None,
    #encryption=None,
    #debug=False,
    #checkSignInAttempt=False,
    #htmlPageRegions={'content':'content','title':'title'},
):
    if sessionManager==None:
        # Obtain a session store
        import web.session
        driver = web.session.driver(environmentType, environment=environmentName, **environmentParams)
        if setupSessionEnvironment and not driver.completeSessionEnvironment():
            driver.removeSessionEnvironment(ignoreErrors=True)
            driver.createSessionEnvironment()
        manager = web.session.manager(driver=driver)
        if not manager.load():
            manager.create()
        sessionManager = manager

    # Obtain Auth objects
    import web.auth
    authSession = web.auth.session(manager.store('auth'), expire=expire, idle=idle)
    driver = web.auth.driver(environmentType, environment=environmentName, **environmentParams)
    authManager = web.auth.manager(driver=driver)
    if setupAuthEnvironment and not driver.completeAuthEnvironment():
        driver.removeAuthEnvironment(ignoreErrors=True)
        driver.createAuthEnvironment()
        if setup != None:
            setup(authManager)

    # Get the username of the current logged in user from the session
    print web.header()
    username = authSession.username()
    if username and authManager.userExists(username):
    #    user = authManager.getUser(username)
        return (None, username)#, print 'Username %s is signed in'%user.username
    else: 
        # Try to login
        import web.auth.handler.signIn
        signInHandler = web.auth.handler.signIn.SignInHandler(
            session = authSession, 
            manager = authManager,
            action=action,
            stickyData = stickyData,
        )
        error = signInHandler.handle()
        if error:  
            # Display the error form
            templateDict['form'] = error
            return (template%templateDict, None)
        else:
            # We have just signed in
            #user = authManager.getUser(authSession.username())
            return (None, authSession.username())

class AuthManager:
    
    def __init__(self, driver):
        self.driver = driver

    def __getattr__(self, name):
        return getattr(self.driver, name)
    
class AuthSession:
    def __init__(self, store, expire=0, idle=0):
        self.store = store
        self.expire = expire
        self.idle = idle
        

    def signOut(self):
        if self.store.has_key('username'):
            del self.store['username']
        if self.store.has_key('started'):
            del self.store['started']
        if self.store.has_key('accessed'):
            del self.store['accessed']
        if self.store.has_key('expire'):
            del self.store['expire']
        if self.store.has_key('idle'):
            del self.store['idle']

    def signIn(self, username):
        currentTime = int(time.time())
        self.store['username'] = username.lower()
        self.store['started']  = currentTime
        self.store['accessed'] = currentTime
        self.store['expire']   = self.expire
        self.store['idle']     = self.idle
        
    def username(self):
        if self.store.has_key('username'): # We have signed in in the past
            started  = self.store['started']
            accessed = self.store['accessed']
            currentTime  = int(time.time())
            if self.expire and ((self.expire + started) <= currentTime): 
                # store Expired
                self.signOut()
                return None
            elif self.idle and ((self.idle + accessed) <= currentTime): 
                # store Idled
                self.signOut()
                return None
            else:
                self.store['accessed'] = int(time.time())
                return self.store['username']
        else:
            # No username
            return None

    def userInfo(self):
        username = self.username()
        if username:
            return {
                'username':username,
                'started' :self.store['started'],
                'accessed':self.store['accessed'],
                'expire'  :self.store['expire'],
                'idle'    :self.store['idle'],
            }
        else:
            return None