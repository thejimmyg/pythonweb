
import base, database, datetime, SnakeSQL, SQLParserTools

import sys

class MySQLBoolConverter(base.BaseBoolConverter):

    def storageToValue(self, column):
        if column == None:
            return None
        elif column in [1,0]:
            return int(column)
        else:
            raise ConversionError('Bool columns take the internal values 1 or 0 not %s, type %s'%(column,repr(type(column))[7:-2]))
        
    def valueToStorage(self, column):
        if column == None:
            return None
        elif column in [1, True]:
            return 1
        elif column in [0, False]:
            return 0
        else:
            raise ConversionError('Bool columns take can only be 1 or 0 not %s'%(column))
        
    def valueToSQL(self, column):
        if column == None:
            return 'NULL'
        elif column in [1, True]:
            return '1'
        elif column in [0, False]:
            return '0'
        else:
            raise ConversionError('Bool columns take can only be 1 or 0 not %s'%(column))
            
    def sqlToValue(self, column):
        if column == 'NULL':
            return None
        elif str(column).upper() == 'FALSE': 
            return False
        elif str(column).upper() == 'TRUE':
            return True
        else:
            raise ConversionError("Bool columns take can only be '1' or '0' not %s, type %s"%(column, repr(type(column))[7:-2]))
            

class MySQLStringConverter(base.BaseConverter):
    def __init__(self):
        a = base.BaseConverter.__init__(self)
        self.type = 'String' # The column type should be specified in the definition
        self.SQLQuotes = True
        self.max  = 255
        self.typeCode = 5
        return a
    
    def storageToValue(self, column):
        if column == None:
            return None
        else:
            return str(column)#.replace(r"\\",r'1')
            
    def valueToStorage(self, column):
        if column == None:
            return None # Note, not NULL
        if len(str(column)) > self.max:
            raise SnakeSQL.ConversionError('Should be %s characters or less.'%self.max)
        return str(column)#.replace(r"\\",r'2')
        
    def valueToSQL(self, column):
        if column == None:
            return 'NULL'
        elif len(str(column)) > self.max:
            raise SnakeSQL.ConversionError('Should be %s characters or less.'%self.max)
        #raise Exception(column)
        x= r"'"+str(column).replace("'","''").replace('\\','\\\\')+"'"
        #print x
        return x

    def sqlToValue(self, column):
        if column == 'NULL':
            return None
        elif len(str(column)) > self.max+2:
            raise SnakeSQL.ConversionError('Should be %s characters or less.'%self.max)
        if str(column)[0] <> "'" or str(column)[-1:] <> "'":
            raise SnakeSQL.ConversionError("%s column value %s should start and end with a ' character."%(self.type, column))
        x= str(column)[1:-1].replace("''","'")#.replace(r"\\",r'4')
        #print x
        return x

class MySQLTextConverter(MySQLStringConverter):
    def __init__(self):
        a = MySQLStringConverter.__init__(self)
        self.type = 'Text' # The column type should be specified in the definition
        self.SQLQuotes = True
        self.max  = 16777215
        self.typeCode = 6
        return a

converters = {
        'String':   MySQLStringConverter(),
        'Text':     MySQLTextConverter(),
        'Binary':   base.BaseBinaryConverter(),
        'Bool':     MySQLBoolConverter(),
        'Integer':  base.BaseIntegerConverter(),
        'Long':     base.BaseLongConverter(),
        'Float':    base.BaseFloatConverter(),
        'Date':     base.BaseDateConverter(),
        'Datetime': base.BaseDatetimeConverter(), # Decision already made.
        'Time':     base.BaseTimeConverter(),
}

class Connection(base.Connection):

    def makeConnection(self, **params):
        try:
            import MySQLdb
        except ImportError, e:
            raise ImportError('MySQLdb could not be imported and is required for MySQL database access. Please check it is correctly installed')
        switch = {
            'database':'db',
            'password':'passwd',
            'socket':'unix_socket',
        }
        newParams = {}
        for param in params:
            if param in switch.keys():
                newParams[switch[param]] = params[param]
            else:
                newParams[param] = params[param]
        c = MySQLdb.connect(**newParams)
        cr = c.cursor()
        cr.execute('SET AUTOCOMMIT=0;')
        self.createdTables = []
        return c

    def commit(self):
        self.createdTables = []
        return base.Connection.commit(self)
        
    def rollback(self):
        for table in self.createdTables[:]:
            self._cursor.drop(table=table)
        return base.Connection.rollback(self)
        
class Cursor(base.Cursor):

    #~ def create(self, **params):
        #~ result = base.Cursor.create(self, **params)
        #~ self.connection.createdTables.append(params['table'])
        #~ print "Created %s, %s"%(params['table'],self.connection.createdTables)
        #~ return result
    
    #~ def drop(self, **params):
        #~ #print self.connection.createdTables
        
        #~ if not params['table'] in self.connection.createdTables:
            #~ raise SnakeSQL.Bug('The created table %s is not in the created tables list %s'%(params['table'],self.connection.createdTables))
        #~ i = self.connection.createdTables.index(params['table'])
        #~ #print i
        #~ self.connection.createdTables.pop(i)
        #~ result = base.Cursor.drop(self, **params)
        #~ #print "Dropped %s"%params['table']
        #~ return result

    def _checkDropConstraints(self, table):
        if self.connection.tables[table].childTables:
            for child in self.connection.tables[table].childTables:
                if self.connection.tables.has_key(child):
                    count = self.count(table=child)
                    if count:
                        raise SnakeSQL.SQLForeignKeyError("Cannot drop table '%s' since child table '%s' has a foreign key reference to it"%(table, child))

    def _checkDeleteConstraints(self, table, where):
        #  Foreign key constraints only supported for InnoDB table types so manually check.
        if self.connection.tables[table].childTables:
            primaryKeys = []
            for child in self.connection.tables[table].childTables:
                foreignKey = None
                for column in self.connection.tables[child].columns:
                    if column.foreignKey == table:
                        foreignKey = column.name
                        break
                if foreignKey == None:
                    raise SnakeSQL.Bug('Child table %s has no foreign key to table %s'%(child, table))
                primaryKeys.append((child, foreignKey))
            where = []
            tables = [table]
            for key in primaryKeys:
                part = []
                part.append(str(table))
                part.append('.')
                part.append(str(self.connection.tables[table].primaryKey))
                part.append(' = ')
                part.append(str(key[0]))
                part.append('.')
                part.append(str(key[1]))
                part.append(' or ')
                where.append(''.join(part))
                tables.append(str(key[0]))
            where = ''.join(where)[:-3]
            #print where
            sql = self.select(
                columns=[str(table)+'.'+self.columns(table)[0]],#str(table)+'.'+self.connection.tables[table].primaryKey],
                tables = tables,
                where = where,
                #fetch = True,
                execute=False,
                format = 'tuple',
            )
            #print sql
            self.execute(sql)
            results = self.fetchall()
            if results:
                raise SnakeSQL.SQLForeignKeyError("Table %s contains references to records with PRIMARY KEYs linked to it"%(repr(table)))

    def _checkInsertConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)
        for col in self.connection.tables[table].columns:
            if col.required and not col.default and col.name not in columns:
                raise SnakeSQL.SQLError("The REQUIRED value '%s' has not been specified."%col.name)

    def _checkInsertOrUpdateForeignKeyConstraints(self, table, columns, internalValues):
        if self.connection.tables[table].parentTables:
            for i in range(len(columns)):
                foreignKey = self.connection.tables[table].get(columns[i]).foreignKey
                if foreignKey:
                    parentPrimaryKey = self.connection.tables[foreignKey].primaryKey
                    where = "%s=%s"%(parentPrimaryKey,internalValues[i])#self.connection.tables[foreignKey].get(parentPrimaryKey).converter.sqlToValue(internalValues[i]))
                    #print where
                    result = self.select(
                        columns=[parentPrimaryKey],
                        tables = [foreignKey],
                        where = where,
                        fetch=False,
                        execute=True,
                        format = 'tuple',
                    )
                    result = self.fetchall()
                    if not result:
                        raise SnakeSQL.SQLForeignKeyError("Invalid value for foreign key %s since table %s does not have a primary key value %s"%(columns[i], foreignKey, internalValues[i]))

        
    def _checkUpdateConstraints(self, table, columns, internalValues):
        self._checkInsertOrUpdateForeignKeyConstraints(table, columns, internalValues)
        for i in range(len(columns)):
            if self.connection.tables[table].get(columns[i]).primaryKey and internalValues[i] == 'NULL':
                raise SnakeSQL.SQLError("The PRIMARY KEY '%s' cannot be set to NULL"%col.name)

    def _setupTypes(self):
        return {
            'String':   'VARCHAR(255)',
            'Text':     'MEDIUMTEXT',
            'Binary':   'MEDIUMBLOB',
            'Bool':     'BOOL', # XXX
            'Integer':  'INT(11)',
            'Long':     'BIGINT', # XXX
            'Float':    "FLOAT",
            'Date':     "DATE",
            'Datetime': "DATETIME", 
            'Time':     "TIME",
        }
        
    def _buildColumns(self, columns):
        """Build column specifications for the CREATE statements
        
        Expects defaults to be properly quoted SQL Values"""
        sqlColumns = []
        for column in columns:
            if column['foreignKey'] != None:
                column['required'] = 1
            f = []
            f.append(column['name'])
            f.append(self.types[column['type'].capitalize()])
            if column['required'] or column['primaryKey'] or column['foreignKey']:
                f.append('NOT NULL')
            if column['default'] != None:
                default = self.connection.converters[column['type'].capitalize()].valueToSQL(self.connection.converters[column['type'].capitalize()].sqlToValue(column['default']))
                #if default != 'NULL':
                f.append('DEFAULT '+default)
            if column['unique'] or column['primaryKey']:
                f.append('UNIQUE')
            if column['foreignKey'] != None:
                f.append('REFERENCES '+column['foreignKey']+' ON DELETE RESTRICT ON UPDATE RESTRICT')
                #f.append('FOREIGN KEY('+column['foreignKey']+')')
            if column['primaryKey']:
                f.append('PRIMARY KEY')
            sqlColumns.append(' '.join(f))
        sql = ',\n '.join(sqlColumns)
        return sql
        
        
    # Cecil Westerhof .. Needs implementing!
    #~ # XXX TODO
    #~ def count(self, table, where=None, values=[]):
        #~ if type(values) not in [type([]), type((1,))]:
            #~ raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        #~ where , convert=True, format='tuple', where=where, values=values)
        #~ if not results:
            #~ return 0
        #~ else:
            #~ return len(results)
            
            
        #~ sql = "SELECT COUNT(*) FROM " + table
        #~ if( where <> None ):
            #~ sql += " WHERE " + where
        #~ OldAutoConvert = self._autoConvert
        #~ self._autoConvert = False
        #~ self.execute(sql)
        #~ Count = self.fetchRows('tuple', None)[0][0]
        #~ self._autoConvert = OldAutoConvert
        #~ return Count
        
driver = {
    'converters':converters,
    'columnClass':base.BaseColumn,
    'tableClass':base.BaseTable,
    'cursorClass':Cursor,
}