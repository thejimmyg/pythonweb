#
# The Python Imaging Library.
# $Id: __init__.py,v 1.1 2004/03/18 23:19:16 thejimmyg Exp $
#
# package placeholder
#
# Copyright (c) 1999 by Secret Labs AB.
#
# See the README file for information on usage and redistribution.
#

# ;-)
