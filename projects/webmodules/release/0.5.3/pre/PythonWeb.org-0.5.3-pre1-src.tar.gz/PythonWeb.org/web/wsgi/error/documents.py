
import web.wsgi.base

class Documents(web.wsgi.base.BaseMiddleware):
    """Displays the appropriate error page for the status code"""
    
    def __init__(self, application, files={}, text={}, functions={}):
        self.application = application
        self.files = files
        self.text = text
        self.functions = functions
        for k in self.files.keys():
            if k in self.text.keys() or k in self.functions.keys():
                raise Exception('More than one document specified for error page %s'%k)
        for k in self.text.keys():
            if k in self.functions.keys():
                raise Exception('More than one document specified for error page %s'%k)

    def setup(self):
        self._newHeaders = []
        self._newResult = None

    def status(self, status):
        if len(status) > 3 and status[3] == ' ':
            if int(status[:3]) in self.text.keys():
                self._newHeaders = [('Content-Type','text/html')]
                self._newResult = self.text[int(status[:3])]
            elif int(status[:3]) in self.files.keys():
                self._newHeaders = [('Content-Type','text/html')]
                fp = open(self.files[int(status[:3])])
                self._newResult = fp.read()
                fp.close()
            elif int(status[:3]) in self.functions.keys():
                self._newHeaders = [('Content-Type','text/html')]
                self._newResult = self.functions[int(status[:3])](environ)
        return status
        
    def headers(self, headers): # Return the new headers if we are displaying a form
        if len(self._newHeaders)>0:
            return self._newHeaders
        else:
            return headers
            
    def result(self, result):
        if self._newResult != None:
            return [self._newResult]
        else:
            return result
