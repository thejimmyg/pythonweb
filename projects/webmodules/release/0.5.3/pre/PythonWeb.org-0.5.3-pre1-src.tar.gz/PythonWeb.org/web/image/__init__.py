"Image processing functions. Not written yet. Will include libgd wrappers and PIL."

def html2tuple(htmlColorCode):
    if len(htmlColorCode) <> 7:
        raise Exception("Invalid colour code. Should be something like '#ffffff' or similar.")
    else:
        l = []
        import string
        for x in [htmlColorCode[1:3], htmlColorCode[3:5], htmlColorCode[5:7]]:
            l.append(string.atoi(x,16))
        return tuple(l)
        
