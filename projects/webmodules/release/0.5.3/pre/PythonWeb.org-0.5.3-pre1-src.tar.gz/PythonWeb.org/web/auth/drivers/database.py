"""Database driver for the auth module.

N.B. You cannot have a column named username as Gadfly thinks it is ambiguous hence the username column is
called user. Not that this matters so much now since Gadfly support is deprecated
"""

#import authBase
from web.errors import AuthError

try:
    True
    False
except NameError:
    True = 1==1
    False = 0==1

class DatabaseAuthEnvironmentDriver:

    def __init__(self, cursor, name=''):
        self.cursor = cursor
        self.name = name

    #
    # Environment Methods
    #
    
    def createAuthEnvironment(self):
        errors = []
        if not self.cursor.tableExists(self.name+'AuthUser'):
            self.cursor.create(
                table=self.name+'AuthUser',
                columns=[    
                    ('user',     'String' ),
                    ('password', 'String' ),
                    ('firstname','String' ),
                    ('surname',  'String' ),
                    ('email',    'String' ),
                    ('active',   'Bool' ),
                    ('grp',    'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthUser'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthLevel'):
            self.cursor.create(
                table=self.name+'AuthLevel',
                columns=[  
                    ('user',     'String'),
                    ('app',      'String' ),
                    ('accessLevel',    'Integer'),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthLevel'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthApp'):
            self.cursor.create(
                table=self.name+'AuthApp',
                columns=[  
                    ('name',     'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthApp'+"' table already exists.")
            
        if not self.cursor.tableExists(self.name+'AuthGroup'):
            self.cursor.create(
                table=self.name+'AuthGroup',
                columns=[    
                    ('name',     'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthGroup'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthRole'):
            self.cursor.create(
                table=self.name+'AuthRole',
                columns=[    
                    ('name',     'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthRole'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthRoles'):
            self.cursor.create(
                table=self.name+'AuthRoles',
                columns=[  
                    ('user',     'String'),
                    ('app',      'String'),
                    ('role',     'String'),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthRoles'+"' table already exists.")
        if errors:
            raise AuthError(', '.join(errors))

    def removeAuthEnvironment(self, ignoreErrors=True):
        errors = []
        for table in ['AuthUser', 'AuthLevel', 'AuthApp', 'AuthGroup', 'AuthRole', 'AuthRoles']:
            try:
                self.cursor.drop(self.name+table)
            except:
                if not ignoreErrors:
                    errors.append("The "+self.name+table+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
            else:
                pass
        if errors:
            raise AuthError(', '.join(errors))
        
    def completeAuthEnvironment(self):
        if self.cursor.tableExists(self.name+'AuthUser') and self.cursor.tableExists(self.name+'AuthLevel') and self.cursor.tableExists(self.name+'AuthApp') and self.cursor.tableExists(self.name+'AuthGroup') and self.cursor.tableExists(self.name+'AuthRole') and self.cursor.tableExists(self.name+'AuthRoles'):
            return True
        else:
            return False

class DatabaseAuthDriver(DatabaseAuthEnvironmentDriver):



    #
    # Applications
    #
    
    def apps(self):
        """Return a list of current applications."""
        rows = self.cursor.select(
            'name', 
            '%sAuthApp'%self.name,
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return rows[0]
        else:
            return []
            
    def appExists(self, app):
        """Test to see if the application named 'app' exists. N.B. This function doesn't test whether the data is valid or whether the level info is availabel, just whether the file exists.""" 
        rows = self.cursor.select(
            'name',
            '%sAuthApp'%self.name, 
            where="name='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return True
        else:
            return False
            
    def addApp(self, app): 
        """Add an application named 'app' unless it already exists in which case raise an AuthError."""
        if self.appExists(app):
            raise AuthError("The '%s' application already exists."%app)
        else:
            self.cursor.insert('%sAuthApp'%self.name, ['name'], [app])
            
    def removeApp(self, app, force=0): # Changed - can't remove app if it is in use
        """Remove an application named 'app' unless it doesn't exist in which case raise an AuthError."""
        if not self.appExists(app):
            raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            if force:
                self.cursor.delete('%sAuthLevel'%self.name,where="app='"+app+"'")
                self.cursor.delete('%sAuthRoles'%self.name,where="app='"+app+"'")
            else:
                rows = self.cursor.select(
                    'user',
                    '%sAuthLevel'%self.name, 
                    where="app='"+app+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                if rows:
                    users = ''
                    for row in rows:
                        users += ", "+row[0]
                    raise AuthError('The app %s is still in use specifying access levels for the following users: %s'%(repr(app), users[2:]))
                rows = self.cursor.select(
                    'user',
                    '%sAuthRoles'%self.name, 
                    where="app='"+app+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                if rows:
                    users = ''
                    for row in rows:
                        users += ", "+row[0]
                    raise AuthError('The app %s is still in use specifying roles for the following users: %s'%(repr(app), users[2:]))
                    
            self.cursor.delete('%sAuthApp'%self.name,where="name='"+app+"'")

    #
    # Users
    #

    def userExists(self, username):
        """Test to see if the user with the username 'username' exists.""" 
        username = username.lower()
        rows = self.cursor.select(
            'user',
            '%sAuthUser'%self.name, 
            where="user='"+username+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )

        if rows:
            return True
        return False
        
    def addUser(self, username, password, firstname='', surname='', email='', active=1, group=None):
        """Add a user with the username 'username' and the password 'password' unless the username already exists in which case raise an AuthError
        Can optionally specify a firstname, surname and email for the user."""
        username = username.lower()
        if self.userExists(username):
            raise AuthError('That user already exists.')
        else:
            self.cursor.insert('%sAuthUser'%self.name,('user', 'password', 'firstname', 'surname', 'email', 'active', 'grp'),(username,password,firstname,surname,email,active,group))

    def removeUser(self, username):
        """Remove a user with the username 'username' unless the username doesn't exist in which case raise an AuthError."""
        username = username.lower()
        if self.userExists(username):
            self.cursor.delete('%sAuthUser'%self.name,where="user='"+username+"'")
            self.cursor.delete('%sAuthLevel'%self.name,where="user='"+username+"'")
        else:
            raise AuthError("The user '%s' doesn't exist."%(username))

    def users(self, group=[], active=None, app=None, role=None):
        """Return a list of current usernames."""
        rows = []
        if (app==None and role!= None) or (app != None and role == None):
            raise AuthError('You must specify both role and app or neither of them')
        if group <> [] and group<>None and not self.groupExists(group):
            raise AuthError('No such group %s'%repr(group))
        if app == None:
            if group == []: # ie all
                if active == None:
                    rows = self.cursor.select(
                        'user', 
                        tables='%sAuthUser'%self.name,
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
                else:
                    rows = self.cursor.select(
                        'user', 
                        tables='%sAuthUser'%self.name,
                        where="active=? ",
                        values = [active],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
            else:
                if active == None:
                    rows = self.cursor.select(
                        'user', 
                        tables='%sAuthUser'%self.name,
                        where="grp=?",
                        values = [group],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
                else:
                    rows = self.cursor.select(
                        'user', 
                        tables='%sAuthUser'%self.name,
                        where="grp= ? and active= ? ",
                        values = [group, active],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
        else:
            if group == []: # ie all
                if active == None:
                    rows = self.cursor.select(
                        'user',
                        tables=['%sAuthRoles'%self.name],
                        where="app=? and role=? ",
                        values = [app, role],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
                else:
                    rows = self.cursor.select(
                        ('%sAuthUser'%self.name+'.user'),
                        tables=['%sAuthUser'%self.name, '%sAuthRoles'%self.name],
                        where="%sAuthUser.active=? and %sAuthRoles.app=? and %sAuthRoles.role=? and %sAuthUser.user=%sAuthRoles.user "%(
                            self.name, 
                            self.name, 
                            self.name,
                            self.name,
                            self.name,
                        ),
                        values = [active, app, role],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
            else:
                if active == None:
                    rows = self.cursor.select(
                        ('%sAuthUser'%self.name+'.user'),
                        tables=['%sAuthUser'%self.name, '%sAuthRoles'%self.name],
                        where="%sAuthUser.grp=? and %sAuthUser.user=%sAuthRoles.user and %sAuthRoles.app=? and %sAuthRoles.role=?"%(
                            self.name, 
                            self.name, 
                            self.name, 
                            self.name, 
                            self.name
                        ),
                        values = [group, app, role],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
                else:
                    rows = self.cursor.select(
                        ('%sAuthUser'%self.name+'.user'),
                        tables=['%sAuthUser'%self.name, '%sAuthRoles'%self.name],
                        where="%sAuthUser.grp=? and %sAuthUser.active=? and %sAuthRoles.app=? and %sAuthRoles.role=? and %sAuthUser.user=%sAuthRoles.user"%(
                            self.name, 
                            self.name, 
                            self.name, 
                            self.name, 
                            self.name, 
                            self.name
                        ),
                        values = [group, active, app, role],
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )

        users = []
        for row in rows:
            users.append(row[0])
        return tuple(users)
            

    #
    # Levels
    #

    def levels(self, username, app=None):
        """Return a dictioanry containing the access level of the user with username 'username' for every application the user has been granted access to. Raise an AuthError if there is no user called 'username'."""
        username = username.lower()
        if not self.userExists(username):
            raise AuthError('That username doesn\'t exist.')
        if app==None:
                rows = self.cursor.select(
                    ('app','accessLevel'),
                    '%sAuthLevel'%self.name,
                    where="user='"+username+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                levels = {}
                for row in rows:
                    levels[row[0]] = row[1]
                return levels
        else:
            rows = self.cursor.select(
                ('app','accessLevel'),
                '%sAuthLevel'%self.name,
                where="user='"+username+"' and app='"+app+"'", 
                fetch=True,
                format='tuple',
                convert=True,
            )
            if rows:
                return row[0]
            else:
                return 0

    def setLevel(self, username, app, level):
        """Set the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        username = username.lower()
        if self.userExists(username):
            if self.appExists(app):
                if level == None or level == 0:
                    self.cursor.delete('%sAuthLevel'%self.name, where="user=? and app=?", values=[username, app])
                else:
                    rows = self.cursor.select(
                        'accessLevel',
                        '%sAuthLevel'%self.name,where="user='"+username+"' and app='"+app+"'", 
                        fetch=True,
                        format='tuple',
                        convert=True,
                    )
                    if rows:
                        self.cursor.update('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)), where="user='"+username+"' and app='"+app+"'")
                    else:
                        self.cursor.insert('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)))
                    return True
            else:
                raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            raise AuthError("The user '%s' doesn't exist."%username)

    #
    # Roles
    #

    def addRole(self, role):
        if self.roleExists(role):
            raise AuthError("The '%s' role already exists."%role)
        else:
            self.cursor.insert('%sAuthRole'%self.name, ['name'], [role])

    def roleExists(self, role):
        rows = self.cursor.select(
            'name',
            '%sAuthRole'%self.name, 
            where="name='"+role+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return True
        else:
            return False

    def removeRole(self, role, force=0):
        if not self.roleExists(role):
            raise AuthError("The '%s' role doesn't exist in the database."%role)
        else:
            # Check the roles aren't already in use:
            if force:
                self.cursor.delete(
                    table='%sAuthRoles'%self.name, 
                    where="role='"+role+"'", 
                )
            else:
                rows = self.cursor.select(
                    'user',
                    '%sAuthRoles'%self.name, 
                    where="role='"+role+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                if rows:
                    users = ''
                    for row in rows:
                        users += ", "+row[0]
                    raise AuthError('The role %s is still in use by the following users: %s'%(repr(role), users[2:]))
            self.cursor.delete('%sAuthRole'%self.name,where="name='"+role+"'")

    def roles(self, username=None, app=None):
        if username != None and app != None:
            rows = self.cursor.select(
                ['role', 'app'],
                '%sAuthRoles'%self.name, 
                where = "app='"+app+"' and user='"+username+"'",
                fetch=True,
                format='tuple',
                convert=True,
            )
            roles = []
            for row in rows:
                roles.append(row[0])
            return tuple(roles)
        else:
            if username != None and app == None:
                rows = self.cursor.select(
                    ['role','app'],
                    '%sAuthRoles'%self.name, 
                    where = "user='"+username+"'",
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                d = {}
                for row in rows:
                    d[row[1]] = row[0]
                return d
            else:
                rows = self.cursor.select(
                    'name',
                    '%sAuthRole'%self.name, 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                roles = []
                for row in rows:
                    roles.append(row[0])
                return tuple(roles)


    def setRole(self, username, app, role):
        if not self.roleExists(role):
            raise AuthError("The '%s' role doesn't exist in the database."%role)
        if role in self.roles(username, app):
            raise AuthError('User %s already has the role %s for the app %s'%(repr(username), repr(role), repr(app)))
        else:
            self.cursor.insert('%sAuthRoles'%self.name, ['role','app','user'], [role,app,username])

    def unsetRole(self, username, app, role):
        if not self.roleExists(role):
            raise AuthError("The '%s' role doesn't exist in the database."%role)
        if role not in self.roles(username, app):
            raise AuthError('User %s does not have the role %s for the app %s'%(repr(username), repr(role), repr(app)))
        else:
            self.cursor.delete('%sAuthRoles'%self.name, where = "app='"+app+"' and user='"+username+"' and role='"+role+"'",)

    #
    # Groups
    #

    def groupExists(self, group):
        if group == None:
            return True
        else:
            rows = self.cursor.select(
                'name',
                '%sAuthGroup'%self.name, 
                where="name='"+group+"'", 
                fetch=True,
                format='tuple',
                convert=True,
            )
            if rows:
                return True
            else:
                return False
        
    def addGroup(self, group):
        if self.groupExists(group):
            raise AuthError("The '%s' group already exists."%group)
        else:
            self.cursor.insert('%sAuthGroup'%self.name, ['name'], [group])

    def removeGroup(self, group, force=0):
        if not self.groupExists(group):
            raise AuthError("The '%s' group doesn't exist in the database."%group)
        else:
            # Check the roles aren't already in use:
            if force:
                self.cursor.update(
                    '%sAuthUser'%self.name, 
                    ['grp'],[None, group],
                    where="grp=?",
                )
            else:
                rows = self.cursor.select(
                    'user',
                    '%sAuthUser'%self.name, 
                    where="grp=?", 
                    values = [group],
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                users = ''
                for row in rows:
                    users += ", "+row[0]
                raise AuthError('The group %s is still in use by the following users: %s'%(repr(group), users[2:]))
            self.cursor.delete('%sAuthGroup'%self.name, where="name='"+group+"'")
    
    def groups(self):
        rows = self.cursor.select(
            'name',
            '%sAuthGroup'%self.name, 
            fetch=True,
            format='tuple',
            convert=True,
        )
        groups = []
        for row in rows:
            groups.append(row[0])
        return tuple(groups)

    #
    # User class methods
    #
            
    def user(self, username): # Changed - removed property
        if self.userExists(username):
            rows = self.cursor.select(
                ('user','password','firstname','surname','email','active','grp'), 
                '%sAuthUser'%self.name, 
                where="user='%s'"%username, 
                fetch=True,
                format='dict',
                convert=True,
            )
            object = rows[0]
            user = {
                'username':object['user'],
                'password':object['password'],
                'firstname':object['firstname'],
                'surname':object['surname'],
                'email':object['email'],
                'active':object['active'],
                'group':object['grp'],
                'levels':self.levels(username), # Changed from level
                'roles':self.roles(username),
            }
            return user
        else:
            raise AuthError("No such username '%s'."%username)

    def setUserProperty(self, username, property, value):
        """Private method to set the value of one of 'password', 'firstname', 'surname' and 'email' for a particular user."""
        username = username.lower()
        if property in ['password','firstname','surname','email']:
            if self.userExists(username):
                self.cursor.update('%sAuthUser'%self.name, (property,), (value,), where="%s='%s'"%('user',username))
            else:
                raise AuthError('That user doesn\'t exist.')
        elif property == 'group':
            if self.groupExists(value):

                self.cursor.update('%sAuthUser'%self.name, ('grp',), (value,), where="%s='%s'"%('user',username))
            else:
                raise AuthError('No such group %s'%repr(value))
        elif property == 'active':
            if value in [0,1]:
                self.cursor.update('%sAuthUser'%self.name, (property,), (value,), where="%s='%s'"%('user',username))
            else:
                raise AuthError('active can only br True or False not %s'%repr(value))
        else:
            raise AuthError("You can only set the properties password, firstname, surname, email, active and group")
