#
# filesystem.py - A Filesystem driver for Session handling in Webmodules
# This is a alpha version.
#
# Copyright (c) James Gardner <james@jimmyg.org>
# Licensed under LGPL
#
# Contributed by Osvaldo Santana Neto <osantana@gmail.com>
#

"""Implementation of a filesystem storage driver for the session module.

Directory structure:

path/
    expires.dbm   --  dumbdbm with sessionIDs and expires
    xxxxxxxxxxxx/ --  sessionID
        app1      --  dumbdbm with app session items
        app2      --  dumbdbm with app session items
    yyyyyyyyyyy/
        app3
        app4
        :
        :

Caution: This driver has not been tested in concurrent writing cases.
"""

# I need a dbm with concurrent writing support because
# of 'path/expires' database.
import dumbdbm

import cPickle
import time
import sys
import os

from web.errors import SessionError

class FilesystemSessionEnvironmentDriver:

    def __init__(self, name, path):
        self.name = name
        self.path = path

    def createSessionEnvironment(self):
        errors = []
        if not os.path.exists(self.path):
            try:
                os.makedirs(self.path)
            except OSError, e:
                errors.append("The %s directory already exists." % self.path)
        if errors:
            raise SessionError(', '.join(errors))

    def removeSessionEnvironment(self, ignoreErrors=True):
        def rm(arg, path, files):
            for filename in files:
                os.remove("%s/%s" % (path, filename))
            os.rmdir(path)
            
        errors = []
        if os.path.exists(self.path):
            try:
                os.path.walk(self.path, rm, None)
            except OSError, e:
                errors.append("The %s directory can't be removed." % self.path)
        if errors:
            raise SessionError(', '.join(errors))

    def completeSessionEnvironment(self):
        return os.path.exists(self.path)

class FilesystemSessionDriver(FilesystemSessionEnvironmentDriver):
    """Filesystem driver for the web.session module

    Driver methods just do what they are asked without error checking therefore you should not use them directly
    unless you are sure what you are doing.
    """

    def _expiresFilename(self):
        return os.path.join(self.path, 'expires')

    def _sessionFilename(self, sessionID):
        return os.path.join(self.path, sessionID)

    def _appFilename(self, sessionID, app):
        return os.path.join(self._sessionFilename(sessionID), app)

    def _dumbdbmFile(self, sessionID, app):
        return dumbdbm.open(self._appFilename(sessionID, app))

    def delete(self, sessionID, app, key):
        "Private method overridden in derived classes. Removes the variable 'key' from the session store."
        s = self._File(sessionID, app)
        if not s.has_key(key):
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        del s[key]
        s.close()

        sessionFile = os.path.join(self.path, app, sessionID)
        if not os.path.exists(sessionFile):
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        os.remove(sessionFile)


    def empty(self, sessionID, app):
        "Empty the values of the session for the current app"
        s = self._dumbdbmFile(sessionID, app)
        s.clear()
        s.close()

    def get(self, sessionID, app, key):#, **params):
        "Private method overridden in derived classes. Gets the variable 'key' from the session store."
        s = self._dumbdbmFile(sessionID, app)
        k = cPickle.dumps(key)
        if not s.has_key(k):
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        ret = cPickle.loads(s[k])
        s.close()
        return ret

    def set(self, sessionID, app, key, value):
        "Private method overridden in derived classes. Sets the variable 'key' to the value 'value'."
        s = self._dumbdbmFile(sessionID, app)
        s[cPickle.dumps(key)] = cPickle.dumps(value)
        s.close()

    def keys(self, sessionID, app):
        "Get the keys of the session store for the sessionID and app"
        s = self._dumbdbmFile(sessionID, app)
        ret = [ cPickle.loads(obj) for obj in s.keys() ]
        s.close()
        return ret

    def items(self, sessionID, app):
        "Get the keys and unpickled values of the session store for the sessionID and app"
        s = self._dumbdbmFile(sessionID, app)
        ret = [ (cPickle.loads(x), cPickle.loads(y)) for x, y in s.items() ]
        s.close()
        return tuple(ret)

    def values(self, sessionID, app):
        "Get the unpickled values of the session store for the sessionID and app"
        s = self._dumbdbmFile(sessionID, app)
        ret = [ cPickle.loads(obj) for obj in s.values() ]
        s.close()
        return tuple(ret)

    #
    # Session Methods
    #

    def cleanup(self, min, max):
        "Remove all sessions which expired after the date expired. Raises an error if the time is greater than now()"
        s = dumbdbm.open(self._expiresFilename())
        sessions = [ (x, cPickle.loads(y)) for x, y in s.items() ]
        s.close()
        for k, v in sessions:
            if v >= min and v <= max:
                self.destroy(k)

    def create(self, sessionID, expire):
        "Create a new session raising an error if the same ID already exists"
        if self.exists(sessionID):
            raise SessionError('A session with the sessionID %s already exists'%sessionID)
        expires = dumbdbm.open(self._expiresFilename())
        expires[sessionID] = cPickle.dumps(expire)
        expires.close()
        os.mkdir(os.path.join(self.path, sessionID))

    def destroy(self, sessionID):
        "Destroy the session, returing True if everything worked, False if the session doesn't exist"
        if self.exists(sessionID):
            sessionDir = self._sessionFilename(sessionID)
            for filename in os.listdir(sessionDir):
                os.remove("%s/%s" % (sessionDir, filename))
            os.rmdir(sessionDir)
            s = dumbdbm.open(self._expiresFilename())
            del s[sessionID]
            s.close()
            return True
        else:
            return False

    def exists(self, sessionID):
        "Return True if sessionID exists, even if it has expired, False otherwise"
        s = dumbdbm.open(self._expiresFilename())
        ret = s.has_key(sessionID)
        s.close()
        return ret and os.path.exists(self._sessionFilename(sessionID))

    def _expireTime(self, sessionID):
        s = dumbdbm.open(self._expiresFilename())
        ret = cPickle.loads(s[sessionID])
        s.close()
        return ret

    def load(self, sessionID):
        "Load the session sessionID returning None if all is ok, error message otherwise"
        if not self.exists(sessionID):
            return ('Session does not exist', None)
        expireTime = self._expireTime(sessionID)
        if expireTime <= time.time():
            return ('Session expired', expireTime)
        else:
            return (None, expireTime)

    def setExpire(self, expireTime, sessionID):
        "Update the expiry time raising an error if the session doesn't exist"
        if not self.exists(sessionID):
            raise SessionError('Session does not exist')

        s = dumbdbm.open(self._expiresFilename())
        s[sessionID] = cPickle.dumps(expireTime)
        s.close()

    def valid(self, sessionID):
        "Return True if sessionID is a valid session, raise an Exception if it doesn't exist"
        ret, exp = self.load(sessionID)
        if ret == 'Session does not exist':
            raise SessionError(ret)
        return ret == None
