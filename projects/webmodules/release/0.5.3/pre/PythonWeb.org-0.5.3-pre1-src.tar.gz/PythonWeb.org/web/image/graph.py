"""Library to aid with drawing graphs

These modules are not particularly well developed so you need to choose your values wisely to ensure
the graphs display correctly."""


import web

import PIL.Image, PIL.ImageDraw, PIL.ImageFont


class ScatterGraph:
    "Simple scatter graph"
    def __init__(self, xAxis, yAxis, points, bgColor=(255,255,255), size=(300,200), title='', font='arial.ttf'):
        
        self.size = size
        self.xAxis = xAxis
        self.yAxis = yAxis
        self.points = points
        self.title = title
        self.bgColor = bgColor
        
        self._checkPoints(points)
        self.image=PIL.Image.new("RGB", size, bgColor)
        self.draw=PIL.ImageDraw.Draw(self.image)
        self.font = PIL.ImageFont.truetype(font,12) 

        self.xPadding = self.font.getsize(str(xAxis['max']))[0] + (3*self.font.getsize(str(yAxis['label']))[1])
        self.yPadding = self.font.getsize(str(xAxis['max']))[1] + (3*self.font.getsize(str(xAxis['label']))[1])

        
    def _checkPoints(self, points):
        for point in points:
            if type(point) <> type((1,)):
                raise Exception("Each point should be 2-tuple, eg (0,0).")
            if type(point[0]) <> type(1) or type(point[1]) <> type(1):
                raise Exception("Each point contain two integers.")

    def _save(self):
        self._drawGrid()
        self._drawPoints()
        self._drawLabels()
        
    def toString(self, format='png'):
        self._save()
        import tempfile
        file = tempfile.mktemp()
        self.image.save(file, format)
        fp = open(file, 'rb')
        stri = fp.read()
        fp.close()
        return stri
            
        #return self.image.tostring(encoder_name)
        
    def save(self, path):
        self._save()
        self.image.save(path) # you can specify the format as the second parameter

    def _transformPoint(self, point):
        x = int(((self.size[0] - (2*self.xPadding)) * (float(point[0])/(self.xAxis['max']))) + self.xPadding)
        y = int(self.size[1]-(((self.size[1] - (2*self.yPadding)) * (float(point[1])/(self.yAxis['max']))) + self.yPadding))
        return (x,y)
        
    #
    # Draw points
    #
    
    def _drawPoints(self):
        for point in self.points:
            x,y = self._transformPoint(point)
            self.draw.line((x-2, y-2, x+3, y+3), fill=(0,0,0))
            self.draw.line((x+2, y-2, x-3, y+3), fill=(0,0,0))
        transformedPoints = []
        for point in self.points:
            transformedPoints.append(self._transformPoint(point))
        for index in range(len(transformedPoints)):
            if index < len(transformedPoints)-1:
                self.draw.line((transformedPoints[index][0], transformedPoints[index][1], transformedPoints[index+1][0], transformedPoints[index+1][1]), fill=(0,0,0))

    def _drawGrid(self):
        
        # Fill Grid
        self.draw.rectangle((self.xPadding, self.yPadding, self.size[0]-self.xPadding, self.size[1]-self.yPadding), fill=(255,255,255))

        # Draw Grid Lines
        xTicks = []
        for tick in range((self.xAxis['max'] / self.xAxis['unit'])+1):
            xTicks.append(self._transformPoint((tick*self.xAxis['unit'],0))[0])
        yTicks = []
        for tick in range((self.yAxis['max'] / self.yAxis['unit'])+1):
            yTicks.append(self._transformPoint((0, tick*self.yAxis['unit']))[1])
        counter = 0
        for tick in xTicks:
            self.draw.line(
                (tick,self.size[1]-self.yPadding,tick,self.size[1]-self.yPadding+2), 
                fill=(0,0,0)
            )
            self.draw.line(
                (tick,self.size[1]-self.yPadding,tick,self.yPadding), 
                fill=(210,210,210)
            )
            self.draw.text(
                (tick - int(float(self.font.getsize(str(counter*self.yAxis['unit']))[0])/2), self.size[1]-self.yPadding+4), str(counter*self.xAxis['unit']),
                font=self.font,
                fill=(0,0,0)
            )
            counter+=1
        counter = 0
        for tick in yTicks:
            self.draw.line(
                (self.xPadding,tick,self.xPadding-2,tick), 
                fill=(0,0,0)
            )
            self.draw.line(
                (self.xPadding,tick,self.size[0] - self.xPadding,tick), 
                fill=(210,210,210)
            )
            self.draw.text((self.xPadding-self.font.getsize(str(counter*self.yAxis['unit']))[0]-4, tick-int(float(self.font.getsize(str(tick))[1]))/2), str(counter*self.yAxis['unit']), font=self.font, fill=(0,0,0))
            counter+=1
            
        # Draw Axes
        self.draw.line(
            (self.xPadding,self.size[1]-self.yPadding,self.size[0]-self.xPadding,self.size[1]-self.yPadding), 
            fill=(0,0,0)
        )
        self.draw.line(
            (self.xPadding,self.size[1]-self.yPadding,self.xPadding,self.yPadding), 
            fill=(0,0,0)
        )

    def _drawLabels(self):

        # Draw Title
        self.draw.text( 
            (int(float(self.size[0]/2))-int(float(self.font.getsize(self.title)[0]/2)),(self.font.getsize(self.title)[1]*2)),
            self.title,
            font=self.font, 
            fill=(0,0,0)
        )
        
        # Draw xAxis Label
        self.draw.text( 
            (int(float(self.size[0]/2))-int(float(self.font.getsize(str(self.xAxis['label']))[0]/2)),self.size[1]-(self.font.getsize(str(self.xAxis['label']))[1]*2)),
            str(self.xAxis['label']),
            font=self.font, 
            fill=(0,0,0)
        )
        
        # Draw yAxis Label
        image=PIL.Image.new("RGB", self.font.getsize(self.yAxis['label']), self.bgColor)
        draw=PIL.ImageDraw.Draw(image)
        draw.text((0,0), self.yAxis['label'], font=self.font, fill=(0,0,0))
        im = image.rotate(90)
        self.image.paste(im, ((self.font.getsize(str(self.yAxis['label']))[1]), int(float(self.size[1]/2))-int(float(self.font.getsize(str(self.yAxis['label']))[0]/2))))
        
class BarGraph(ScatterGraph):
    def __init__(self, xAxis, yAxis, points, bgColor=(255,255,255), size=(300,200), title='', font='arial.ttf', barColor=(200,0,0)):
        ScatterGraph.__init__(self, xAxis, yAxis, points, bgColor, size, title, font)
        self.barColor = barColor
        
    def _checkPoints(self, points):
        counter = 1
        for point in points:
            if type(point) <> type(1) and type(point) <> type(1L) and type(point) <> type(1.0):
                raise Exception("Each point should be a number not a %s."%(str(type(point))[1:-1]))
            units = int(float(self.xAxis['max'])/self.xAxis['unit'])
            if len(points) <> units:
                raise Exception("There should be '%s' points on the graph not '%s'."%(units, len(points)))
            if point > self.yAxis['max']:
                raise Exception("Point %s cannot take the value '%s' since the scale only goes up to '%s'."%(counter, point, self.yAxis['max']))
            counter += 1

    def _drawPoints(self):
        counter=0
        for point in self.points:
            x1,y1 = self._transformPoint((self.xAxis['unit']*counter, point))
            x2,y2 = self._transformPoint((self.xAxis['unit']*(counter+1), 0))
            self.draw.rectangle((x1,y1,x2,y2), fill=self.barColor, outline=(0,0,0))
            counter+=1
        
class PieChart:
    
    "Simple pie chart"
    def __init__(self, points, bgColor=(255,255,255), size=(300,200), title='', font='arial.ttf', colors=((200,0,0),(0,200,0),(0,0,200))):
        
        self.colors = colors
        self.size = size
        self.points = points
        self.title = title
        self.bgColor = bgColor
        
        self._checkPoints(points)
        self.image=PIL.Image.new("RGB", size, bgColor)
        self.draw=PIL.ImageDraw.Draw(self.image)
        self.font = PIL.ImageFont.truetype(font,12) 

        self.xPadding = 2* int(float(self.font.getsize(self.title)[0]/2))
        self.yPadding = 2* int(float(self.font.getsize(self.title)[0]/2))

        # Check dimensions
        max = ''
        for k in points.keys():
            if len(k) > len(max):
                max = k
        height = self.font.getsize(self.title)[1]
        w = size[1] + (height*(1+len(k)) + 10)
        if size[0] < w:
            raise Exception('The width should be at least %s pixels or the key will not display correctly.'%w)
        
        
        
    def _checkPoints(self, points):
        pass
            
    def save(self, path):
        newDict = {}
        total = 0
        for k,v in self.points.items():
            total += v
            
        previous = 0
        counter = 0
        
        w = 0
        if self.size[0]-self.xPadding >= self.size[1]-self.yPadding:
            w = self.size[1]-self.yPadding
        else:
            w = self.size[0]-self.xPadding

        order = self.points.keys().sort()
        for k,v in self.points.items():
            
            height = self.font.getsize(self.title)[1]
            if counter == len(self.colors):
                counter = 0
                
            # Draw Pie
            self.draw.pieslice(
                (
                    self.xPadding, 
                    self.yPadding + int(float(self.font.getsize(self.title)[0]/2)), 
                    w, 
                    w + int(float(self.font.getsize(self.title)[0]/2))
                ),
                previous, 
                previous+(float(v)/total)*360,
                fill=self.colors[counter],
                outline=(0,0,0) 
            )
            previous = previous+(float(v)/total)*360
            
            # Draw Key
            self.draw.text( 
                (
                    self.xPadding + w + height + 10, 
                    self.yPadding + int(float(self.font.getsize(self.title)[0]/2)) + (counter*height),
                ),
                k,
                font=self.font, 
                fill=(0,0,0)
            )

            self.draw.rectangle( 
                (
                    self.xPadding + w, 
                    self.yPadding + int(float(self.font.getsize(self.title)[0]/2)) + (counter*(height)),
                    self.xPadding + w + height, 
                    self.yPadding + int(float(self.font.getsize(self.title)[0]/2)) + (counter*(height)) + height,
                ),
                outline = (0,0,0),
                fill=self.colors[counter]
            )
            
            counter += 1

        self.draw.text( 
            (int(float(self.size[0]/2))-int(float(self.font.getsize(self.title)[0]/2)),(self.font.getsize(self.title)[1]*2)),
            self.title,
            font=self.font, 
            fill=(0,0,0)
        )
        self.image.save(path)
        