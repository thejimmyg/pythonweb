"""Base PDBC driver

ToDo:

- where in delete and update doesn't support multiple tables
"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import datetime, database, SnakeSQL, SQLParserTools, tablePrint

#
# Table and column classes
#

from SnakeSQL.driver.base import BaseTable, BaseColumn, BaseConverter, BaseStringConverter, BaseTextConverter
from SnakeSQL.driver.base import BaseBinaryConverter, BaseBoolConverter, BaseIntegerConverter, BaseLongConverter
from SnakeSQL.driver.base import BaseFloatConverter, BaseDateConverter, BaseDatetimeConverter, BaseTimeConverter

import dtuple

# Database classes
#

class PrependError(Exception):
    pass
# Useage

#1. execute                                 passes to underlying cursor
#2. execute in portable mode                parsers and passes to the abstraction methods
#3. execute in portable abstraction mode    portably executes code

class Connection:

    def makeConnection(self, **params):
        raise Exception('This method should be overridden in the derived class')

    # Problems with tables and fetchall
    #~ def __getattr__(self, name):
        #~ return getattr(self._cursor,name)

    def __init__(self, driver, debug=False, structureTableName='StructureTable', createStructureTable=True, prepend='', **params):
        self.initialised = False
        self.createdTables = [] # Only used by MySQL driver
        self.baseConnection = self.makeConnection(**params)
        self.prepend = prepend
        self.structureTableName = structureTableName
        self._structureTableName = self.prepend+self.structureTableName
        self.converters = driver['converters']
        self.cursorClass = driver['cursorClass']
        self.tableClass = driver['tableClass']
        self.columnClass = driver['columnClass']
        self.parser = SQLParserTools.Transform()
        self.tables = {}
        self.debug = debug
        self._cursor = self.cursor()
        self._cursor._ignoreTableTest = False
        self.createStructureTable = createStructureTable

        self.loadStructureTable()
        self.initialised = True

    def loadStructureTable(self):
        self._cursor._ignoreTableTest = True
        self.tables = {}
        if not self._cursor.tableExists(self._structureTableName, mode='direct'):
            if self.createStructureTable:  
                self._cursor.create(
                    table=self.structureTableName, 
                    columns = [
                        self._cursor.column(name='TableName', type='String', required=True),
                        self._cursor.column(name='ColumnName', type='String', required=True),
                        self._cursor.column(name='ColumnType', type='String', required=True),
                        self._cursor.column(name='IsRequired', type='Bool'),
                        self._cursor.column(name='IsUnique', type='Bool'),
                        self._cursor.column(name='IsPrimaryKey', type='Bool'),
                        self._cursor.column(name='ForeignKeyTable', type='Text'),
                        self._cursor.column(name='DefaultValue', type='Text'),
                        self._cursor.column(name='Position', type='Integer', required=True),
                    ],
                    execute=True,
                )
            else:
                raise Exception('Structure table %s does not exist and automatic creation of the table has been disabled'%repr(structureTableName))
        else:
            values = [
                [self.structureTableName, 'TableName',  'String', 1, 0, 0, None, None,0],
                [self.structureTableName, 'ColumnName', 'String', 1, 0, 0, None, None,1],
                [self.structureTableName, 'ColumnType', 'String', 1, 0, 0, None, None,2],
                [self.structureTableName, 'IsRequired',   'Bool',   0, 0, 0, None, None,3],
                [self.structureTableName, 'IsUnique',     'Bool',   0, 0, 0, None, None,4],
                [self.structureTableName, 'IsPrimaryKey', 'Bool',   0, 0, 0, None, None,5],
                [self.structureTableName, 'ForeignKeyTable', 'Text',   0, 0, 0, None, None,6],
                [self.structureTableName, 'DefaultValue',    'Text',   0, 0, 0, None, None,7],
                [self.structureTableName, 'Position',   'Integer',1, 0, 0, None, None,8],
            ]
            columns = []
            for value in values:
                columns.append(
                    self.columnClass(
                        table = value[0],
                        name = value[1],
                        type = value[2],
                        required = value[3],
                        unique = value[4],
                        primaryKey = value[5],
                        foreignKey = value[6],
                        default = value[7],
                        position = value[8],
                        converter = self.converters[value[2]],
                    )
                )
            self.tables[self.structureTableName] = self.tableClass(self.structureTableName, columns)
            
            self._cursor.select(
                columns=[
                    'TableName',
                    'ColumnName',
                    'ColumnType',
                    'IsRequired',
                    'IsUnique',
                    'IsPrimaryKey',
                    'ForeignKeyTable',
                    'DefaultValue',
                    'Position',
                ], 
                tables=[self.structureTableName], 
                order='TableName, ColumnName',
                fetch=False,
                #where="TableName != '"+self._structureTableName+"'",
            )
            results = self._cursor.fetchall(format='dict')
            tables = {}
            for result in results:
                if result['TableName'] != self.structureTableName:
                    if not tables.has_key(result['TableName']):
                        tables[result['TableName']] = []
                    tables[result['TableName']].append(
                        self.columnClass(
                            table = result['TableName'],
                            name = result['ColumnName'],
                            type = result['ColumnType'].capitalize(),
                            required = result['IsRequired'],
                            unique = result['IsUnique'],
                            primaryKey = result['IsPrimaryKey'],
                            foreignKey = result['ForeignKeyTable'],
                            default = result['DefaultValue'],
                            converter = self.converters[result['ColumnType'].capitalize()],
                            position = result['Position'],
                        )
                    )
            for name, columns in tables.items():
                self.tables[name] = self.tableClass(name, columns)
                
        self._buildTableLinks()
        self._cursor._ignoreTableTest = False

    def _buildTableLinks(self):
        for tableName, tableObject in self.tables.items():
            for column in tableObject.columns:
                if column.primaryKey:
                    self.tables[tableName].primaryKey = column.name
                if column.foreignKey:
                    self.tables[column.foreignKey].childTables.append(tableName)
                    self.tables[tableName].parentTables.append(column.foreignKey)
        #print self.tables.keys()

    def close(self):
        return self.baseConnection.close()

    def commit(self):
        return self.baseConnection.commit()
        
    def rollback(self):
        r = self.baseConnection.rollback()
        self.loadStructureTable()
        return r

    def cursor(self, debug=None, convert=True, format='tuple', mode='portable', fetch=True, **params):
        if debug == None:
            debug = self.debug
        return self.cursorClass(
            cursor = self.baseConnection.cursor(**params), 
            connection = self, 
            debug = debug,
            convert=convert,
            format = format,
            mode = mode,
        )
        
    def __del__(self):
        if self.initialised:
            self.rollback()

class Cursor:
    "Base class for database adaptation layer"

    def __init__(self, cursor, connection, debug=False, convert=True, format='tuple', mode='portable', fetch=True):
        self._ignoreTableTest = False
        self.debug = debug
        self.format = format
        self.sql = []
        self.position = 0
        self.baseCursor = cursor
        self.connection = connection
        self.mode = mode
        self.info = None
        self.metainfo = None
        self.convert = convert
        self.fetch = fetch
        self.sql = []
        self.types = self._setupTypes()
        
        
    def _setupTypes(self):
        return {
            'Date':'Date',
            'Datetime':'Datetime',
            'Time':'Time',
            'Float':'Float',
            'Long':'Long',
            'String':'String',
            'Bool':'Bool',
            'Text':'Text',
            'Integer':'Integer'
        }
        
    def executeMany(self, sql, parameters=[], mode=None):
        for params in parameters:
            self.execute(sql, params, mode)

    def _execute(self, *args):
        return self.baseCursor.execute(*args)


    def execute(self, sql, parameters=[], mode=None):
        operation = sql
        self.metainfo = None
        self.info = None
        if (mode == None and self.mode == 'db-api2.0') or mode=='db-api2.0':
            return self._execute(operation, parameters)
        else:
            if self.debug:
                self.sql.append(sql)
            if type(parameters) not in [type(()), type([])]:
                parameters = [parameters]
            parsedSQL = self.connection.parser.parse(operation)
            if parameters:
                parsedSQL['values'] = parameters
            if parsedSQL.has_key('sqlValues'):
                parsedSQL['_sqlValues'] = parsedSQL['sqlValues']
                del parsedSQL['sqlValues']
            if parsedSQL['function'] == 'create':
                del parsedSQL['function']
                return self.create(**parsedSQL)
            elif parsedSQL['function'] == 'drop':
                del parsedSQL['function']
                if len(parsedSQL['tables'])>1:
                    raise SnakeSQL.SQLSyntaxError('Only one table can be dropped at once')
                parsedSQL['table'] = parsedSQL['tables'][0]
                del parsedSQL['tables']
                return self.drop(**parsedSQL)
            elif parsedSQL['function'] == 'insert':
                del parsedSQL['function']
                return self.insert(**parsedSQL)
            elif parsedSQL['function'] == 'update':
                del parsedSQL['function']
                return self.update(**parsedSQL)
            elif parsedSQL['function'] == 'select':
                del parsedSQL['function']
                return self.select(fetch=False, **parsedSQL)
            elif parsedSQL['function'] == 'delete':
                del parsedSQL['function']
                return self.delete(**parsedSQL)
            elif parsedSQL['function'] == 'show':
                del parsedSQL['function']
                del parsedSQL['item']
                tables = self.tables(**parsedSQL)
                self.metainfo={}
                self.metainfo['results'] = []
                for table in tables:
                    self.metainfo['results'].append([table])
                self.metainfo['columns'] = ['Tables']
                return 'SHOW TABLES'
            elif parsedSQL['function'] == 'describe':
                del parsedSQL['function']
                del parsedSQL['item']
                if not self.tableExists(parsedSQL['table']):
                    raise SnakeSQL.SQLError('No such table %s'%parsedSQL['table'])
                #tables = self.tables(**parsedSQL)
                self._ignoreTableTest = True
                result = self.select(
                    columns=['ColumnName','ColumnType','IsRequired','IsUnique','IsPrimaryKey','ForeignKeyTable','DefaultValue'],
                    tables=[self.connection.structureTableName],
                    where="TableName='"+parsedSQL['table']+"'",
                    fetch=False,
                    execute=True,
                )
                self._ignoreTableTest = False
                return result
            else:
                raise SnakeSQL.SQLSyntaxError("%s is not a supported SQL keyword."%parsedSQL['function'].upper())
        
    def fetchone(self, convert=True, format=None):
        results = self.fetchall(convert, format)
        if results:
            return results[0]
        else:
            return None

    def fetchall(self, convert=True, format=None):
        if format == None: 
            format = self.format
        if self.info == None:
            if self.metainfo == None:
                return None
            else:
                # No conversion needed
                if format == 'tuple':
                    return tuple(self.metainfo['results'])
                else:
                    return self._formatResults(format, self.metainfo['columns'], self.metainfo['results'])
        else:
            if convert == None:
                convert = self.convert
            results = self.baseCursor.fetchall()
            if convert:
                results = self._convertResults(results)
            if format == 'tuple':
                return tuple(results)
            else:
                if not results:
                    return tuple([])
                else:
                    columns = []
                    for i in range(len(results[0])):
                        columns.append(self.info[i].name)
                    return self._formatResults(format, columns, results)

    def _convertResults(self, results):
        newresults = []
        for record in results:
            newrecord = []
            for i in range(len(record)):
                newrecord.append(self.info[i].converter.storageToValue(record[i]))
            newresults.append(tuple(newrecord))
        return tuple(newresults)

    def _formatResults(self, format, columns, results):
        if format == 'text':
            return tablePrint.table(columns, results, mode='sql')
        else:
            if format == 'dict':
                final = []
                for result in results:
                    fin = {}
                    for i in range(len(result)):
                        fin[columns[i]] = result[i]
                    final.append(fin)
                return tuple(final)
            elif format == 'object':
                rows = []
                for result in results:
                    descr = dtuple.TupleDescriptor([[n] for n in columns])
                    rows.append(dtuple.DatabaseTuple(descr, result))
                return tuple(rows)
            else:
                raise SnakeSQL.ConversionError('Invalid format type %s for conversions'%format)

    def export(self, format='sql'):
        "format can be sql (or code maybe later?)"
        output = []
        tables = self.tables()
        tables
        counter = 0
        cont = True
        while cont:
            changed = False
            for i in range(len(tables)):
                table = tables[i]
                for child in self.connection.tables[table].childTables:
                    if child in tables:
                        if tables.index(child) < tables.index(tables[i]):
                            changed = True
                            table = tables[i]
                            j = tables.index(child)
                            tables.pop(tables.index(tables[i]))
                            tables.insert(j, table)
            if not changed:
                cont = False
            counter += 1
            if counter == 100:
                raise Exception('Maximum recursion depth exceeded whilst trying to determine table dependencies, possible circular dependencies')
        for table in tables:
            columns = []
            names = []
            for column in self.connection.tables[table].columns:
                columns.append(
                    self.column(
                        name       = column.name,
                        type       = column.type,
                        required   = column.required,
                        unique     = column.unique,
                        primaryKey = column.primaryKey,
                        foreignKey = column.foreignKey,
                        default    = column.default,
                    )
                )
                names.append(column.name)
            output.append(self.connection.parser.buildCreate(table=table, columns=columns,))
            
            results = self.select(
                columns=self.columns(table),
                tables=[table],
                fetch=True,
                format='tuple',
            )
            for result in results:
                values = []
                for i in range(len(result)):
                    values.append(self.info[i].converter.valueToSQL(result[i]))
                output.append(
                    self.connection.parser.buildInsert(table=table, columns=names, sqlValues=values)
                )

        return '\n'.join(output)
        
#
# These methods accept an altered table name
#

    def _tableExists(self, table):
        try:
            self._execute("SELECT * FROM "+table+' where 3=4')
        except:
            #~ if mode != 'dbapi2.0':
                #~ if self.connection.tables.has_key(table):
                    #~ raise SnakeSQL.Bug("The table %s doesn't actaully exist but is present in connection.tables()"%table)
            return False
        else:
            #~ if mode != 'dbapi2.0':
                #~ if not self.connection.tables.has_key(table):
                    #~ raise SnakeSQL.Bug("The table %s does actaully exist but isn't present in connection.tables()"%table)
            return True



#
# These methods do not accept an altered table name
#

    def _checkUpdateConstraints(self, table, columns, internalValues):
        pass
        
    def _checkDropConstraints(self, table):
        pass

    def _checkInsertConstraints(self, table, columns, internalValues):
        pass
        
    def _prependTable(self, table):
        return self.connection.prepend + table
        
    def _removeTablePrepend(self, table):
        # Remove the prepend
        if table[:len(self.connection.prepend)] <> self.connection.prepend:
            raise PrependError('The table %s does not have the prepend %s present'%(table, self.connection.prepend))
        else:
            return table[len(self.connection.prepend):]

        
        
    def tableExists(self, table, mode=None):
        if mode==None:
            mode=self.mode
        if mode == 'direct':
            return self._tableExists(table)
        else:
            if table == self.connection.structureTableName and not self._ignoreTableTest :
                return False
            if self.connection.tables.has_key(table):
                #~ if self.debug:
                    #~ if self._tableExists(table):
                        #~ return True
                    #~ else:
                        #~ raise Exception('Table %s does not exists but is in the table structure. %s'%(table, self.connection.tables.keys()))
                #~ else:
                return True
            else:
                #~ if self.debug:
                    #~ if self._tableExists(table):
                        #~ raise Exception('Table %s exists but is not in the table structure. %s'%(table, self.connection.tables.keys()))
                    #~ else:
                        #~ return False
                #~ else:
                return False

    def columnExists(self, table, column, mode=None):
        # Add the prepend
        #
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            if not self.connection.tables.has_key(table):
                raise SnakeSQL.SQLError('No such table %s'%repr(table))
            if self.connection.tables[table].has_key(column):
                return True
            else:
                return False
        else:
            try:
                self._execute("SELECT "+column+" FROM "+table+" WHERE 3=4")
                self.baseCursor.fetchall()
            except:
                return False
            else:
                return True

    def tables(self, mode=None):
        "Returns a list of strings of table names in the database including ColTypes"
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            tables = self.connection.tables.keys()
            if not self._ignoreTableTest:
                tables.pop(tables.index(self.connection.structureTableName))
            return tables
        else:
            tables = self._tables()
            # Remove the prepend
            result = []
            for table in tables:
                result.append(self._removeTablePrepend(table))
            return tuple(result)

    def _tables(self):
        self._execute('SHOW TABLES')
        tables = self.baseCursor.fetchall()[0]
        # Remove the prepend
        result = []
        for table in tables:
            result.append(self._removeTablePrepend(table))
        return tuple(result)

    def columns(self, table, mode=None):
        "Returns a list of all the column names for the table 'table'. Used if autoConvert='table'."
        # Add the prepend
        fakeTable = table
        table = self._prependTable(table)
        if mode==None:
            mode=self.mode
        if mode == 'portable':
            if not self.connection.tables.has_key(fakeTable):
                raise SnakeSQL.SQLError('No such table %s'%repr(fakeTable))
            columns = []
            for column in self.connection.tables[fakeTable].columns:
                columns.append(column.name)
            return tuple(columns)
        else:
            raise Exception('Not Tested')
            self._execute("select * from "+table+" where 1=2")
            cols = []
            for col in self.baseCursor.description:
                cols.append(col[0])
            return tuple(cols)
        
## SQL statement generators

    def select(self, columns, tables, values=[], where=None, order=None, execute=None, fetch=None, limit=None, **fetchParams):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        if fetch == None:
            fetch = self.fetch
        if fetch==True and execute==None:
            execute=True
        #if format == None:
        #    format = self.format
        #if convert == None:
        #    convert = self.convert
        if type(tables) == type(''):
            tables = [tables]
        # Add the prepend
        t =[]
        for table in tables:
            t.append(self._prependTable(table))
        tables = t
        del t
        if type(columns) == type(''):
            columns = [columns]
        if columns == ['*']:
            columns = []
            for table in tables:
                for col in self.columns(self._removeTablePrepend(table)):
                    if len(tables) == 1:
                        columns.append(col)
                    else:
                        columns.append(table+'.'+col)
        else:
            # Add the prepend
            cols = []
            for column in columns:
                if column.count('.') == 1:
                    table, colname = column.split('.')
                    cols.append(self._prependTable(table) + '.' + colname)
                else:
                    cols.append(column)
            columns = cols
            del cols
        if where:
            fakeTable = None
            if len(tables) == 1:
                fakeTable = self._removeTablePrepend(tables[0])
            if type(where) == type(''):

                where = self.connection.parser._parseWhere(where, tables=tables)
                #print where
                whereTable = fakeTable
                if len(tables) > 1:
                    whereTable = None
                where, used = self.where(where, values, whereTable, _ignoreParamErrors=True)
                if values:
                    
                    if used < len(values):
                        raise SnakeSQL.SQLSyntaxError('Not enough ? parameters in WHERE clause or too many values specified')
                    elif used > len(values):
                        raise SnakeSQL.SQLSyntaxError('Not enough values to substitute for all ? parameters in WHERE clause')
                #print where
            where = self._where(where, values, fakeTable)
        if type(order) == type(''):
            order = self.order(order)
        if order:
            if len(tables) > 1:
                order = self._order(order)
            else:
                order = self._order(order, self._removeTablePrepend(tables[0]))
        info = []
        
        if len(tables) == 1:
            fakeTable = self._removeTablePrepend(tables[0])
            if not self.tableExists(fakeTable):
                raise SnakeSQL.SQLError("Table '%s' doesn't exist."%fakeTable)
                # XXX should check that the underlying table doesn't exist too
            for i in range(len(columns)):
                if '.' in columns[i]:
                    t, c = columns[i].split('.')
                    if not self._prependTable(t) == tables[0]:
                        raise SnakeSQL.SQLSyntaxError("Unexpected '.' character found in column name %s"%(repr(column)))
                    else:
                        columns[i] = c
                else:
                    info.append(self.connection.tables[fakeTable].get(columns[i]))
        else:
            for column in columns:
                if '.' not in column:
                    raise SnakeSQL.SQLSyntaxError("Expected table name followed by '.' character before column name %s"%(repr(column)))
                else:
                    table, column = column.split('.')
                    table = self._removeTablePrepend(table)
                    if not self.tableExists(table):
                        raise SnakeSQL.SQLError("Table '%s' doesn't exist."%table)
                        # XXX should check that the underlying table doesn't exist too
                    info.append(self.connection.tables[table].get(column))
        sql = self.connection.parser.buildSelect(tables, columns, where, order, limit)
        if execute == False:
            return sql
        else:
            self.info = info
            self._execute(sql)
            if fetch:
                return self.fetchall(**fetchParams)
            else:
                return sql

    def insertMany(self, table, columns, values, _sqlValues=[]):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        for value in values:
            self.insert(table, columns, values=value, _sqlValues=_sqlValues, execute=True)


    def _internalValues(self, table, columns, values, _sqlValues):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        # NOTE: We are not dealing with an altered name and we don't need to modify it.

        #raise Exception(_sqlValues)
        # Check table exists
        if not self.tableExists(table):
            raise SnakeSQL.SQLError("Table '%s' doesn't exist."%table)
        # Format the values
        if type(columns) == type(''):
            columns = [columns]
        # Duplicated = if type(values) not in [type([]), type((1,))]:
        #    raise Exception("Expected 'values' to be a list or tuple of values not type %s"%str(type(values))[6:-1])
        if type(_sqlValues) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError("Expected '_sqlValues' to be a list or tuple of values not type %s"%str(type(_sqlValues))[6:-1])
        info = []
        for column in columns:
            if '.' in column:
                raise SnakeSQL.SQLSyntaxError("Unexpected '.' character found in column name %s"%(repr(column)))
            else:
                info.append(self.connection.tables[table].get(column))
        # Get values in the correct format
        used = 0
        internalValues = []
        if len(_sqlValues) == 0: # We are using values and they need to be converted
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise SnakeSQL.SQLError("Table '%s' has no column named '%s'."%(table, columns[i]))
                internalValues.append(info[i].converter.valueToSQL(values[i]))
        elif len(_sqlValues) == len(values) == 0:
            raise SnakeSQL.SQLError('You must specify either values or _sqlValues')
        elif len(values) == 0: # We are only using SQL values
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise SnakeSQL.SQLError("Table '%s' has no column named '%s'."%(table, columns[i]))
                internalValues.append(info[i].converter.valueToSQL(info[i].converter.sqlToValue(_sqlValues[i])))
            #internalValues = _sqlValues
        else: # We are using both SQL and Python values, they need to be mixed
            if len(columns) != len(_sqlValues):
                raise SnakeSQL.SQLError('The number of _sqlValues must match the number of columns, even if some values are \'?\'')
            for i in range(len(columns)):
                if not self.connection.tables[table].columnExists(columns[i]):
                    raise SnakeSQL.SQLSError("Table '%s' has no column named '%s'."%(table, columns[i]))
                if _sqlValues[i] == '?':
                    if used == len(values):
                        raise SnakeSQL.SQLError('The number of values must match the number of \'?\' terms in _sqlValues')
                    internalValues.append(info[i].converter.valueToSQL(values[used]))
                    used += 1
                else:
                    value = info[i].converter.sqlToValue(_sqlValues[i])
                    internalValues.append(info[i].converter.valueToSQL(value))
        return internalValues, columns, used

    def insert(self, table, columns, values=[], _sqlValues=[], execute=None):
        """_sqlValues is a list of values as quoted SQL or ?, values is a list of values
        
        We can't use values = None as this is interpreted as values = [None] which is a valid value"""
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        internalValues, columns, used = self._internalValues(table, columns, values, _sqlValues)
        fakeTable = table# Add the prepend
        table = self._prependTable(table)
        # Build SQL
        self._checkInsertConstraints(fakeTable, columns, internalValues)
        sql = self.connection.parser.buildInsert(table, columns, internalValues)
        if execute == False:                
            return sql
        else:
            self.info = None
            self._execute(sql)
            return sql

    def update(self, table, columns, values=[], _sqlValues=[], where=None, execute=None, limit=None):
        """_sqlValues is a list of values as quoted SQL or ?, values is a list of values
        
        We can't use values = None as this is interpreted as values = [None] which is a valid value"""
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        internalValues, columns, used = self._internalValues(table, columns, values, _sqlValues)
        fakeTable = table# Add the prepend
        table = self._prependTable(table)
        self._checkUpdateConstraints(fakeTable, columns, internalValues)
        usedagain = 0

        if where:
            # XXX None?
            if type(where) == type(''):
                where = self.connection.parser._parseWhere(where, tables=table)
                where, usedagain = self.where(where, values[len(columns)+used:], fakeTable, _ignoreParamErrors=True)
            where = self._where(where, values, fakeTable)
        if _sqlValues:
            if used + usedagain < len(values):
                raise SnakeSQL.SQLSyntaxError('Not enough ? parameters or too many values specified')
            elif used + usedagain > len(values):
                raise SnakeSQL.SQLSyntaxError('Not enough values to substitute for all ? parameters')
        #else:
        #    if usedagain < len(values):
        #        raise SnakeSQL.SQLSyntaxError('Not enough ? parameters in WHERE clause or too many values specified')
        #    elif usedagain > len(values):
        #        raise SnakeSQL.SQLSyntaxError('Not enough values to substitute for all ? parameters in WHERE clause')
    
        # Build SQL
        sql = self.connection.parser.buildUpdate(table, columns, internalValues, where, limit)
        if execute == False:                
            return sql
        else:
            self.info = None
            self._doUpdate(sql, fakeTable, where, limit, columns, internalValues)
            return sql

    def _doUpdate(self, sql, table, where, limit, colUpdate, newValues):
        self._execute(sql)

    def _checkDeleteConstraints(self, table, where):
        pass

    def delete(self, table, values=[], where=None, execute=None, limit=None):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        if execute and not self.tableExists(table):
            raise SnakeSQL.SQLError('Table %s does not exist'%table)
        # Add the prepend
        fakeTable = table
        table = self._prependTable(table)
        used = 0
        if where:
            if type(where) == type(''):
                where = self.connection.parser._parseWhere(where, tables=table)
                where, used = self.where(where, values, fakeTable, _ignoreParamErrors=True)
                if values:
                    if used < len(values):
                        raise SnakeSQL.SQLSyntaxError('Not enough ? parameters in WHERE clause or too many values specified')
                    elif used > len(values):
                        raise SnakeSQL.SQLSyntaxError('Not enough values to substitute for all ? parameters in WHERE clause')
            where = self._where(where, values, fakeTable)
        if used < len(values):
            raise SnakeSQL.SQLSyntaxError('Not enough ? parameters or too many values specified')
        elif used > len(values):
            raise SnakeSQL.SQLSyntaxError('Not enough values to substitute for all ? parameters')
        self._checkDeleteConstraints(fakeTable, where)
        sql = self.connection.parser.buildDelete(table, where, limit)
        if execute == False:
            return sql
        else:
            self.info = None
            self._doDelete(sql, fakeTable, where, limit)
            return sql

    def _doDelete(self, sql, table, where, limit):
        self._execute(sql)

    def create(self, table, columns, values=[], execute=None): # XXX Needs values for parameter substitutions
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        if execute and self.tableExists(table):
            raise SnakeSQL.SQLError('Table %s already exists'%table)
        f = []
        for column in columns:
            if type(column) == type(''):
                f.append(self.column(column))
            elif type(column) in [type((1,2)), type([])]: 
                # We are using the previous version of the modules
                if len(column) != 2:
                    raise SnakeSQL.DataError('The create statement no longer takes lists of tuples for column names unless they are length 2. Instead use .column() to build columns')
                f.append(self.column(name=column[0], type=column[1]))
            else:
                f.append(column)
        used = 0
        for column in f:
            for param in ['name','type','required','unique','primaryKey','foreignKey','default']:
                if not column.has_key(param):
                    raise SnakeSQL.DataError('Expected the parameter %s in the column dictionary'%(repr(param)))
            for name in ['name', 'type']:
                if type(column['name']) != type(''):
                    raise SnakeSQL.DataError('Column %ss should be strings. %s is not a valid value.'%(name, repr(column['name'])))
            if column['primaryKey'] and column['default'] <> None:
                raise SnakeSQL.SQLError('A column cannot be a PRIMARY KEY and have a default value')
            if column['foreignKey'] and column['default'] <> None:
                raise SnakeSQL.SQLError('A column cannot be a FOREIGN KEY and have a default value')
            if column['primaryKey'] and column['foreignKey']:
                raise SnakeSQL.SQLError('A column cannot be a PRIMARY KEY and a FOREIGN KEY')
            if column['foreignKey']:
                column['foreignKey'] = self._prependTable(column['foreignKey']) # prepend field, take off later
            if column['default'] == '?':
                if len(values) > used:
                    column['default'] = self.connection.converters[column['type'].capitalize()].valueToSQL(values[used])
                    used += 1
                else:
                    raise SnakeSQL.SQLError('Too many ? parameters or not enough values specified')
        sql = ['CREATE TABLE ']
        sql.append(self._prependTable(table))
        sql.append(' (')
        sql.append(self._buildColumns(f))
        sql.append(')')
        sql = ''.join(sql)
        if execute == False:
            return sql
        else:
            values = []
            counter = 0
            columns = []
            for column in f:
                if column['foreignKey']:
                    column['foreignKey'] = self._removeTablePrepend(column['foreignKey']) # remove prepend
                columns.append(
                    self.connection.columnClass(
                        table = table,
                        name = column['name'],
                        type = column['type'].capitalize(),
                        required = column['required'],
                        unique = column['unique'],
                        primaryKey = column['primaryKey'],
                        foreignKey = column['foreignKey'],
                        default = column['default'],
                        position = counter,
                        converter = self.connection.converters[column['type'].capitalize()],
                    )
                )
                values.append([table, column['name'], column['type'], column['required'], column['unique'], column['primaryKey'], column['foreignKey'], column['default'], counter])
                counter += 1
            self.info = None
            self._execute(sql)
            self.connection.tables[table] = self.connection.tableClass(table, columns)
            self.connection._buildTableLinks()
            self._ignoreTableTest = True
            self.insertMany(
                table=self.connection.structureTableName,
                columns = ['TableName','ColumnName','ColumnType','IsRequired','IsUnique','IsPrimaryKey','ForeignKeyTable','DefaultValue','Position'],
                values = values
            )
            self._ignoreTableTest = False
            return sql
            
    def _buildColumns(self, columns):
        return self.connection.parser._buildColumns(columns)

    def drop(self, table, execute=None):
        "Remove a table from the database."
        # Add the prepend
        sql = self.connection.parser.buildDrop(self._prependTable(table))
        if execute == False:
            return sql
        else:
            if not self.tableExists(table):
                raise SnakeSQL.SQLError('Table %s does not exist'%table)
            self._checkDropConstraints(table)
            self.info = None
            self._ignoreTableTest = True
            self.delete(
                table=self.connection.structureTableName, 
                where="TableName='%s'"%table,
                execute=True
            )
            self._ignoreTableTest = False
            self.connection._buildTableLinks()
            self._execute(sql)
            del self.connection.tables[table]
            return sql
            

    def column(self, **params):
        values = {
            'name':None,
            'type':None,
            'required':0,
            'unique':0,
            'primaryKey':0,
            'foreignKey':None,
            'default':None,
        }
        #if params.has_key('value') and 
        for param in params:
            if not param in values.keys():
                raise SnakeSQL.SQLSyntaxError('Invalid parameter %s for column definition'%repr(param))
        for key in params.keys():
            values[key] = params[key]
        if values['name'] == None:
            raise SnakeSQL.InterfaceError("Parmeter 'name' not specified correctly for the column")
        if values['type'] == None:
            raise SnakeSQL.InterfaceError("Parmeter 'name' not specified correctly for the column")
        if values['primaryKey'] and values['default'] <> None:
            raise SnakeSQL.InterfaceError("A PRIMARY KEY column cannot also have a default value")
        if values['primaryKey'] and values['foreignKey'] <> None:
            raise SnakeSQL.InterfaceError("A PRIMARY KEY column cannot be a FOREIGN KEY value")
        if values['default'] and values['foreignKey'] <> None:
            raise SnakeSQL.InterfaceError("A FOREIGN KEY column cannot also have a default value")
        for i in ['required', 'unique', 'primaryKey']:
            if values[i] not in [0,1,True,False]:
                raise SnakeSQL.DataError("%s can be True or False, not %s"%([i],repr(values[i])))
        values['type'] = values['type'].capitalize()
        if values['type'].capitalize() not in self.types.keys():
            raise SnakeSQL.DataError("%s is not a recognised type"%(values['type'].capitalize()))
        if values['primaryKey'] and values['type'].upper() not in SQLParserTools.primaryKeyTypes:
            raise SnakeSQL.DataError("%s columns cannot be used as PRIMARY KEYs"%values['type'].capitalize())
        if values['default'] <> None and values['type'].upper() not in SQLParserTools.noDefaults:
            raise SnakeSQL.DataError("%s columns cannot be have a DEFAULT value"%values['type'].capitalize())
            
        #if values['default'] == 
        # XXX Type checking of default done later.
        # XXX Extra fields error
        return values
        # XXX Check foreign key details.
        
## Builders

    """
    Note on where functions:
    If table is None it is assumed the where clause only applies to one table and hence the full tableName.columnName
    way of doing things is not being used.
    """
    def _where(self, where, values=[], table=None):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        for block in where:
            if type(block) == type([]):
                #print block
                if block[0].count('.') == 0 and block[2].lower() == block[0].lower():
                    raise SnakeSQL.SQLError('The value %s in the where clause should be quoted or the column name should also have the table specified'%block[2])
                #else:
                #    print block[2].lower(), block[0].lower()
                if table == None: # We are using multiple tables
                    if block[0].count('.') == 1:
                        t, column = block[0].split('.')
                        if not self.tableExists(t):
                            raise SnakeSQL.SQLError('Table %s specified in WHERE clause does not exist'%repr(t))
                        elif not self.columnExists(t, column):
                            raise SnakeSQL.SQLError('Column %s in table %s specified in WHERE clause does not exist'%(repr(column),repr(t)))
                        else:
                            # Prepend the table
                            if block[2][0] <> "'":
                                if block[2][-1:] == "'":
                                    raise SnakeSQL.Bug('Invalid format of %s term in where clause, extra "\'" character'%block[2])
                                if block[2].upper() not in ['TRUE','FALSE','1','0']:
                                    t2, col2 = block[2].split('.')
                                    block[2] = self._prependTable(t2)+'.'+col2
                            block[0] = self._prependTable(t)+'.'+column
                    else:
                        raise SnakeSQL.SQLSyntaxError('Invalid column %s in WHERE clause, expected format tableName.columnName since using multiple tables'%(repr(block[0])))
                else:
                    if block[0].count('.') > 0:
                        # User has unnecessarily specified the table name too.
                        t, column = block[0].split('.')
                        if not self.tableExists(t):
                            raise SnakeSQL.SQLError('Table %s specified in WHERE clause does not exist'%repr(t))
                        elif not self.columnExists(t, column):
                            raise SnakeSQL.SQLError('Column %s in table %s specified in WHERE clause does not exist'%(repr(column),repr(t)))
                        else:
                            # Prepend the table
                            block[0] = self._prependTable(t)+'.'+column
                    #elif block[2]<>'?' and block[2][0] <> "'":
                    #    if not self.columnExists(table, block[2]):
                    #        raise SnakeSQL.SQLError('Column %s in table %s specified in WHERE clause does not exist'%(repr(block[2]),repr(table)))
                if block[2] == '?':
                    raise SnakeSQL.Bug("Found an unprocessed ? in 'where' parameter")
        return where

    def where(self, where, values=[], table=None, _ignoreParamErrors=False):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        #if type(where) <> type(''):
        #    raise SnakeSQL.SQLError("Expected 'where' to be a string")
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        used = 0
        for block in where:
            if type(block) == type([]):
                if block[2] == '?':
                    if block[1].lower() in ['is', 'is not'] and values[used] <> None:
                        raise SnakeSQL.SQLSyntaxError('NULL is the only value that can be used after the %s operator in the WHERE clause, not %s'%(repr(block[1].upper()), repr(values[used])))
                    if len(values) <= used:
                        raise SnakeSQL.SQLError('Not enough values to replace ? in WHERE clause')
                    else:
                        if table <> None: # Single table
                            column = block[0]
                            block[2] = self.connection.tables[table].get(column).converter.valueToSQL(values[used])
                        elif '.' in block[0]:
                            #table, column = block[0].split()
                            t, column = block[0].split('.')
                            block[2] = self.connection.tables[t].get(column).converter.valueToSQL(values[used])
                        else:
                            raise SnakeSQL.SQLSyntaxError('Invalid column %s in WHERE clause, expected format tableName.columnName since using multiple tables'%(repr(block[0])))
                        used += 1
        if not _ignoreParamErrors:
            return where
        else:
            #if len(values) > used:
            #    raise SnakeSQL.SQLSyntaxError('Not enough ? in WHERE clause or too many values sepcified, %s ? and %s values'%(used, len(values)))
            if len(values) < used:
                raise SnakeSQL.SQLSyntaxError('Not enough values sepcified to substitute all ? params in WHERE clause')
            else:
                return where, used

    def _order(self, order, table=None):
        for block in order:
            column = block[0]
            if table == None:# Multiple tables => No checking
                if '.' not in column:
                    raise SnakeSQL.SQLSyntaxError("Expected '.' in ORDER BY clause near %s since using multiple tables"%column)
                else:
                    table, col = column.split('.')
                    if not self.tableExists(table):
                        raise SnakeSQL.SQLError('No such table %s, error in ORDER BY clause near %s'%(table, col))
                    if not self.columnExists(table, col):
                        raise SnakeSQL.SQLError('No such column %s in table %s, error in ORDER BY clause'%(table, col))
                    block[0] = self._prependTable(table)+'.'+ col
            else:
                if '.' in column:
                    tab, col = column.split('.')
                    if not self.tableExists(tab):
                        raise SnakeSQL.SQLError('No such table %s, error in ORDER BY clause near %s'%(tab, col))
                    if not tab == table:
                        raise SnakeSQL.SQLError('Table %s specified in ORDER BY clause is not being selected from'%tab)
                    if not self.columnExists(tab, col):
                        raise SnakeSQL.SQLError('No such column %s in table %s, error in ORDER BY clause'%(tab, col))
                    block[0] = self._prependTable(tab)+'.'+ col
                else:
                    if not self.columnExists(table, column):
                        raise SnakeSQL.SQLError('No such column %s in table %s, error in ORDER BY clause'%(table, column))
        return order
        
    def order(self, order):
        if type(order) <> type(''):
            raise SnakeSQL.SQLError("Expected 'order' to be a string")
        order = self.connection.parser._parseOrder(order)
        return order
        
    def _function(self, function, table, column, where=None, values=[]):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        results = self.select(columns=[column], tables=[table], fetch=True, convert=True, format='tuple', where=where, values=values)
        if not results:
            return None
        else:
            if function=='max':
                r = max(results)
                return r[0]
            elif function=='min':
                r = min(results)
                return r[0]
            else:
                raise SnakeSQL.SQLError('Invalid function %s'%function)
            
    def max(self, table, column, where=None, values=[]):
        return self._function('max', table, column, where)

    def min(self, table, column, where=None, values=[]):
        return self._function('min', table, column, where)
        
    def count(self, table, where=None, values=[]):
        if type(values) not in [type([]), type((1,))]:
            raise SnakeSQL.SQLError('The parameter \'values\' should be a list not type %s'%(str(type(values))[7:-2]))
        results = self.select(columns=[self.connection.tables[table].columns[0].name], tables=[table], fetch=True, convert=True, format='tuple', where=where, values=values)
        if not results:
            return 0
        else:
            return len(results)
        
        #return self._function('count', table, where, values)