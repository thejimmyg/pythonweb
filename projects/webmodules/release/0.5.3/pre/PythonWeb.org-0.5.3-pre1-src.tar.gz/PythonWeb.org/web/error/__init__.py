"""Error Handling

The module exports two functions:

info()    - returns a dictionary with various representations of the error
handle()  - automatically handles any errors according to the options specified

And has one sub-module:

web.error.handler - provides some custom error handlers

The implementation for Python 2.1 and earlier differs slightly so the output will be slightly different
"""

import sys, os, types, time, pydoc, linecache
if sys.version_info[:2] == (2,4) or sys.platform == 'posix': # XXX Strange bug!
    import web.compat.only2_4.inspect as inspect
else:
    import inspect
import web.errors, web.error.handler

class Breakpoint(Exception):
    pass
    
if sys.version_info < (2,2):
    
    import sys, os, types, string, time, traceback
    import keyword, tokenize, linecache, inspect, pydoc
    
    class OldErrorInformation:
        def small(self, text): 
            return '<small>' + text + '</small>'
    
        def textCode(self, error=None, context=5):
            if error:
                (etype, evalue, etb) = error
            else:
                (etype, evalue, etb) = self.error
                
            return string.join(traceback.format_exception(etype, evalue, etb))
    
        def htmlCode(self, error=None, context=5):
            """Return a nice HTML document describing the traceback."""
            if error:
                (etype, evalue, etb) = error
            else:
                (etype, evalue, etb) = self.error
            indent = '<tt><small>%s</small>&nbsp;</tt>' % ('&nbsp;' * 5)
            frames = []
            records = inspect.getinnerframes(etb, context)
            for frame, file, lnum, func, lines, index in records:
                file = file and os.path.abspath(file) or '?'
                link = '<a href="file:%s">%s</a>' % (file, pydoc.html.escape(file))
                args, varargs, varkw, locals = inspect.getargvalues(frame)
                if func == '?':
                    call = ''
                else:
                    def eqrepr(value, repr=pydoc.html.repr): return '=' + repr(value)
                    call = 'in <strong>%s</strong>' % func + inspect.formatargvalues(
                            args, varargs, varkw, locals, formatvalue=eqrepr)
        
                names = []
                def tokeneater(type, token, start, end, line,
                               names=names, kwlist=keyword.kwlist,
                       NAME=tokenize.NAME, NEWLINE=tokenize.NEWLINE):
                    if type == NAME and token not in kwlist:
                        if token not in names: names.append(token)
                    if type == NEWLINE: raise IndexError
                def linereader(file=file, lnum=[lnum], getline=linecache.getline):
                    line = getline(file, lnum[0])
                    lnum[0] = lnum[0] + 1
                    return line
        
                try:
                    tokenize.tokenize(linereader, tokeneater)
                except IndexError: pass
                lvals = []
                for name in names:
                    if name in frame.f_code.co_varnames:
                        if locals.has_key(name):
                            value = pydoc.html.repr(locals[name])
                        else:
                            value = '<em>undefined</em>'
                        name = '<strong>%s</strong>' % name
                    else:
                        if frame.f_globals.has_key(name):
                            value = pydoc.html.repr(frame.f_globals[name])
                        else:
                            value = '<em>undefined</em>'
                        name = '<em>global</em> <strong>%s</strong>' % name
                    lvals.append('%s&nbsp;= %s' % (name, value))
                if lvals:
                    lvals = string.join(lvals, ', ')
                    lvals = indent + '''
    <small><font color="#909090">%s</font></small><br>''' % lvals
                else:
                    lvals = ''
        
                level = '''
    <table width="100%%" bgcolor="#d8bbff" cellspacing=0 cellpadding=2 border=0>
    <tr><td>%s %s</td></tr></table>\n''' % (link, call)
                excerpt = []
                if index is not None:
                    i = lnum - index
                    for line in lines:
                        num = '<small><font color="#909090">%s</font></small>' % (
                            '&nbsp;' * (5-len(str(i))) + str(i))
                        line = '<tt>%s&nbsp;%s</tt>' % (num, pydoc.html.preformat(line))
                        if i == lnum:
                            line = '''
    <table width="100%%" bgcolor="#ffccee" cellspacing=0 cellpadding=0 border=0>
    <tr><td>%s</td></tr></table>\n''' % line
                        excerpt.append('\n' + line)
                        if i == lnum:
                            excerpt.append(lvals)
                        i = i + 1
                frames.append('<p>' + level + string.join(excerpt, '\n'))
        
            #~ return string.join(frames)
            exception = ['<p><strong>%s</strong>: %s' % (str(etype), str(evalue))]
            if type(evalue) is types.InstanceType:
                for name in dir(evalue):
                    value = pydoc.html.repr(getattr(evalue, name))
                    exception.append('\n<br>%s%s&nbsp;=\n%s' % (indent, name, value))
                
            plaintrace = text()
                
            return '<!DOCformat HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" \n' + \
            ' "http://www.w3.org/TR/html4/loose.dtd">' + \
            '<html><head><title>Exception Occurred</title></head> ' + head \
           
            head + string.join(frames) + string.join(exception) + '''
    
    <!-- The above is a description of an error that occurred in a Python program.
         It is formatted for display in a Web browser because it appears that
         we are running in a CGI environment.  In case you are viewing this
         message outside of a Web browser, here is the original error traceback:
    
    %s
    -->
    ''' % plaintrace+ '</body></html>'
else:

    from cgitb import scanvars, lookup, grey, strong, small, __UNDEF__, reset, enable, Hook#, handler
    
    class NewErrorInformation:
        
        def textCode(self, error=None, context=None):
            if error:
                (etype, evalue, etb) = error
            else:
                (etype, evalue, etb) = self.error
            if context == None:
                context = self.context
            global file
            global highlight
            frames = []
            records = inspect.getinnerframes(etb, context)
            for frame, file, lnum, func, lines, index in records:
                file = file and os.path.abspath(file) or '?'
                args, varargs, varkw, locals = inspect.getargvalues(frame)
                call = ''
                if func != '?':
                    call = 'in ' + func + \
                        inspect.formatargvalues(args, varargs, varkw, locals,
                            formatvalue=lambda value: '=' + pydoc.text.repr(value))
                highlight = {}
                def reader(lnum=[lnum]):
                    highlight[lnum[0]] = 1
                    try: return linecache.getline(file, lnum[0])
                    finally: lnum[0] += 1
                vars = scanvars(reader, frame, locals)
                rows = [' %s %s' % (file, call)]
                if index is not None:
                    i = lnum - index
                    for line in lines:
                        num = '%5d ' % i
                        rows.append(num+line.rstrip())
                        i += 1
                done, dump = {}, []
                for name, where, value in vars:
                    if name in done: continue
                    done[name] = 1
                    if value is not __UNDEF__:
                        if where == 'global': name = 'global ' + name
                        elif where == 'local': name = name
                        else: name = where + name.split('.')[-1]
                        dump.append('%s = %s' % (name, pydoc.text.repr(value)))
                    else:
                        dump.append(name + ' undefined')
                rows.append('\n'.join(dump))
                frames.append('\n%s\n' % '\n'.join(rows))
                

            return ''.join(frames)
                
        def htmlCode(self, error=None, context=None):
            if error:
                (etype, evalue, etb) = error
            else:
                (etype, evalue, etb) = self.error
            if context == None:
                context = self.context
            global file
            global highlight
            indent = '<tt>' + small('&nbsp;' * 5) + '&nbsp;</tt>'
            frames = []
            records = inspect.getinnerframes(etb, context)
            for frame, file, lnum, func, lines, index in records:
                file = file and os.path.abspath(file) or '?'
                link = '<a href="file://%s">%s</a>' % (file, pydoc.html.escape(file))
                args, varargs, varkw, locals = inspect.getargvalues(frame)
                call = ''
                if func != '?':
                    call = 'in ' + strong(func) + \
                        inspect.formatargvalues(args, varargs, varkw, locals,
                            formatvalue=lambda value: '=' + pydoc.html.repr(value))
                highlight = {}
                def reader(lnum=[lnum]):
                    highlight[lnum[0]] = 1
                    try: return linecache.getline(file, lnum[0])
                    finally: lnum[0] += 1
                vars = scanvars(reader, frame, locals)
                rows = ['<tr><td bgcolor="#d8bbff">%s%s %s</td></tr>' %
                        ('<big>&nbsp;</big>', link, call)]
                if index is not None:
                    i = lnum - index
                    for line in lines:
                        num = small('&nbsp;' * (5-len(str(i))) + str(i)) + '&nbsp;'
                        line = '<tt>%s%s</tt>' % (num, pydoc.html.preformat(line))
                        if i in highlight:
                            rows.append('<tr><td bgcolor="#ffccee">%s</td></tr>' % line)
                        else:
                            rows.append('<tr><td>%s</td></tr>' % grey(line))
                        i += 1
                done, dump = {}, []
                for name, where, value in vars:
                    if name in done: continue
                    done[name] = 1
                    if value is not __UNDEF__:
                        if where in ['global', 'builtin']:
                            name = ('<em>%s</em> ' % where) + strong(name)
                        elif where == 'local':
                            name = strong(name)
                        else:
                            name = where + strong(name.split('.')[-1])
                        dump.append('%s&nbsp;= %s' % (name, pydoc.html.repr(value)))
                    else:
                        dump.append(name + ' <em>undefined</em>')
                rows.append('<tr><td>%s</td></tr>' % small(grey(', '.join(dump))))
                frames.append('''<p>
            <table width="100%%" cellspacing=0 cellpadding=0 border=0>
            %s</table>''' % '\n'.join(rows))
        
            return ''.join(frames)
        
class _ErrorInformation:
    
    def __init__(self, error, context=5, format='html'):
        self.error = error
        (etype, evalue, etb) = self.error
        self.pythonVersion = 'Python %s : %s' % (sys.version.split()[0], sys.executable)
        self.errorType = str(etype)
        self.errorValue = str(evalue)
        self.date = time.ctime(time.time())
        self.context = context
        self.format = format
        
    def output(self, output, format=None, error=None, context=None):
        if format == None:
            format = self.format
        if format not in ['html','text']:
            raise web.errors.ErrorHandlingError('%s is an invalid format'%repr(format))
        if error == None:
            error = self.error
        if context == None:
            context = self.context
        if output == 'code':
            return self.code(format, error, context)
        elif output == 'traceback':
            return self.traceback(format, error)
        elif output == 'debug':
            return self.debug(format, error, context)
        else:
            raise web.errors.ErrorHandlingError('%s is an invalid output type'%repr(output))
            
    def code(self, format=None, error=None, context=None):
        if format == None:
            format = self.format
        if format not in ['html','text']:
            raise web.errors.ErrorHandlingError('%s is an invalid output format'%repr(format))
        if error == None:
            error = self.error
        if context == None:
            context = self.context
        if format == 'html':
            return self.htmlCode(error, context)
        else:
            return self.textCode(error, context)

    def traceback(self, format=None, error=None):
        if format == None:
            format = self.format
        if format not in ['html','text']:
            raise web.errors.ErrorHandlingError('%s is an invalid output format'%repr(format))
        if error == None:
            error = self.error
        if format == 'html':
            return self.htmlException(error)
        else:
            return self.textException(error)

    def debug(self, format=None, error=None, context=None):
        if format == None:
            format = self.format
        if format not in ['html','text']:
            raise web.errors.ErrorHandlingError('%s is an invalid output format'%repr(format))
        if error == None:
            error = self.error
        if context == None:
            context = self.context
            
        if format == 'html':
            return self.html(error, context)
        else:
            return self.text(error, context)
            
    def _getTraceback(self, error=None):
        if error:
            (etype, evalue, etb) = error
        else:
            (etype, evalue, etb) = self.error

        tracebackString = ''
        if not tracebackString:
            import traceback
            tracebackString = ''.join(traceback.format_exception(etype, evalue, etb))
        return tracebackString
        
    def _reset(self):
        """Return a string that resets the CGI and browser to a known state."""
        return '''<!--: spam
    Content-Type: text/html
    
    <body bgcolor="#f0f0f8"><font color="#f0f0f8" size="-s5"> -->
    <body bgcolor="#f0f0f8"><font color="#f0f0f8" size="-5"> --> -->
    </font> </font> </font> </script> </object> </blockquote> </pre>
    </table> </table> </table> </table> </table> </font> </font> </font>'''
    
    
    def html(self, error=None, context=None):
        """Return a nice HTML document describing a given traceback."""
        if error:
            (etype, evalue, etb) = error
        else:
            (etype, evalue, etb) = self.error
        if context == None:
            context = self.context
        if type(etype) is types.ClassType:
            etype = etype.__name__
        pyver = 'Python ' + sys.version.split()[0] + ': ' + sys.executable
        date = time.ctime(time.time())
        head = '<body bgcolor="#f0f0f8">' + pydoc.html.heading(
            '<big><big><strong>%s</strong></big></big>' % self.errorType,
            '#ffffff', '#6622aa', self.pythonVersion + '<br>' + self.date) + '''
    <p>A problem occurred in a Python script.  Here is the sequence of
    function calls leading up to the error, in the order they occurred.'''
        htmlCode = self.htmlCode(error=error, context=context)
        htmlException = self.htmlException(error=error)

        return  '<!DOCformat HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" \n' + \
        '    "http://www.w3.org/TR/html4/loose.dtd">' + \
        '<html><head><title>Exception Occurred</title></head>' \
        + self._reset() + head + self.htmlCode() + self.htmlException() + '''
    
    <!-- The above is a description of an error in a Python program, formatted
         for a Web browser because the 'cgitb' module was enabled.  In case you
         are not reading this in a Web browser, here is the original traceback:
    
    %s
    -->
    ''' % self._getTraceback((etype, evalue, etb)) + '</body></html>'
    
    
    def text(self, error=None, context=None):
        """Return a plain text document describing a given traceback."""
        if error:
            (etype, evalue, etb) = error
        else:
            (etype, evalue, etb) = self.error
        if context == None:
            context = self.context

        head = "%s\n%s\n%s\n" % (self.errorType, self.pythonVersion, self.date) + '''
    A problem occurred in a Python script.  Here is the sequence of
    function calls leading up to the error, in the order they occurred.
    '''
        return head + self.textCode() + self.textException() + '''
    
    The above is a description of an error in a Python program.  Here is
    the original traceback:
    
    %s
    ''' % self._getTraceback((etype, evalue, etb))
        
    def textException(self, error=None):
        if error:
            (etype, evalue, etb) = error
        else:
            (etype, evalue, etb) = self.error
        indent = " "*4
        sep = '%s: %s'
        esep = '\n%s%s = %s'
        strongStart = ''
        strongEnd = ''
        format = pydoc.text.repr

        return self._buildException((etype, evalue, etb), indent, sep, esep, strongStart, strongEnd, format)
        
    def htmlException(self, error=None):
        if error:
            (etype, evalue, etb) = error
        else:
            (etype, evalue, etb) = self.error
        indent = '<tt>' + small('&nbsp;' * 5) + '&nbsp;</tt>'
        sep = '<p>%s: %s'
        esep = '\n<br>%s%s&nbsp;=\n%s'
        strongStart = '<strong>'
        strongEnd = '</strong>'
        format = pydoc.html.repr
        return self._buildException((etype, evalue, etb), indent, sep, esep, strongStart, strongEnd, format)
        
    def _buildException(self, (etype, evalue, etb), indent, sep, esep, strongStart, strongEnd, format):
        exception = [sep % (strongStart+str(etype)+strongEnd, str(evalue))]
        if type(evalue) is types.InstanceType:
            for name in dir(evalue):
                if name[:1] == '_': continue
                value = format(getattr(evalue, name))
                exception.append(esep % (indent, name, value))
        return ''.join(exception)

# These two methods provide the public interface

def error(**params):
    "Return an ErrorInformation object or its output suitable for printing depending on parameters specified"
    if sys.version_info < (2,2):
        class ErrorInformation(_ErrorInformation, OldErrorInformation):
            pass
    else:
        class ErrorInformation(_ErrorInformation, NewErrorInformation):
            pass
    if params.has_key('error'):
        error = params['error']
        del params['error']
    else:
        error = sys.exc_info()
    return ErrorInformation(error, **params)
    
def info(output='debug', **params):
    "Return error information in the format specified"
    return error(**params).output(output)

def handle(handler=None, **params):
    #print sys.exc_info()
    "Automatically catch errors and handle the results"
    if handler == None:
        handler = 'browser'
    sys.excepthook = WebExceptHook(handler, **params)

class WebExceptHook:
    def __init__(self, handler, **params):
        self.handler = handler
        self.params = params

    def __call__(self, etype, evalue, etb):
        
        self.handle((etype, evalue, etb))
        
    def handle(self, traceback=None):
        traceback = traceback or sys.exc_info()
        if type(self.handler) == type(''):
            if self.handler not in web.error.handler.handlers.keys():
                raise web.errors.ErrorHandlingError('No such handler %s'%self.handler)
            else:
               self.handler = web.error.handler.handlers[self.handler]
        self.params['error'] = traceback
        self.handler(**self.params)
