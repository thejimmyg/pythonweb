"Utility functions"

from tablePrint import table
def wrap(text, width):
    """
    A word-wrap function that preserves existing line breaks
    and most spaces in the text. Expects that existing line
    breaks are posix newlines (\n).
    """
    return reduce(
        lambda line, word, width=width: '%s%s%s' %(
            line,
            ' \n'[(len(line[line.rfind('\n')+1:]) + len(word.split('\n',1)[0]) >= width)],
            word,
        ),
        text.split(' ')
    )

def convertConfig(config):
    
    class lowerDict:
        def __init__(self, dict):
            self.__dict = dict
        def __getitem__(self, name):
            return self.__dict[name.lower()]
        def __setitem__(self, name, value):
            self.__dict[name.lower()] = value
            
    dict = lowerDict({})
    for section in config.sections():
        dict[section] = lowerDict({})
        for option in config.options(section):
            dict[section][option] = config.get(section, option)
    return dict
    
import sgmllib, string

class StrippingParser(sgmllib.SGMLParser):

    from htmlentitydefs import entitydefs # replace entitydefs from sgmllib
    
    def __init__(self, validTags=[]): # valid_tags are the HTML tags that we will leave intact
        sgmllib.SGMLParser.__init__(self)
        self.result = ""
        self.endTagList = [] 
        self.valid_tags = validTags
        
    def handle_data(self, data):
        if data:
            self.result = self.result + data

    def handle_charref(self, name):
        self.result = "%s&#%s;" % (self.result, name)
        
    def handle_entityref(self, name):
        if self.entitydefs.has_key(name): 
            x = ';'
        else:
            # this breaks unstandard entities that end with ';'
            x = ''
        self.result = "%s&%s%s" % (self.result, name, x)
    
    def unknown_starttag(self, tag, attrs):
        """ Delete all tags except for legal ones """
        if tag in self.valid_tags:       
            self.result = self.result + '<' + tag
            for k, v in attrs:
                if string.lower(k[0:2]) != 'on' and string.lower(v[0:10]) != 'javascript':
                    self.result = '%s %s="%s"' % (self.result, k, v)
            endTag = '</%s>' % tag
            self.endTagList.insert(0,endTag)    
            self.result = self.result + '>'
                
    def unknown_endtag(self, tag):
        if tag in self.valid_tags:
            self.result = "%s</%s>" % (self.result, tag)
            remTag = '</%s>' % tag
            self.endTagList.remove(remTag)

    def cleanup(self):
        """ Append missing closing tags """
        for j in range(len(self.endTagList)):
                self.result = self.result + self.endTagList[j]    
        

def strip(html, validTags=[]):
    """Strip illegal HTML tags from string"""
    parser = StrippingParser(validTags)
    parser.feed(html)
    parser.close()
    parser.cleanup()
    return parser.result
    


def prepareDict(params, defaults={}, required=[], exclude=[], excludeAndRaiseIfNotPresent=[]):
    for key in required:
        if not params.has_key(key):
            raise Exception("Parameter '%s' not found.")
    for key in excludeAndRaiseIfNotPresent:
        if not params.has_key(key):
            raise Exception("Parameter '%s' not found and so cannot be excluded.")
        else:
            del params[key]
    dict = {}
    for k, v in defaults.items():
        if not(k in exclude or k in excludeAndRaiseIfNotPresent):
            dict[k] = v
    for k, v in params.items():
        if not(k in exclude or k in excludeAndRaiseIfNotPresent):
            dict[k] = v
    return dict