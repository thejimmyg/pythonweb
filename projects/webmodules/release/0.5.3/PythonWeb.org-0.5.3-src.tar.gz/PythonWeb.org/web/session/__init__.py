"""Sessions

Changes
=======

2005-02-03

* Default behaviour of setCookie is to set to the current Session Expire time if maxAge is not specified. This 
  requires setting the default of self.expireTime to be the correct expire length.

2005-02-28

* SessionManager:
    * seed and cleanupProbability parameters changed to _seed and _cleanupProbability to make it clear that they are not important parameters
    * _genSessionID() now no longer takes the seed parameter but instead takes the value from self._seed
    * web.session.manager() and web.session.start() now use a cookie parameter for all cookie parameters rather than induvidually specifying them
    * _checkCookieParams() has been removed - the options are checked in __init__
    * If the cookie dictionary doesn't have max-age specified, max-age takes the value of expire
    * If max-age is None the max-age cookie option is not set
    * Any methods which used to allow you to specify maxAge now do not except for _setCookieString
    * True replaced by 1 and False replaced by 0 for Python < 2.2 support
    * genSessionID(), deleteCookieString() and setCookieString replcaed by _genSessionID(), _deleteCookieString() and _setCookieString, 
    * setExpire() now has an option to update the cookie
    * setCookie takes param _cookieString=None allowing you to specify the cookie to set

2005-04-05

* autoSetup option
* Removed driver() (integrated with manager) and replaced manager() with the class definition

2005-04-08
* _genSessionID removed
* SessionID generation code improved (bugfix)
"""

import time, random, Cookie, md5, base64
from web.errors import SessionError, SessionWarning

cookieDefaults = {
    'comment':'Built with the Python Web Modules at www.pythonweb.org',
    'version':1,
}

class SessionManager:
    "Session manager class for managing the creation, destruction, loading, checking etc of sessions"
    # Underscored methods do not check things exist as it is assumed they do if the manager has a sessionID. This 
    # is safe accept in the case you cleanup sessions for sessions with an expire time in the future or 
    # another application destroys the session

    def __init__(self, driver, expire=86400, cookie=cookieDefaults, _seed='PythonWeb', _cleanupProbability=0.05, autoCreate=0, **driverParams):

        if driver == 'database':
            import drivers.database
            self._driver = drivers.database.DatabaseSessionDriver(**driverParams)
        else:
            raise SessionError('No such driver %s'%driver)
            
        self.autoCreate = autoCreate
        self.autoCreated = 0
        if self.autoCreate:
            if not self.completeSessionEnvironment():
                self.removeSessionEnvironment(ignoreErrors=True)
                self.createSessionEnvironment()
                self.autoCreated = 1

        # Check cookie options
        self.cookie = {}
        for key in cookie.keys():
            if key not in ['path','domain','comment','secure','max-age','version']:        
                raise SessionError("'%s' is not a known key for a cookie dictionary."%key)
            self.cookie[key] = cookie[key]
        if not self.cookie.has_key('max-age'):
            self.cookie['max-age'] = expire
        elif self.cookie['max-age'] == None:
            del self.cookie['max-age']
        # setup member variables
        self.response_headers = []
        self.sent_headers = []
        self.expireTime = int(expire + time.time())
        self.driver = driver
        self.expire = expire
        self.created = 0
        self.sessionID = None
        self._cleanupProbability = _cleanupProbability
        self._seed = _seed
        # Remove unwanted sessions
        if random.random() < float(self._cleanupProbability):
            self.cleanup()

    #
    # Environment
    #
    
    def createSessionEnvironment(self):
        return self._driver.createSessionEnvironment()
        
    def removeSessionEnvironment(self, ignoreErrors=True):
        return self._driver.removeSessionEnvironment(ignoreErrors)
        
    def completeSessionEnvironment(self):
        return self._driver.completeSessionEnvironment()

    def sendCookieHeaders(self):
        for part, info in self.response_headers:
        #for part, info, result in self.response_headers:
            header = '%s: %s'%(part, info)
            #self.sent_headers.append((header, result))
            self.sent_headers.append(header)
            print header
        self.response_headers = []
        
    def load(self, sessionID=None):
        if sessionID == None:
            sessionID = self.cookieSessionID()
        error, expireTime = self._driver.load(sessionID)
        if error:
            return 0
        else:
            self.sessionID = sessionID
            self.expireTime = expireTime
            return 1

    def cleanup(self, min=None, max=None, ignoreWarning=0):
        if min > max:
            raise SessionError('The minimum expire time to cleanup cannot be greater than the maximum, min=%s max=%s'%(min,max))
        if not min:
            min = 0
        if not max:
            max = int(time.time())
        elif max > int(time.time()):
            if not ignoreWarning:
                raise SessionWarning('It is dangerous to set max greater than the current time as this removes sessions that have not yet expired and maybe in use by other applications as it may cause them to crash. This error can be ignored by setting ignoreWarning==True')
        self._driver.cleanup(min, max)
    
    def valid(self, sessionID=None):
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        return self._driver.valid(sessionID)

    def exists(self, sessionID=None):
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        return self._driver.exists(sessionID)

    def destroy(self, sessionID=None, sendCookieHeaders=1, ignoreWarning=0):
        """End a session and if removeCookie=True remove the session cookie."""
        if sessionID == None:
            sessionID = self.sessionID
        if sessionID == None:
            raise SessionError('No session has been loaded')
        if not ignoreWarning:
            raise SessionWarning('It is dangerous to destroy a session as it may be in use by other applications which may cause them to crash. If you wish to remove the information for this application only use the empty() method of the store object for the particular app. This error can be ignored by setting ignoreWarning=True')
        destroy = self._driver.destroy(sessionID)
        self.deleteCookie(sendCookieHeaders)
        return destroy

    def create(self, sendCookieHeaders=1, expire=None):
        """Private method to start a new session."""
        if self.sessionID:
            raise SessionError('The session %s already exists, you cannot create a new session without destroying the old one'%self.sessionID)
        if expire == None:
            expire = self.expire

        # Only try and create a new ID 100 times.. after that something is going wrong!
        counter = 0
        sessionID = ''
        m = md5.new()
        m.update('this is a test of the emergency broadcasting system')
        m.update(self._seed)
        r = random.Random(str(time.time()))
        while 1:
            counter += 1
            if counter > 100:
                raise SessionError('Could not create valid SessionID.')
            else:
                m.update(str(r.random()))
                session = base64.encodestring(m.digest())[:-3].replace('/', '$')
                session = session.replace('+','p')
                session = session.replace('$','d')
                session = session.replace('\\','b')
                session = session.replace('/','f')
                sessionID = session
                if not self.exists(sessionID):
                    break
        self.sessionID = sessionID
        self.setCookie(sendCookieHeaders)
        self._driver.create(sessionID, int(time.time() + expire))
        self.created = 1
        return self.sessionID

    def store(self, app):
        return SessionStore(self._driver, self.sessionID, app, self)

    def setExpire(self, expireTime, sessionID=None, setCookie=0, sendCookieHeaders=0):
        "Shouldn't need to update the Expire"
        expireTime = int(expireTime)
        if sessionID == None:
            sessionID = self.sessionID
        if self.sessionID == None:
            raise SessionError('No session has been loaded')
        if expireTime < time.time():
            raise SessionError('You cannot update a session with a time less than the current time. If you wish to destroy a session use destroy()')
        r = self._driver.setExpire(expireTime, sessionID)
        self.expireTime = expireTime
        if sendCookieHeaders or setCookie:
            self.setCookie(sendCookieHeaders, self._setCookieString(maxAge=int(self.expireTime-time.time())+1))
        return r

    def cookieSessionID(self, environ=None, noSessionID=''):
        """Read and return the sessionID from the HTTP_COOKIE environment variable"""
        sessionID=''
        if environ==None:
            import os
            environ = os.environ
        try:
            cookie = environ["HTTP_COOKIE"]
        except KeyError:
            pass
        else:
            c2 = Cookie.SimpleCookie()
            c2.load(environ["HTTP_COOKIE"])
            try:
                sessionID=c2['sessionID'].value
            except:
                pass
        if sessionID: 
            if len(sessionID)>32:
                # raise SessionError('The Session ID is invalid. Session IDs should be 32 characters long.')
                return noSessionID
            return sessionID
        else:
            return noSessionID
            
    def setCookie(self, sendCookieHeaders=0, _cookieString=None):
        "Internal method to add cookie header to header list"
        if _cookieString == None:
            _cookieString = self._setCookieString()
        result = _cookieString.split(': ')
        part = result[0]
        if type(result[1]) != type(''):
            info = ': '.join(result[1:])
        else:
            info = result[1]
        self.response_headers.append((part, info))
        if sendCookieHeaders:
            self.sendCookieHeaders()

    def deleteCookie(self, sendCookieHeaders=0):
        result = self._deleteCookieString().split(': ')
        part = result[0]
        if type(result[1]) != type(''):
            info = ': '.join(result[1:])
        else:
            info = result[1]
        self.response_headers.append((part, info))
        if sendCookieHeaders:
            self.sendCookieHeaders()
            
    def _setCookieString(self, maxAge=None):
        """Private method to set the session cookie with the options specified by the cookie param"""
        # Create a cookie dictionary object
        c = Cookie.SimpleCookie()
        c['sessionID'] = self.sessionID
        for k, v in self.cookie.items():
            if v <> None:
                c['sessionID'][k] = v
        if maxAge <> None:
            c['sessionID']['max-age'] = maxAge
        return str(c)
        
    def _deleteCookieString(self):
        """Private method to remove session cookie."""
        return self._setCookieString(0)


class SessionStore:
    "Session store class for manipluating the values in the store or a particular application"
    def __init__(self, driver, sessionID, app, manager):
        if not app:
            raise SessionError('No app name has been specified')
        self.app = app
        self._driver = driver
        self.sessionID = sessionID
        self.manager = manager

    def set(self, key, value):
        "Public method to set a session variable. 'value' can be anything that can be pickled."
        return self._driver.set(self.sessionID, self.app, key, value)

    def get(self, key):#, otherwise):
        "Public method to retrieve a session variable."
        return self._driver.get(self.sessionID, self.app, key)#, otherwise)

    def delete(self, key):
        "Public method to remove a session variable."
        return self._driver.delete(self.sessionID, self.app, key)

    def empty(self):
        "Delete all values in the store for this application"
        return self._driver.empty(self.sessionID, self.app)
        
    def has_key(self, key):
        "Returns True if the key 'key' exists otherwise False."
        try:
            self.get(key)
        except SessionError:
            return 0
        else:
            return 1

    def keys(self):
        "Returns a list of store keys"
        return self._driver.keys(self.sessionID, self.app)
        
    def items(self):
        "Returns a list of store keys"
        return self._driver.items(self.sessionID, self.app)
        
    def values(self):
        "Returns a list of store keys"
        return self._driver.values(self.sessionID, self.app)
        
    def __getitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        return self.get(key)

    def __setitem__(self, key, value):
        "Allows the use of a dictionary-style interface to the session class."
        return self.set(key,value)
        
    def __delitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        return self.delete(key)

manager = SessionManager