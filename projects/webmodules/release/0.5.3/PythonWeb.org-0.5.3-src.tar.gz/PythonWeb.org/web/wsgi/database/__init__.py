"Database Access"

import web.wsgi.base

class Database(web.wsgi.base.BaseMiddleware):
    
    def __init__(self, application, **params):
        import web.database
        self.params = params
        self.application = application
    
    def environ(self, environ):
        for key in ['web.database.connection', 'web.database.cursor']:
            if environ.has_key(key):
                raise Exception('environ already has database keys')
        if self.params.has_key('connection'):
            if len(self.params) > 1:
                raise Exception('If connection is specified you cannot specify other variables')
            connection = self.params['connection']
        else:
            connection = web.database.connect(**self.params)
        environ['web.database.connection'] = connection
        environ['web.database.cursor'] = connection.cursor()
        # XXX Defaults
        return environ