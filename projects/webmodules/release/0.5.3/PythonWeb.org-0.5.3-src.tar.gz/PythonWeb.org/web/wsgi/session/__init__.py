"Session Handling"

import web.wsgi.base
import web.session
from web.errors import SessionError

class Session(web.wsgi.base.BaseMiddleware):
    """Session handling middleware"""

    def __init__(self, application, **params):
        self.application = application
        self._newHeaders = []
        self.params = params

    def environ(self, environ):
        if not self.params.has_key('driver'):
            raise SessionError('No driver specified')
        if self.params['driver'] <> 'database':
            raise SessionError('Invalid driver %s'%self.driver)
        if not self.params.has_key('cursor'):
            if not environ.has_key('web.database.cursor'):
                raise SessionError('No database cursor available')
            else:
                self.params['cursor'] = environ['web.database.cursor']
        manager = web.session.manager(
            **self.params
        )
        sid = manager.cookieSessionID(environ)
        if not manager.load(sid):
            manager.create(sendCookieHeaders=False)
            self._newHeaders = [manager.response_headers[-1]]
        environ['web.session'] = manager
        return environ

    def headers(self, headers):
        "This method allows you to make changes to headers. You should return headers"
        for header in headers:
            self._newHeaders.append(header)        
        return self._newHeaders
        