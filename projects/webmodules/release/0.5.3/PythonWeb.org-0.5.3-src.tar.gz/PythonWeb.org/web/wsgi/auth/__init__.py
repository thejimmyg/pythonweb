"""Authorization middleware.. if the headers are a 403 error then a form is displayed with the error 
and the headers are modified to display that form.

The session middleware requires the following environ entries:
web.database.connection
web.session.manager
"""

import sys
import web.wsgi, web.wsgi.base
import web.auth, web.auth.handler.signIn
from web.errors import AuthError

class Auth(web.wsgi.base.BaseMiddleware):
    def __init__(self, application, driver, store=None, expire=0, idle=0, autoCreate=0, encryption=None, app='auth', 
        template='<html><body><h1>Please Sign In</h1>%(form)s<p>%(message)s</p></body></html>',
        redirectMethod='http', **driverParams
    ):
        self.application = application
        self.driver = driver
        self.store = store
        self.expire = expire
        self.idle = idle
        self.autoCreate = autoCreate
        self.encryption = encryption
        self.app = app
        self.driverParams = driverParams
        self.template = template
        self.redirectMethod = redirectMethod

    def setup(self):
        self._newHeaders = []
        self._newResult = None
        
    def environ(self, environ):
        if self.store == None:
            if not environ.has_key('web.session'):
                raise AuthError('No session store specified and no session manager available')
            else:
                self.store = environ['web.session'].store(self.app)
        if self.driver <> 'database':
            raise AuthError('Invalid driver %s'%self.driver)
        if not self.driverParams.has_key('cursor'):
            if not environ.has_key('web.database.cursor'):
                raise AuthError('No database cursor available')
            else:
                self.driverParams['cursor'] = environ['web.database.cursor']
        environ['web.auth'] = web.auth.manager(
            self.store, 
            self.driver, 
            self.expire, 
            self.idle, 
            self.autoCreate, 
            **self.driverParams
        )
        if environ['web.auth'].signedInUser:
            environ['web.auth.user'] = environ['web.auth'].signedInUser
            environ['REMOTE_USER'] = environ['web.auth.user'].username
        self._environ = environ
        return environ

    def status(self, status):
        if status[:4] == '403 ':
            if not self.store.has_key('redirect') and \
                not (self._environ['web.cgi'].has_key('mode') and \
                self._environ['web.cgi']['mode'].value == 'signOut'):
                self.store['redirect'] = web.wsgi.currentURL(self._environ)
            signInHandler = web.auth.handler.signIn.SignInHandler(
                manager=self._environ['web.auth'], 
                cgi=self._environ['web.cgi'],
                message = status[4:],
                encryption = self.encryption
            )
            form = signInHandler.handle()
            if form: # ie there is a problem and the sign in form needs displaying
                self._newResult = self.template%form
                self._newHeaders = [('Content-type','text/html')]
            else:
                url = self.store['redirect']
                # Use the session store to cache the URL for redirect
                if self.redirectMethod == 'metaRefresh':
                    self._newResult = """<HTML>
                    <HEAD>
                    <META HTTP-EQUIV="refresh" content="0;URL=%s">
                    <TITLE>Redirecting to original page</TITLE>
                    </HEAD>
                    <BODY>
                    <!-- Signed in but not using app
                    %s -->
                    </BODY>
                    </HTML>"""%(url, status[4:])
                    self._newHeaders = [('Content-type','text/html')]
                elif self.redirectMethod == 'http':
                    self._newHeaders = [('Location', url)] 
                    self._newResult = None
                else:
                    raise Exception('Invalid redirectMethod specified')
                del self.store['redirect']
        return status
        
    def headers(self, headers): # Return the new headers if we are displaying a form
        if len(self._newHeaders)>0:
            return self._newHeaders
        else:
            return headers
            
    def result(self, result):
        if self._newResult != None:
            return [self._newResult]
        else:
            return result
