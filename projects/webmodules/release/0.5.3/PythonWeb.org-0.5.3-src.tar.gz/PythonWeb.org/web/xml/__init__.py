"XML processing functions. Not written yet. Will include libxml2 and libxslt wrappers."

def transform(input, stylesheet, output):
    
    import libxml2
    import libxslt
    
    styledoc = libxml2.parseFile(stylesheet)
    style = libxslt.parseStylesheetDoc(styledoc)
    doc = libxml2.parseFile(input)
    result = style.applyStylesheet(doc, None)
    style.saveResultToFilename(output, result, 0)
    style.freeStylesheet()
    doc.freeDoc()
    result.freeDoc()
