"""Auth functions

XXX Multiple sign in mode?
# Encryption type shouldn't be stored in the database


Example:

auth = web.auth.setup(session, 'database', cursor=cursor) # session is a session store for the user, cursor is a valid database cursor

if not auth.signedInUser:
    print web.redirect('signIn.py')
elif not auth.signedInUser.authorize(app='app', group='group', role='role'):
   print web.redirect('signIn.py?user=%s'%user.username)
else:
    print web.header('text/plain'), "Authenticated"

autoCreated = 0
"""

import time, md5
import web.auth

from web.errors import AuthError

class AuthSession:
    
    def __init__(self, store, expire=0, idle=0):
        self.store = store
        self.expire = expire
        self.idle = idle
        self.signedInUser = self.user()

    #
    # Session Functions (These functions do not authorisation or authentication, they just store auth session information
    #

    def signOut(self):
        if self.store.has_key('username'):
            del self.store['username']
        if self.store.has_key('started'):
            del self.store['started']
        if self.store.has_key('accessed'):
            del self.store['accessed']
        if self.store.has_key('expire'):
            del self.store['expire']
        if self.store.has_key('idle'):
            del self.store['idle']
        self.signedInUser = None

    def signIn(self, username):

        username = username.lower()
        currentTime = int(time.time())
        self.store['username'] = username.lower()
        self.store['started']  = currentTime
        self.store['accessed'] = currentTime
        self.store['expire']   = self.expire
        self.store['idle']     = self.idle
        self.signedInUser = self.user()
        
    def username(self):
        if self.store.has_key('username'): # We have signed in in the past
            started  = self.store['started']
            accessed = self.store['accessed']
            currentTime  = int(time.time())
            if self.expire and ((self.expire + started) <= currentTime): 
                # store Expired
                self.signOut()
                return None
            elif self.idle and ((self.idle + accessed) <= currentTime): 
                # store Idled
                self.signOut()
                return None
            else:
                self.store['accessed'] = int(time.time())
                return self.store['username']
        else:
            # No username
            return None

    def userInfo(self): # Changed
        username = self.username()
        if username:
            return {
                'username':username,
                'started' :self.store['started'],
                'accessed':self.store['accessed'],
                'expire'  :self.store['expire'],
                'idle'    :self.store['idle'],
            }
        else:
            return None

class AuthAdmin:
    def __init__(self, driver, autoCreate=0, encryption=None, **driverParams):
        self.autoCreate = autoCreate
        if driver == 'database':
            import drivers.database
            self._driver = drivers.database.DatabaseAuthDriver(**driverParams)
        else:
            raise AuthError('No such driver %s'%driver)
        self.autoCreated = 0
        if self.autoCreate:
            if not self.completeAuthEnvironment():
                self.removeAuthEnvironment(ignoreErrors=True)
                self.createAuthEnvironment()
                self.addApp('app')
                self.addUser(
                    'john',
                    'bananas',
                    'John',
                    'Smith',
                    'johnsmith@example.com',
                )
                self.setLevel('john', 'app', 1)
                self.autoCreated = 1

        self.encryption = encryption
        if self.encryption not in [None, 'md5']:

            raise AuthError('Invalid encryption format %s'%self.encryption)
    #
    # Manager Functions
    #

    def user(self, username):

        username = username.lower()
        userInfo = {
            'username':username,
            'started' :None,
            'accessed':None,
            'expire'  :None,
            'idle'    :None,
        }
        return AuthUser(self._driver, userInfo, self.encryption)

    #
    # Environment
    #
    
    def createAuthEnvironment(self):
        return self._driver.createAuthEnvironment()
        
    def removeAuthEnvironment(self, ignoreErrors=True):
        return self._driver.removeAuthEnvironment(ignoreErrors)
        
    def completeAuthEnvironment(self):
        return self._driver.completeAuthEnvironment()
        
    #
    # Applications
    #
    
    def apps(self):
        return self._driver.apps()
        
    def appExists(self, app):
        return self._driver.appExists(app)
            
    def addApp(self, app):
        return self._driver.addApp(app)
        
    def removeApp(self, app, force=0):
        return self._driver.removeApp(app, force)

    #
    # Users
    #
    
    def userExists(self, username):
        username = username.lower()
        return self._driver.userExists(username)
        
    def addUser(self, username, password, firstname='', surname='', email='', active=1, group=None): # CHANGED
        username = username.lower()
        if self.encryption == 'md5':
            password = md5.new(password).hexdigest()
        return self._driver.addUser(username, password, firstname, surname, email, active, group)
        
    def removeUser(self, username):
        username = username.lower()
        return self._driver.removeUser(username)
        
    def users(self, group=[], active=None, app=None, role=None):
        return self._driver.users(group, active, app, role)
        
    #
    # Access Levels
    #

    def levels(self, username, app=None):
        username = username.lower()
        return self._driver.levels(username, app)

    def setLevel(self, username, app, level):
        username = username.lower()
        return self._driver.setLevel(username, app, level)

    #
    # Roles
    # 
    
    def addRole(self, role):
        return self._driver.addRole(role)

    def roleExists(self, role):
        return self._driver.roleExists(role)

    def removeRole(self, role, force=0):
        return self._driver.removeRole(role, force)

    def roles(self, username=None, app=None):
        if username != None: 
            username = username.lower()
        return self._driver.roles(username, app)

    def setRole(self, username, app, role):
        username = username.lower()
        return self._driver.setRole(username, app, role)

    def unsetRole(self, username, app, role):
        username = username.lower()
        return self._driver.unsetRole(username, app, role)
        
    #
    # Groups
    #

    def groupExists(self, group):
        return self._driver.groupExists(group)
        
    def addGroup(self, group):
        return self._driver.addGroup(group)

    def removeGroup(self, group, force=0):
        return self._driver.removeGroup(group, force)
    
    def groups(self):
        return self._driver.groups()

class AuthUser:
    def __init__(self, driver, userInfo, encryption):
        self.__dict__['_driver']    = driver
        self.__dict__['encryption'] = encryption
        if self.encryption not in [None, 'md5']:
            raise AuthError('Invalid encryption format %s'%self.encryption)
        self.__dict__['username']   = userInfo['username']
        self.__dict__['started']    = userInfo['started']
        self.__dict__['accessed']   = userInfo['accessed']
        self.__dict__['expire']     = userInfo['expire']
        self.__dict__['idle']       = userInfo['idle']
        user            = self._driver.user(self.username)
        self.__dict__['password']   = user['password']
        self.__dict__['firstname']  = user['firstname']
        self.__dict__['surname']    = user['surname']
        self.__dict__['email']      = user['email']
        self.__dict__['levels']     = user['levels']
        self.__dict__['roles']      = user['roles']
        self.__dict__['active']     = user['active']
        self.__dict__['group']      = user['group']

    def authorise(self, app=None, level=None, role=None, active=1, group=[]):
        if active not in [1,0,None]:
            raise AuthError('active can only be True, False or None, not %s'%repr(active))
        if app != None and level == None and role==None:
            raise AuthError('You must specify a role or access level as well as the app')
        if group != []:
            if not self._driver.groupExists(group):
                raise AuthError('No such group %s'%repr(group))
            elif self.group != group:
                return False
        if active in [1,0] and self.active != active:
            return False
        if level != None or role != None:
            if app == None:
                raise AuthError('app must be specified if level or role are specified')
            if level != None and (not self.levels.has_key(app) or self.levels[app] < level):
                return False
            if role != None and (not self.roles.has_key(app) or self.roles[app] != role):
                return False
        return True

    def __setattr__(self, name, value):
        return self.__setitem__(name, value)

    def __setitem__(self, name, value):
        if name in ['firstname', 'surname', 'email', 'group', 'active']:
            self._driver.setUserProperty(self.username, name, value) # Set in the database
            self.__dict__[name] = value # Set in the class
        elif name == 'password':
            if self.encryption == 'md5':
                value = md5.new(value).hexdigest()
            self._driver.setUserProperty(self.username, name, value) # Set in the database
            self.__dict__[name] = value # Set in the class
        else:
            if name in self.__dict__.keys():
                raise AttributeError('You cannot set the value of the %s attribute'%name)
            else:
                raise AttributeError('No such attribute %s'%name)

class AuthManager(AuthAdmin, AuthSession):
    
    def __init__(self, store, driver, expire=0, idle=0, autoCreate=0, encryption=None, **driverParams):
        self.__dict__['encryption'] = encryption
        if self.encryption not in [None, 'md5']:
            raise AuthError('Invalid encryption format %s'%self.encryption)
        self.autoCreate = autoCreate
        self.store = store
        self.expire = expire
        self.idle = idle
        if driver == 'database':
            import drivers.database
            self._driver = drivers.database.DatabaseAuthDriver(**driverParams)
        else:
            raise AuthError('No such driver %s'%driver)
        self.autoCreated = 0
        if self.autoCreate:
            if not self.completeAuthEnvironment():
                self.removeAuthEnvironment(ignoreErrors=True)
                self.createAuthEnvironment()
                self.addApp('app')
                self.addUser(
                    'john',
                    'bananas',
                    'John',
                    'Smith',
                    'johnsmith@example.com',
                )
                self.setLevel('john', 'app', 1)
                self.autoCreated = 1
        self.signedInUser = self.user()
        
    #
    # Manager Functions
    #

    def user(self, username=None):
        if username == None:
            userInfo = self.userInfo()
        else:
            username = username.lower()
            userInfo = {
                'username':username,
                'started' :None,
                'accessed':None,
                'expire'  :None,
                'idle'    :None,
            }
        if userInfo == None:
            return None
        return AuthUser(self._driver, userInfo, self.encryption)

manager=AuthManager
session=AuthSession
admin=AuthAdmin