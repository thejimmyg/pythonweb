"Implementation of PEP 333 Web Server Gateway Interface for PythonWeb.org"

import web

from urllib import quote
from wsgiref.handlers import CGIHandler

__all__ = ['runCGI', 'currentURL', 'base', 'cgi', 'database', 'environment', 'error', 'session', 'auth']


def runCGI(application):
    "Wrapper function to enable WSGI applications to run in a CGI environment"
    return CGIHandler().run(application)

def currentURL(environ):
    baseurl = environ['wsgi.url_scheme']+'://'
    if environ.get('HTTP_HOST'):
        baseurl += environ['HTTP_HOST']
    else:
        baseurl += environ['SERVER_NAME']
        if environ['wsgi.url_scheme'] == 'https':
            if environ['SERVER_PORT'] != '443':
               baseurl += ':' + environ['SERVER_PORT']
        else:
            if environ['SERVER_PORT'] != '80':
               baseurl += ':' + environ['SERVER_PORT']
    url = baseurl
    url += quote(environ.get('SCRIPT_NAME',''))
    url += quote(environ.get('PATH_INFO',''))
    if environ.get('QUERY_STRING'):
        url += '?' + environ['QUERY_STRING']
    return url
