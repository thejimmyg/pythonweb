"Page objects to make the use of templates easier. Not written yet."

class Page:
    def __init__(self, **params):
        for key in params.keys():
            if key[0] == '_':
                raise Exception("Page region names cannot begin with an underscore '_' character")
        self.__dict__['_dict'] = params
        
    def __getitem__(self, name):
        return self.__dict__['_dict'][name]
    
    def __setitem__(self, name, value):
        self.__dict__['_dict'][name] = value
        
    def __getattr__(self, name):
        return self.__dict__['_dict'][name]
    
    def __setattr__(self, name, value):
        self.__dict__['_dict'][name] = value