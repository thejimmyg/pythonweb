

     ======================================================================
                             PYTHON WEB MODULES   
     ======================================================================

                          http://www.pythonweb.org
                    Copyright (C) 2002-2005 James Gardner
                         email: mail@pythonweb.org


 Installation
 ============

 To install the modules:

    > python setup.py install

 Other ways to use the modules are discussed in the Getting Started Guide
 section of the documentation.


 Documentation
 =============

 Full documentation including a getting started guide and module reference
 can be found in the doc directory. 

 The documentation is also available in alternative formats from the website.


 Examples
 ========

 A number of examples can be found in the doc/src/lib directory. If you are
 working under UNIX you will need to set the permissions of these files so
 that they can be executed by the sample webserver.
 
 > chmod -R 755 doc/src/lib
 
 
 Licence
 =======

 Most of the web modules are licenced under the LGPL, however software in the 
 external directory may be licenced under other open source licences.


 Directory Structure
 ===================

  + doc           Full documentation for the modules
  + scripts       Useful scripts
  + web           The modules themselves
    + external      Software written by 3rd parties
    