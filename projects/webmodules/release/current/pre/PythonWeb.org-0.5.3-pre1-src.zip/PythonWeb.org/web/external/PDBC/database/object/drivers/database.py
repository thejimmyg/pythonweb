
cursor = None

def function(table, column, func):
    if func.upper() == 'MAX':
        return cursor.max(table, column)
    elif func.upper() == 'MIN':
        return cursor.min(table, column)
    else:
        raise Exception("Function '%s' not defined.")
        
def create(table, fields):
    #print fields
    f = []
    for field in fields:
        f.append(
            cursor.column(
                name=field[0], type=field[1], required=field[2], default=field[3], unique=field[4]
            )
        )
    return cursor.create(table=table, columns=f)

def drop(table):
    return cursor.drop(table=table)

def newID(table):
    m = cursor.max(table, 'rowid')
    if not m:
        return 1
    return int(m) + 1
    #print max #XXX MAJOR BUG. Comes back as Long.

def colUnique(table, name, value, ignoreRowids=[]): # is type needed.
    if ignoreRowids:
        if len(ignoreRowids) == 1:
            where = ' and rowid <> %s'%ignoreRowids[0]
        else:
            r= []
            for id in ignoreRowids:
                r.append(str(id))
            where = ' and rowid <> %s'%(r[0]) + ' and rowid <> '.join(r[1:])
    else: 
        where=''
    if type in ['INTEGER', 'FLOAT']: 
        rows = cursor.select(name,table,where=name + "=" + str(value)+where, fetch=True, format='tuple', convert=True)
    else:
        rows = cursor.select(name,table,where = name + "='" + str(value) + "'"+where, fetch=True, format='tuple', convert=True)
    if len(rows) > 0:
        return False
    return True
    
def getKeys(table, where=None, order=None, column='rowid'):
    "Returns a list of keys 'rowid's which rows matching the criteria."
    rows = cursor.select(column, table, where=where, order=order, fetch=True, format='tuple', convert=True)
    rowids = []
    for row in rows:
        rowids.append(row[0])
    return rowids
    
#
# SQL Funcitons
#

def exists(table):
    return cursor.tableExists(table)
    
def rowExists(table, rowid):
    rows = cursor.select('rowid', table, where="rowid="+str(rowid), fetch=True, format='tuple', convert=True)
    if rows:
        return True
    return False
   
def getRow(table, fields, rowid):
    return cursor.select(fields, table, where="rowid="+str(rowid), fetch=True, format='tuple', convert=True)
    
def fieldsExist(table, fields, rowid):
    rows = getRow(table, fields, rowid)
    if not (rows and len(rows[0]) == len(fields)):
        return False
    return True
                
def addRow(table, fields, values): # XXX AutoIncrement.
    rowid = newID(table)
    fields.insert(0, 'rowid')
    values.insert(0, rowid)
    return cursor.insert(table, fields, values)
    
def updateRow(table, rowid, fields, values):
    if type(values) not in [type([]), type((1))]:
        values = [values]
    return cursor.update(table, fields, values, where='rowid='+str(rowid))
    
def removeRow(table, rowid):
    return cursor.delete(table, where="rowid="+str(rowid))

def removeRows(table, query):
    return cursor.delete(table, where=str(query))
    
def relatedRowids(joinTable, column, foreignColumn, rowid):
    rows = cursor.select(column, joinTable, where=foreignColumn+'='+str(rowid), fetch=True, format='tuple', convert=True)
    rowids = []
    for row in rows:
        rowids.append(int(row[0]))
    return rowids
    
def isRelated(joinTable, curTable, foreignTable, curKey, foreignKey):
    rows = cursor.select(curTable, joinTable, where="%s=%s and %s=%s"%(curTable, curKey, foreignTable, foreignKey), fetch=True, format='tuple', convert=True)
    if rows:
        return True
    return False
    
def relate(table, curTable, foreignTable, curKey, foreignKey):
    return cursor.insert(table, (curTable, foreignTable), (curKey, foreignKey))

def unrelate(table, curTable, foreignTable, curKey, foreignKey):
    return cursor.delete(table, where="%s=%s and %s=%s"%(curTable, curKey, foreignTable, foreignKey))
