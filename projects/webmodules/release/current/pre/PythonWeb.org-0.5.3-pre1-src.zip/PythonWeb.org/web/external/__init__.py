"Utility functions."
#~ import sys

#~ class LemonError(Exception):
    #~ """Raised when a general Error in a lemon module occurs
    #~ Attributes:
        #~ message -- explanation of what the specific error is.

    #~ Useage:
        #~ raise LemonError('There was an error')

        #~ try:
            #~ ...
        #~ except LemonError, e:
            #~ print e.message
            
    #~ """
    #~ def __init__(self, message):
        #~ self.message = message

    #~ def __str__(self):
        #~ return self.message

#~ class ReadOnlyDictWrapper:
    #~ "Dict for cgi variables."
    #~ def __init__(self, dict):
        #~ self.__dict = dict
    #~ def __getattr__(self, name):
        #~ if self.__dict.has_key(name):
            #~ return self.__dict[name]
        #~ elif name in dir(self.__dict):
            #~ return getattr(self.__dict, name)
        #~ else:
            #~ return None
    #~ def __getitem__(self, name):
        #~ if self.__dict.has_key(name):
            #~ return self.__dict[name]
        #~ else:
            #~ return None
    #~ def __setitem__(self, name, value):
        #~ raise Exception('You cannot assign values to a CGI object.')
    #~ def __setitem__(self, name, value):
        #~ raise Exception('You cannot assign values to a CGI object.')
    #~ def __str__(self):
        #~ stri = ''
        #~ for k, v in self.__dict.items():
            #~ stri+=(' %s=%s,'%(k,repr(v)))
        #~ return stri[:-1]
    #~ def __repr__(self):
        #~ return '<%s %s>'%(self.__class__.__name__, self.__str__())

#~ # CGI Wrapper code
#~ import cgi as cgi_proper

#~ class CGIWrap(ReadOnlyDictWrapper):
    #~ pass
#~ import os
#~ cgi2 = cgi_proper.parse(keep_blank_values=1, strict_parsing=0)#FormContentDict()#cgi_proper.parse(environ=os.environ, keep_blank_values=True, strict_parsing=False)

#~ cgi = {}
#~ for k,v in cgi2.items():
    #~ if ((type(v) == type([])) or (type(v) == type([]))) and (len(v) == 1):
        #~ cgi[k] = v[0]
    #~ else:
        #~ cgi[k] = v
        
#~ del cgi2
#~ #raise Exception(cgi)
#~ dict = {}
#~ for k,v in cgi.items():
    #~ if len(v)>1:
        #~ dict[k] = v
    #~ else:
        #~ dict[k] = v[0]
#~ get = CGIWrap(dict)
#~ del dict

#~ # Config code
#~ class Config(ReadOnlyDictWrapper):
    #~ pass
#~ class ConfigSection(ReadOnlyDictWrapper):
    #~ pass    
#~ def config(file):
    #~ "Simple wrapper to allow attribute access to ConfigParser config files."
    #~ if type(file) <> type([]):
        #~ files = [findFile(file)]
    #~ else:
        #~ files = []
        #~ for f in file:
            #~ files.append(findFile(f))
    #~ import ConfigParser
    #~ conf = ConfigParser.ConfigParser()
    #~ conf.read(files)
    #~ #return conf.sections()
    #~ dict = {}
    #~ for section in conf.sections():
        #~ #print section
        #~ s = {}#dict[section] = conf.items(section)
        #~ for i in conf.items(section):
            #~ s[i[0]] = i[1]
        #~ dict[section] = ConfigSection(s)
    #~ return Config(dict)

#~ def findFile(filename):
    #~ """Utility function which searched the directories listed in sys.path for the file specified in filename.
    #~ If the file exists the complete path is returned. 
    
    #~ Note that the directories are searched in the order they appear in sys.path so if you want to choose a specific file it is better not to use this function 
    #~ because a similar file in a directory earlier in sys.path will be returned first."""
    #~ for p in sys.path:
        #~ if os.path.exists(os.path.join(p,filename)):
            #~ return os.path.join(p,filename)
    #~ return filename
    
#~ def cgiAsDict(form):
    #~ """Takes a cgi.FieldStorage() item and retuns a simple dictionary for use in other lemon functions."""
    #~ dict = {}
    #~ for k in form.keys():
        #~ dict[k] = form.getvalue(k,'')
    #~ return dict
    
#~ def addToDict(dict1, dict2, overWrite=True):
    #~ """Adds the information in the dictionary 'dict2' to the entries in the dictionary 'dict1'.
    #~ If 'overWrite' is True the values in 'dict2' overwrite the values in 'dict1', otherwise only the keys not 
    #~ already in 'dict1' are added."""
    
    #~ dict={}
    #~ if overWrite == True:
        #~ for k,v in dict1.items():
            #~ dict[k] = v
            
    #~ if type(dict2) == type([]) or type(dict2) == type(()):
        #~ for k,v in dict2:
            #~ dict[k] = v
    #~ else:
        #~ for k,v in dict2.items():
            #~ dict[k] = v
    
    #~ if overWrite == False:
        #~ for k,v in dict1.items():
            #~ dict[k] = v
            
    #~ return dict
    
#~ def removeFromDict(dict1, keys):
    #~ """Removes all keys in 'dict1' specified in the list or dictionary 'keys'."""
    #~ dict = {}
    #~ for k,v in dict1.items():
        #~ if k not in keys:
            #~ dict[k] = v
    #~ return dict
    
#~ def keepInDict(dict1, keys):
    #~ """Removes all keys in 'dict1' NOT specified in the list or dictionary 'keys'."""
    #~ dict = {}
    #~ for k,v in dict1.items():
        #~ if k in keys:
            #~ dict[k] = v

    #~ return dict
    
#~ def dictAsURLPairs(stickyData):
    #~ """Changes a dictionary such as lemon.get into a query string."""
    #~ import urllib
    #~ url = ''
    #~ for k, v in stickyData.items():
        
        #~ if type(v) <> type([]):
            #~ url += urllib.quote_plus(str(k))+'='+urllib.quote_plus(str(v))+'&'
        #~ else:
            #~ for item in v:
                #~ url += urllib.quote_plus(k)+'='+urllib.quote_plus(str(item))+'&'
    #~ return url

#~ def hidden(stickyData):
    #~ """Changes a dictionary such as lemon.get into a string containing hidden fields HTML."""
    #~ fields = ''
    #~ for k,v in stickyData.items():
        #~ if type(v) <> type([]):
            #~ fields += '<input type="hidden" name="%s" value="%s">\n' % (str(k),str(v)) # No _plus
        #~ else:
            #~ for item in v:   
                #~ fields += '<input type="hidden" name="%s" value="%s">\n' % (str(k),str(item)) # No _plus
    #~ return fields
        
#~ def addZeros(num,s):
    #~ "Function to add an appropriate number of zeros to s such that len(s) is num."
    #~ s = str(s)
    #~ while( len(s) < num ):
        #~ s = '0'+s
    #~ return s
    
#~ def allNone(value):
    #~ allNone = True
    #~ for n in value:
        #~ if type(n) <> type(None):
            #~ allNone = False
            #~ break
    #~ return allNone
                    
#~ def escape(value):
    #~ val = str(value)
    #~ return val.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('\n','<br>')

#~ def unescape(value):
    #~ return value.replace('&amp;','&').replace('&lt;','<').replace('&gt;','>')


# Make available the newDixt() object
#~ if pythonVersion >= '2.3.0':
    #~ class newDict(dict):
        #~ def __getattr__(self, name):
            #~ if name in self.keys():
                #~ return self.__getitem__(name)
            
        #~ def __setattr__(self, name, value):
            #~ if not name in dir(self):
                #~ self.__setitem__(name, value)
            #~ else:
                #~ raise Exception("You cannot set a the name of a dictionary key which is already used by the class, listed by the dir() function. '%s' is one such value."%name)
                