import md5, web.form

class SignInHandler:

    def __init__(self, manager, cgi=None, redirect=None, modeName='mode', action='', stickyData={}, message='', encryption=None):
        self.auth = manager
        self.encryption = encryption
        if self.encryption not in [None, 'md5']:
            raise Exception('Invalid encryption format %s'%self.encryption)
        self.modeName = modeName
        self.action = action
        self.status = None
        self.stickyData = stickyData
        self.messages = {
            # Errors
            'ALREADY_SIGNED_IN'     : 'You are already signed in. If you want to sign in again you should <a href="%s">sign out</a> first.'%('?%s=signOut'%(self.modeName)),
            'NOT_SIGNED_IN'         : 'You are not signed in', # No status message needs displaying
            'NOT_SIGNED_IN_YET'     : '', # No status message needs displaying
            'NO_USER_ENTERED'       : 'Please enter a username.',
            'NO_USER'               : 'The username you have specified does not exist.',
            'NO_PASSWORD_ENTERED'   : 'No password entered.',
            'INVALID_PASSWORD'      : 'The password is incorrect.',
            # Statements:
            'SIGNED_OUT'            : 'You have been sucessfully signed out.',
            'SIGNED_IN'             : '', # No status message is returned anyway
        }
        if cgi == None:
            self.cgi = web.cgi
        else:
            self.cgi = cgi
        self.redirect = redirect
        self.message = message
        # Setup the form
        self.stickyData[self.modeName] = 'signIn'
        self.stickyData['redirect'] = redirect
        self.form = web.form.Form(method='get', stickyData=self.stickyData, action=self.action)
        self.form.add(field='String', name='username', size=18, required=1, requiredError=self.messages['NO_USER_ENTERED'])
        self.form.add(field='Password', name='password', size=18, required=1, requiredError=self.messages['NO_PASSWORD_ENTERED'])
        self.form.addAction('Sign In')
        
    def handle(self):
        if self.cgi.has_key(self.modeName) and self.cgi[self.modeName].value == 'signOut':
            if self.auth.signedInUser != None:
                self.auth.signOut()
                self.status = 'SIGNED_OUT'
                return {'form':'','message':self.messages[self.status]}
            else:
                self.status = 'NOT_SIGNED_IN'
                return {'form':'','message':self.messages[self.status]}
        else:
            if self.auth.signedInUser != None:
                username = self.auth.signedInUser.username
                self.status = 'ALREADY_SIGNED_IN'
                return {'form':self.form.html(),'message':self.message}
            elif not self.cgi.has_key(self.modeName) or self.cgi[self.modeName].value not in ['signIn','signOut']:
                self.status = 'NOT_SIGNED_IN_YET'
                return {'form':self.form.html(),'message':self.message}
            else:
                self.form.populate(self.cgi)
                password = self.form['password'].value
                if self.encryption == 'md5':
                    password = md5.new(password).hexdigest()
                validates = 1
                if not self.form.valid():
                    return {'form':self.form.html(),'message':self.message}
                elif not self.auth.userExists(self.form['username'].value):
                    self.status = 'NO_USER'
                    self.form['username'].setError(self.messages[self.status])
                    return {'form':self.form.html(),'message':self.message}
                elif self.auth.user(self.form['username'].value).password <> password:
                    self.status = 'INVALID_PASSWORD'
                    self.form['password'].setError(self.messages[self.status])
                    return {'form':self.form.html(),'message':self.message}
                else:
                    self.auth.signIn(self.cgi['username'].value)
                    if self.redirect: # Redirect to correct place!
                        status = 'SIGNED_IN'
                        self.setHeader("Location",self.redirect)
                        return None
                    else:
                        status = 'SIGNED_IN'
                        return None
        
    def setHeader(self, header, value):
        print "%s: %s\n\n"%(header,value)
