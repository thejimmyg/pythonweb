"Error Handling"

import web, web.error, sys, web.mail

class Error:
    def __init__(self, application):
        self.application = application

    def __init__(self, application, showExceptions=True, 
        emailTo=[], 
        replyName='', 
        replyEmail='', 
        subject='Error Report',
        sendmail = '/usr/bin/sendmail',
        smtp = '',
        method = 'sendmail',
        type = 'html',
    ):
        self.application = application
        self.showExceptions = showExceptions
        # Mail options
        self.replyName = replyName
        self.replyEmail = replyEmail
        self.subject = subject
        self.sendmail = sendmail
        self.smtp = smtp
        self.method = method
        self.emailTo = emailTo
        self.type = type

    def send(self, message):
        if len(self.emailTo) > 0:
            web.mail.send(
                to = self.emailTo,
                msg = message,
                type = self.type,
                replyName = self.replyName,
                replyEmail = self.replyEmail,
                subject = self.subject,
                sendmail = self.sendmail,
                smtp = self.smtp,
                method = self.method,
            )
        
    def __call__(self, environ, start_response):
        try:
            result = self.application(environ, start_response)
        except:
            status, h, error = self.error()
            if not status or not h or not error:
                status = '500 Error'
                h = [('Content-type','text/plain')]
                start_response(status, h, sys.exc_info())
                msg = 'An error occured and the error handling middleware failed to handle it correctly.'
                self.send(msg)
                return [msg]
            else:
                start_response(status, h)
                if type(error) == type(''):
                    self.send(error)
                    return [error]
                else:
                    self.send(''.join(error))
                    return error
        else:
            return result

    def error(self):
        "Generate an error report"
        return '200 Error Handled', [('Content-type','text/html')], web.error.info(output='debug', format='html')

