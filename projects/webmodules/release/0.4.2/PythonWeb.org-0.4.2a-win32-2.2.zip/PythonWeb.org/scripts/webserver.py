#!/usr/bin/env python

"""
Simple Python Webserver NOT SUITABLE FOR PRODUCTION USE.
        
Visit http://localhost:8080/doc/html/ to see the webserver running.

WARNING: This server will not function correctly if the path to the webserver
contains spaces. You should unzip the distribution to a directory with a path 
such as C:\PythonWeb to get around this problem."""
    
import sys; sys.path.append('../')
import web.util

if __name__ == '__main__':
    if len(sys.argv) > 1:
        dir = sys.argv[1]
    print __doc__
    web.util.runWebServer(root='../', cgi='/doc/src/lib')
else:
    print "Webserver\n\nUseage: python webserver.py"