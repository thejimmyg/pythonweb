"""File driver for the auth module."""

import authBase, os, os.path, cPickle, StringIO
from web.errors import AuthError

class AuthAdminFile:
    def __init__(self, dir=None):
        if not dir:
            raise AuthError('You must specify a directory to store the auth files in.')
        if not os.path.exists(dir):
            raise AuthError("The directory '%s' doesn't exist."%dir)
        self.dir = dir
        
    def applicationExists(self, app):
        """Test to see if the application named 'app' exists. N.B. This function doesn't test whether the data is valid or whether the level info is availabel, just whether the file exists.""" 
        if not os.path.exists(os.path.join(self.dir,'AuthApp_'+app)):
            return False
        return True
        
    def addApplication(self, app):
        """Add an application named 'app' unless it already exists in which case raise an AuthError."""
        if self.applicationExists(app):
            raise AuthError("The '%s' application already exists."%app)
        else:
            object = {
                'name':app, 
            }
        
            file = open(os.path.join(self.dir,'AuthApp_'+app),'w')
            cPickle.dump(object, file)
            file.close()
            
    def removeApplicaiton(self, app):
        """Remove an application named 'app' unless it doesn't exist in which case raise an AuthError."""
        if not self.applicationExists(app):
            raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            os.remove(os.path.join(self.dir,'AuthApp_'+app))
            # Remove all Level values associated with App.
            for file in os.listdir(self.dir):
                if file[:10] == 'AuthLevel_':
                    f = open(os.path.join(self.dir, file), 'r')
                    object = cPickle.load(f)['expire'] # XXX What is this!
                    f.close()
                    if object.has_key(app):
                        del object[app]
                        file = f = open(os.path.join(self.dir, file),'w')
                        cPickle.dump(object, file)
                        file.close()

    def userExists(self, username):
        """Test to see if the user with the username 'username' exists.""" 
        if not os.path.exists(os.path.join(self.dir,'AuthUser_'+username)):
            return False
        #if sys.platform == 'win32':   # I think we can leave this in becuase UNIX is case sensitive
        #    pass
        file = open(os.path.join(self.dir,'AuthUser_'+username),'r')
        object = cPickle.load(file)
        file.close()
        if not object['username'] == username:
            return False
        return True
        
    def addUser(self, username, password, firstname='', surname='', email=''):
        """Add a user with the username 'username' and the password 'password' unless the username already exists in which case raise an AuthError
        Can optionally specify a firstname, surname and email for the user."""
        if self.userExists(username):
            raise AuthError("The username '%s' already exists."%username)
        else:
            object = {
                'username':username, 
                'password':password,
                'firstname':firstname,
                'surname':surname,
                'email':email,
            }
        
            file = open(os.path.join(self.dir,'AuthUser_'+username),'w')
            cPickle.dump(object, file)
            file.close()
            file = open(os.path.join(self.dir,'AuthLevel_'+username),'w')
            cPickle.dump({}, file)
            file.close()

    def removeUser(self, username):
        """Remove a user with the username 'username' unless the username doesn't exist in which case raise an AuthError."""
        if self.userExists(username):
            os.remove(os.path.join(self.dir,'AuthUser_'+username))
            os.remove(os.path.join(self.dir,'AuthLevel_'+username))
            return 1
        else:
            raise AuthError("The username '%s' doesn't exist."%(username))
            
    def setAccessLevel(self, username, app, level):
        """Set the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        if self.userExists(username):
            if self.applicationExists(app):
                # Read the user level
                file = open(os.path.join(self.dir,'AuthLevel_'+username),'r')
                object = cPickle.load(file)
                file.close()
                object[app] = int(level)
                # Write the user level
                file = open(os.path.join(self.dir,'AuthLevel_'+username),'w')
                cPickle.dump(object, file)
                file.close()
                return True
            else:
                raise AuthError("The '%s' application doesn't exist."%app)
        else:
            raise AuthError("The user '%s' doesn't exist."%username)
        
    def getAccessLevel(self, username, app):
        """Return the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        levels = self.getAccessLevels(username)
        if levels.has_key(app):
            return levels[app]
        else:
            return None

    def getAccessLevels(self, username):
        """Return a dictioanry containing the access level of the user with username 'username' for every application the user has been granted access to. Raise an AuthError if there is no user called 'username'."""
        if self.userExists(username):
            file = open(os.path.join(self.dir,'AuthLevel_'+username),'r')
            object = cPickle.load(file)
            file.close()
            return object
        else:
            raise AuthError('That username doesn\'t exist.')
            
    def _setProperty(self, property, username, value):
        """Private method to set the value of one of 'password', 'firstname', 'surname' and 'email' for a particular user."""
        if property in ['password','firstname','surname','email']:
            if self.userExists(username):
                # Read the user level
                file = open(os.path.join(self.dir,'AuthUser_'+username),'r')
                object = cPickle.load(file)
                file.close()
                if name in ['firstname', 'surname', 'email', 'password']:
                    object[property] = firstname
                else:
                    raise AuthError("The user has no property named '%s'."%property)
                # Write the user level
                file = open(os.path.join(self.dir,'AuthUser_'+username),'w')
                cPickle.dump(object, file)
                file.close()
            else:
                raise AuthError('That user doesn\'t exist.')
        else:
            raise AuthError("You can only set the properties 'password', 'firstname', 'surname' and 'email'")

    def setFirstname(self, username, value):
        """Sets the firstname of the user 'username' to 'value'."""
        return self._setProperty('firstname', username, value)
        
    def setSurname(self, username, value):
        """Sets the surname of the user 'username' to 'value'."""
        return self._setProperty('surname', username, value)

    def setEmail(self, username, value):
        """Sets the email address of the user 'username' to 'value'."""
        return self._setProperty('email', username, value)
            
    def setPassword(self, username, value):
        """Sets the password of the user 'username' to 'value'."""
        return self._setProperty('password', username, value)
            
    def users(self):
        """Return a list of current usernames."""
        usernames = []
        for file in os.listdir(self.dir):
            if file[:9] == 'AuthUser_':
                usernames.append(file[9:])
        return usernames
        
    def apps(self):
        """Return a list of current applications."""
        apps = []
        for file in os.listdir(self.dir):
            if file[:8] == 'AuthApp_':
                apps.append(file[8:])
        return apps
        
    def getUser(self, username, app=None, property=None):
        """Returns a data structure containing useful infomation about the user.
        eg. 
            user = getUser('testuser', 'testapp')
            
            # The variables below all return values the value as expected
            user.username, user.email, user.password, user.firstname, user.surname
            
            user.app # contains a structure of apps which testuser has access to
            user.app.testapp.level # returns testuser's access level to 'testapp'.
            
            user.apps() # returns a list of app names. (Similar to the auth.apps() function)"""
        if self.userExists(username):
            # Read the user level
        
            if app == None:
                app = self.app
            
            from objects import App, Apps, User


            file = open(os.path.join(self.dir,'AuthUser_'+username),'r')
            object = cPickle.load(file)
            file.close()
            
            level = self.getAccessLevel(username, app)
            user = User(
                {
                    'username':object['username'],
                    'password':object['password'],
                    'firstname':object['firstname'],
                    'surname':object['surname'],
                    'email':object['email'],
                    #'app':appStructure,
                    'level':self.getAccessLevels(username),
                    'accessLevel': level,
                }
            )
            if not property:
                return user
            elif user.has_key(property):
                return user[property]
            else:
                raise AuthError("No such property '%s'."%property)
        else:
            raise AuthError("No such username '%s'."%username)

    def getFirstname(self, username):
        """Returns the firstname of the user 'username'."""
        return self.getUser(username, property='firstname')
        
    def getSurname(self, username):
        """Returns the surname of the user 'username'."""
        return self.getUser(username, property='surname')
        
    def getEmail(self, username):
        """Returns the email address of the user 'username'."""
        return self.getUser(username, property='email')

    def getPassword(self, username):
        """Returns the password of the user 'username'."""
        return self.getUser(username, property='password')
        
class AuthFile(AuthAdminFile, authBase.AuthBase):
    
#
# Auth Driver code (Over-ridden in other classses)
#

    def __init__(
        self, 
        session, 
        expire=0, 
        idle=0, 
        signInForm=None, 
        autoSignIn=True, 
        autoRedirect=False,
        redirect=None, 
        includeQuery=False, 
        stickyData={}, 
        reminderForm=None, 
        emailOptions=None, 
        app=None, 
        errorCodes=None, 
        htmlPage=None,
        encryption=None,
        dir=None,
        debug=False,
        checkSignInAttempt=False,
        htmlPageRegions={'content':'content','title':'title'},
    ):
        if not dir:
            raise AuthError('You must specify a directory to store the auth files in.')
        if not os.path.exists(dir):
            raise AuthError("The directory '%s' doesn't exist."%dir)
        self.dir = dir
        return authBase.AuthBase.__init__(
            self,
            session, 
            expire, 
            idle, 
            signInForm, 
            autoSignIn, 
            autoRedirect,
            redirect, 
            includeQuery, 
            stickyData, 
            reminderForm, 
            emailOptions, 
            app, 
            errorCodes, 
            htmlPage,
            encryption,
            debug,
            checkSignInAttempt,
            htmlPageRegions,
        )