"""Implementation of a database storage driver for the session module."""

import pickle, StringIO, time
import sessionBase
from web.errors import SessionError

class SessionDatabaseSetup:
    
#
# Session Manager Functions
#
        
    def __init__(self, cursor, table='Session'):
        self.params = {}
        self.params['cursor'] = cursor
        self.params['table'] = table
        
    def createTables(self, autoCommit=None): # autoCommit needed for the Gadfly types information to be added.
        """Create a session table cable of holding session information from the default values in the Lemon.ini file."""
        errors = []
        if not self.params['cursor'].tableExists(self.params['table']+'Store'):
            self.params['cursor'].create(
                    self.params['table']+'Store',
                    (    
                        ('SessionID',   'String'),
                        ('App',         'String'),
                        ('ItemKey',     'String'),
                        ('ItemValue',   'Text'),
                    )
                )
            if autoCommit:
                autoCommit.commit()
        else:
            errors.append("The '"+self.params['table']+'Store'+"' table already exists.")

            
        if not self.params['cursor'].tableExists(self.params['table']+'s'):
            self.params['cursor'].create(
                    self.params['table']+'s',
                    (    
                        ('SessionID',   'String'),
                        ('Expire',     'Integer'),
                    )
                )
            if autoCommit:
                autoCommit.commit()
        else:
            errors.append("The '"+self.params['table']+'s'+"' table already exists.")
        return errors
        
    def dropTables(self, autoCommit=None):
        errors = []
        if self.params['cursor'].tableExists(self.params['table']+'Store'):
            self.params['cursor'].drop(self.params['table']+'Store')
            if autoCommit:
                autoCommit.commit()
        else:
            errors.append("The "+self.params['table']+'Store'+" table doesn't exist.")
        if self.params['cursor'].tableExists(self.params['table']+'s'):
            self.params['cursor'].drop(self.params['table']+'s')
            if autoCommit:
                autoCommit.commit()
        else:
            errors.append("The "+self.params['table']+'s'+" table doesn't exist.")
        return errors

    def tablesExist(self):
        if self.params['cursor'].tableExists(self.params['table']+'Store') and self.params['cursor'].tableExists(self.params['table']+'s'):
            return True
        return False

class SessionDatabase(sessionBase.SessionBase):
    """The main session class for database storage of sessions.
    See the information in lemon.session.start() for details of how to use it. The class should not be called 
    directly becuase error-checking occurs in lemon.session.start()."""
        
    def __init__(self, app, expire, sessionID, cookie, seed, cleanup, cursor, table):
        """Initialise the class with the parameters as specified in the lemon.session.start() function."""
        
        sessionBase.SessionBase.__init__(self, app, expire, sessionID, cookie, seed, cleanup)
        
        # Set up options allowed in the constructor
        self.__dict__['params']['cursor'] = cursor
        self.__dict__['params']['table'] = table
        
        self.begin()
        
    def _addSession(self, sessionID, length):
        "Create a new session setting the 'Created' and 'Accessed' variables."
        self.params['cursor'].insert(   
                                        self.params['table']+'s', 
                                        ('SessionID', 'Expire'),
                                        (self.params['sessionID'],int(time.time())+int(length)),
                                    )
        #self.params['database'].commit()
                                    
    def _removeSession(self, sessionID):
        "Remove session information from the session store."
        self.params['cursor'].delete(self.params['table']+'s', where="SessionID='"+sessionID+"'")
        self.params['cursor'].delete(self.params['table']+'Store', where="SessionID='"+sessionID+"'")
        #self.params['database'].commit()
        
    def _cleanupSessions(self):
        "Remove all expired sessions."
        rows = self.params['cursor'].select('SessionID',self.params['table']+'s', where="Expire < "+str(int(time.time())), fetchMode='tuple')  
        for row in rows:
            self.params['cursor'].delete(self.params['table']+'s', where="SessionID='"+row[0]+"'")      
            self.params['cursor'].delete(self.params['table']+'Store', where="SessionID='"+row[0]+"'")      
        #self.params['database'].commit()
        
    def _sessionExists(self, sessionID):
        "Returns True if the session already exists, False otherwise."
        rows = self.params['cursor'].select('SessionID',self.params['table']+'s', where="SessionID='"+sessionID+"' and Expire >"+str(int(time.time())), fetchMode='tuple')
        if rows:
            return True
        return False
        
    def _set(self, key, value, app=None, pickleValue=True):
        "Sets the variable 'key' to the value 'value' after pickling it. # XXX The app functionality is not tested"
        if not app:
            app = self.params['app']
        if pickleValue:
            out = StringIO.StringIO()
            pickle.dump(value,out)
            value = out.getvalue()
    
        rows = self.params['cursor'].select('ItemValue',self.params['table']+'Store',where="SessionID='"+self.params['sessionID']+"' and ItemKey='"+key+"'", fetchMode='tuple')
        if len(rows) == 0:
            self.params['cursor'].insert(self.params['table']+'Store', ('SessionID','App','ItemKey','ItemValue'), (self.params['sessionID'], self.params['app'], key, value))
            #self.params['database'].commit()
        else:
            self.params['cursor'].update(self.params['table']+'Store', ('ItemValue',), (value,), where="SessionID='"+self.params['sessionID']+"' and ItemKey='"+key+"' and App='"+app+"'")  
            #self.params['database'].commit()
    
    def _get(self, key, app=None, pickleValue=True):
        "Gets the variable 'key' from the session store."
        if not app:
            app = self.params['app']
        rows=self.params['cursor'].select(('ItemValue'),self.params['table']+'Store',where="SessionID='"+self.params['sessionID']+"' and ItemKey='"+key+"' and App='"+app+"'", fetchMode='tuple')  
        if not rows:
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
        else:
            if type(rows[0]) == type({}):
                read = StringIO.StringIO(rows[0]['ItemValue'])
            else: # Assume it can be accessed as a tuple
                read = StringIO.StringIO(rows[0][0])
            if pickleValue:
                return pickle.load(read)
            else:
                return read
                
    def _delete(self, key, app=None):
        "Removes the variable from the session store."
        if not app:
            app = self.params['app']
        
        rows=self.params['cursor'].select(('ItemValue'),self.params['table']+'Store',where="SessionID='"+self.params['sessionID']+"' and ItemKey='"+key+"' and App='"+app+"'", fetchMode='tuple')  
        if not rows:
            raise SessionError("The session store doesn't have a key named '%s' for the app '%s'."%(key,app))
            
        self.params['cursor'].delete(self.params['table']+'Store',where="SessionID='"+self.params['sessionID']+"' and ItemKey='"+key+"' and App='"+app+"'")  
        #self.params['database'].commit()
        
        
    #~ def _updateAccessed(self):
        #~ "Update the 'Accessed' variable of the session."
        #~ self.params['cursor'].update(   
                                        #~ self.params['table'], 
                                        #~ 'ItemValue',
                                        #~ int(time.time()),
                                        #~ where="SessionID='"+self.params['sessionID']+"' and App='Sessions' and ItemKey='Accessed'",
                                    #~ )
        #~ self.params['database'].commit()
                                    
