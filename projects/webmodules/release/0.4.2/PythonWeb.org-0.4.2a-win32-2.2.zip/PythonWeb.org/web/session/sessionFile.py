"""Implementation of a file based storage driver for the session module."""

import cPickle, os, StringIO, time
import sessionBase

from web.errors import SessionError
        
class SessionFile(sessionBase.SessionBase):
    """The main session class for file storage of sessions.
    See the information in web.session.start() for details of how to use it. The class should not be called 
    directly becuase error-checking occurs in web.session.start()."""
        
    def __init__(self, app, expire, sessionID, cookie, seed, cleanup, dir, table):
        """Initialise the class with the parameters as specified in the web.session.start() function."""
        
        sessionBase.SessionBase.__init__(self, app, expire, sessionID, cookie, seed, cleanup)
        
        # Set up options allowed in the constructor
        self.__dict__['params']['dir'] = dir
        self.__dict__['params']['table'] = table
        
        self.begin()
        
    def _addSession(self, sessionID, length):
        "Create a new session setting the 'Created' and 'Accessed' variables."
        object = {
            'expire':int(time.time())+int(length), 
        }
        
        file = open(os.path.join(self.params['dir'],'Session_'+sessionID),'w')
        cPickle.dump(object, file)
        file.close()

    def _removeSession(self, sessionID):
        "Remove session information from the session store."
        os.remove(os.path.join(self.params['dir'],'Session_'+sessionID))
        
    def _cleanupSessions(self):
        "Remove all expired sessions."
        for file in os.listdir(self.params['dir']):
            if file[:8] == 'Session_':
                f = open(os.path.join(self.params['dir'], file), 'r')
                expire = cPickle.load(f)['expire']
                f.close()
                if expire < int(time.time()):
                    self._removeSession(file[8:])
        
    def _sessionExists(self, sessionID, length=0):
        "Returns True if the session already exists and has not expired, False otherwise."
        if not os.path.exists(os.path.join(self.params['dir'],'Session_'+sessionID)):
            return False
        
        #~ file = open(os.path.join(self.params['dir'],self.params['sessionID']))
        #~ object = cPickle.load(file)
        #~ file.close()
        
        #~ if object['expire'] > int(time.time())+int(self.params['expire']):
            #~ return False
        return True
        
        
    def _set(self, key, value, app=None):
        "Sets the variable 'key' to the value 'value' after pickling it. # XXX The app functionality is not tested"
        if not app:
            app = self.params['app']

        file = open(os.path.join(self.params['dir'],'Session_'+self.params['sessionID']),'r')
        object = cPickle.load(file)
        file.close()
        
        file = open(os.path.join(self.params['dir'],'Session_'+self.params['sessionID']),'w')
        if object.has_key(app):
            object[app][key] = value
        else:
            object[app] = {}
            object[app][key] = value
        cPickle.dump(object, file)
        file.close()
    
    def _get(self, key, app=None):
        "Gets the variable 'key' from the session store."
        if not app:
            app = self.params['app']
            
        file = open(os.path.join(self.params['dir'],'Session_'+self.params['sessionID']))
        object = cPickle.load(file)
        if object.has_key(app):
            if object[app].has_key(key):
                return object[app][key]
            else:
                raise SessionError("The session store doesn't have a key named '%s'."%(key))
                #return None
        else:
            raise SessionError("The session store has no application named '%s'."%(app))
            #return None
        file.close()

    def _delete(self, key, app=None):
        "Removes the variable from the session store."
        if not app:
            app = self.params['app']
        
        file = open(os.path.join(self.params['dir'],'Session_'+self.params['sessionID']),'r')
        object = cPickle.load(file)
        file.close()
        
        if object.has_key(app) and object[app].has_key(key):
            del object[app][key]

            file = open(os.path.join(self.params['dir'],'Session_'+self.params['sessionID']),'w')
            cPickle.dump(object, file)
            file.close()
        else:
            raise SessionError("The session store doesn't have a key named '%s'."%(key))
        

        
