"""Base class for session storage drivers."""

import time, random, Cookie, os, md5, base64, string, StringIO#, #lemon, lemon.session
from web.errors import SessionError

class SessionBase:
    """
    This is the base class to derive session storage driver from. This class defines the interface
    of the storage drivers. eg. SessionDB is the database session handler derived from this class.
    
    If a sessionID is not specified and the sessionID cannot be read from a cookie, a new session is created
    and the cookie is set.
    """
    
    
    def __init__(self, app, expire, sessionID, cookie, seed, cleanup):
        """Initialise the class with the parameters as specified in the lemon.session.start() function."""
        
        # Check cookie options are valid
        for key in cookie.keys():
            if key not in ['path','domain','comment','secure','max-age','version']:        
                raise SessionError("'%s' is not a valid key for a cookie dictionary."%key)
                
                
        self.__dict__['params']={} # Store all member variables in the params dictionary.
        
        # Set up options allowed in the constructor
        if app == 'Sessions':
            raise SessionError("The app 'Sessions' is reserved for use by the session module.")
        else:
            self.__dict__['params']['app'] = app
        self.__dict__['params']['expire'] = expire
        self.__dict__['params']['sessionID'] = sessionID
        self.__dict__['params']['cookie'] = cookie
        self.__dict__['params']['seed'] = seed
        self.__dict__['params']['cleanup'] = cleanup
        self.__dict__['params']['reserved'] = []
        if self.__dict__['params']['cookie']['max-age'] == None:
            self.__dict__['params']['cookie']['max-age'] = self.__dict__['params']['expire']
        #self.begin()
        
        # XXX Derived class should call begin() when done
        

    def begin(self):
        # Set up other options
        self.params['reserved'] = []#'SessionCreated']
        self.params['created'] = False
        
        # Set up the session ID from a cookie if necessary or start a new session as needed.
        if not self.params['sessionID']:
            self.params['sessionID'] = self._readCookie()
        if len(self.params['sessionID'])>255:
            raise SessionError('The Session ID is invalid. Session IDs should be 32 characters long.')
            
        # Remove unwanted sessions
        if random.random() < float(self.params['cleanup']):
            self._cleanupSessions()
            
        if not self.params['sessionID'] or not self._sessionExists(self.params['sessionID']): 
            self.params['sessionID'] = self._createSession(self.params['cookie']['max-age'])
        #~ if :
            #~ self.params['sessionID'] = self._createSession(0)
            #~ raise Exception(self.valid())
            
#raise Exception(self.valid())


 
    #
    # Get and set session variable functions
    #
    
    def set(self, key, value, block=True):
        "Public method to set a session variable. 'value' can be anything that can be pickled."
        if  not block or key not in self.__dict__['params']['reserved']:
            self._set(key, value)
        else:
            raise SessionError("The variable app '%s' is reserved for use by the session module."%(self.params['app']))
    
    def get(self, key, block=True):
        "Public method to retrieve a session variable."
        if not block or key not in self.__dict__['params']['reserved']:
            #try:
            return self._get(key)
            #except:
            #    return None
        else:
            raise SessionError("The variable app '%s' is reserved for use by the session module."%(self.params['app']))
    
    def delete(self, key, block=True):
        "Public method to remove a session variable."
        if  not block or key not in self.__dict__['params']['reserved']:
            #try:
            self._delete(key)
            #except:
            #    pass
        else:
            raise SessionError("The variable app '%s' is reserved for use by the session module."%(self.params['app']))

    def has_key(self, key, block=True):
        "Returns True if the key 'key' exists otherwise False."
        try:
            self.get(key, block)
        except SessionError:
            return False
        else:
            return True

    #
    # Get and set parameters
    # 

    def destroy(self, removeCookie=False):
        """End a session and if removeCookie=True remove the session cookie."""
        self._removeSession(self.sessionID)
        if removeCookie:
            self._removeCookie()
        
    #def created(self):
    #    """Find out if a session was automatically created and hence whether this was the first visit."""
    #    return self.created
        
    def valid(self):
        """Return whether or not the session is still valid"""
        return self._sessionExists(self.params['sessionID'])
        
   
    def reserve(self, key):
        """Prevent a user using the variable name 'key'."""
        if self.params['reserved'].count(key) == 0:
            self.params['reserved'].append(key)
            
    def release(self, key):
        """Allow a user to use the previously reserved variable name 'key'."""
        for x in range(self.params['reserved'].count(key)):
            self.params['reserved'].remove(key)

    #
    # Cookie functions
    #
    
    def _readCookie(self):
        """Private method to read the sessionID from the session cookie."""
        SessionID=""
        try:
            cookie = os.environ["HTTP_COOKIE"]
        except KeyError:
            pass
        else:
            c2 = Cookie.SimpleCookie()
            c2.load(os.environ["HTTP_COOKIE"])
            try:
                SessionID=c2[self.params['app']].value
            except:
                pass
            
        if SessionID: 
            return SessionID
        else:
            return ''

    def _removeCookie(self):
        """Private method to remove session cookie."""
        c1 = Cookie.SimpleCookie()
        c1[self.params['app']] = self.params['sessionID']
        c1[self.params['app']]["max-age"] = 1   # Time to keep, in seconds
        #c1[self.params['app']]["expires"] = 1   # Obsolete, but Netscape still seems to require it
        c1[self.params['app']]["version"] = 1
        # Print the headers that sets the cookies
        print c1
        
    def _setCookie(self, length):
        """Private method to set the session cookie with the options specified by the cookie param in 
        lemon.session.start()"""
        # Create a cookie dictionary object
        c1 = Cookie.SimpleCookie()
        c1[self.params['app']] = self.params['sessionID']
        for k, v in self.params['cookie'].items():
            if v:
                c1[self.params['app']][k] = v
        c1[self.params['app']]["version"] = 1
        # Print the headers that sets the cookies
        print c1
        
    #
    # Session management functions
    #
    
    def _createSession(self, length):
        """Private method to start a new session."""
        counter = 0
        while 1:
            counter += 1
            if counter > 100:
                raise SessionError('Could not create valid SessionID.')
            g = random.Random(time.time())
            self.params['sessionID'] = self._genSessionID(str(int(g.random()*10000000)))
            if not self._sessionExists(self.params['sessionID']):
                break
        self._setCookie(length)
        self._addSession(self.params['sessionID'], int(self.params['expire']))
        self.params['created'] = True
        #self._set('SessionCreated',str(int(time.time())),False)
        return self.params['sessionID']
        
    def _genSessionID(self, st):
        """Private method to generate a new sessionID. Uses the entropySeed specified in Lemon.ini."""
        m = md5.new()
        m.update('this is a test of the emergency broadcasting system')
        m.update(str(time.time()))
        m.update(str(st))
        session = string.replace(base64.encodestring(m.digest())[:-3], '/', '$')
        session = session.replace('+','p')
        session = session.replace('$','d')
        session = session.replace('\\','b')
        session = session.replace('/','f')
        return session
    
    def __getitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        return self.get(key)

    def __setitem__(self, key, value):
        "Allows the use of a dictionary-style interface to the session class."
        return self.set(key,value)
        
    def __delitem__(self, key):
        "Allows the use of a dictionary-style interface to the session class."
        if key in dir(self):
            raise SessionError("You cannot delete the key '%s' as it is used by the session module"%(key))
        else:
            self.delete(key)

    def __getattr__(self, name):
        """Get the value of one of the params specified in lemon.session.start()"""
        if self.params.has_key(name):
            return self.params[name]
        else:
            raise SessionError("The session does not have a parameter named '%s'."%name)

    #def __setattr__(self, name, value):
    #    if name in dir(self):
    #        raise SessionError("You cannot set the variable '%s' using this method. Choose a different name or use the set() method."%name)
            #is self.__dict__[name] = value
    #    else:
    #        self.set(name,value)

    #def __delattr__(self, name):
    #    if name in dir(self):
    #        raise SessionError("You cannot delete the key '%s' as it is used by the session module"%(key))
    #    else:
    #        self.delete(name)
            
    #
    # Storage Driver Overridden Functions
    #
    
    def _addSession(sessionID):
        "Private method overridden in derived classes. Creates a new session setting the 'Created' and 'Accessed' variables."
        raise SessionError('Should be overriden in the derived classes.')
        
    def _removeSession(sessionID):
        "Private method overridden in derived classes. Removes session information from the session store."
        raise SessionError('Should be overriden in the derived classes.')
        
    def _set(self, key, value):
        "Private method overridden in derived classes. Sets the variable 'key' to the value 'value'."
        raise SessionError("The _set() method should be overridden in the derived class.")
    
    def _get(self, key):
        "Private method overridden in derived classes. Gets the variable 'key' from the session store."
        raise SessionError("The _get() method should be overridden in the derived class.")
                
    def _delete(self, key):
        "Private method overridden in derived classes. Removes the variable 'key' from the session store."
        raise SessionError("The _delete() method should be overridden in the derived class.")
        
    def _cleanupSessions(self):
        "Private method to remove all expired sessions."
        raise SessionError('This function should have been overridden in the derived class.')
        
    #~ def _updateAccessed(self):
        #~ "Private method overridden in derived classes. Update the 'Accessed' variable of the session."
        #~ raise SessionError('This function should have been overridden in the derived class.')
        
    def _sessionExists(self, sessionID):
        "Private method overridden in derived classes. Returns True if the session already exists, False otherwise."
        raise SessionError('Should be overriden in the derived classes.')

