"Utility functions"

    
def wrap(text, width):
    """
    A word-wrap function that preserves existing line breaks
    and most spaces in the text. Expects that existing line
    breaks are posix newlines (\n).
    """
    return reduce(
        lambda line, word, width=width: '%s%s%s' %(
            line,
            ' \n'[(len(line[line.rfind('\n')+1:]) + len(word.split('\n',1)[0]) >= width)],
            word,
        ),
        text.split(' ')
    )

    
import sgmllib, string

class StrippingParser(sgmllib.SGMLParser):

    from htmlentitydefs import entitydefs # replace entitydefs from sgmllib
    
    def __init__(self, validTags=[]): # valid_tags are the HTML tags that we will leave intact
        sgmllib.SGMLParser.__init__(self)
        self.result = ""
        self.endTagList = [] 
        self.valid_tags = validTags
        
    def handle_data(self, data):
        if data:
            self.result = self.result + data

    def handle_charref(self, name):
        self.result = "%s&#%s;" % (self.result, name)
        
    def handle_entityref(self, name):
        if self.entitydefs.has_key(name): 
            x = ';'
        else:
            # this breaks unstandard entities that end with ';'
            x = ''
        self.result = "%s&%s%s" % (self.result, name, x)
    
    def unknown_starttag(self, tag, attrs):
        """ Delete all tags except for legal ones """
        if tag in self.valid_tags:       
            self.result = self.result + '<' + tag
            for k, v in attrs:
                if string.lower(k[0:2]) != 'on' and string.lower(v[0:10]) != 'javascript':
                    self.result = '%s %s="%s"' % (self.result, k, v)
            endTag = '</%s>' % tag
            self.endTagList.insert(0,endTag)    
            self.result = self.result + '>'
                
    def unknown_endtag(self, tag):
        if tag in self.valid_tags:
            self.result = "%s</%s>" % (self.result, tag)
            remTag = '</%s>' % tag
            self.endTagList.remove(remTag)

    def cleanup(self):
        """ Append missing closing tags """
        for j in range(len(self.endTagList)):
                self.result = self.result + self.endTagList[j]    
        

def strip(html, validTags=[]):
    """Strip illegal HTML tags from string"""
    parser = StrippingParser(validTags)
    parser.feed(html)
    parser.close()
    parser.cleanup()
    return parser.result
    
    

def table(values, width=80):
    if (width <> None) and (width < 0 or type(width) <> type(1)):
        raise Exception('The output width must be an integer greater than 0.')
    else:
        d = {}
        for p in values:
            d[p[0]] = {'names':p[1],'widths':[], 'max':0}
        for column, v in d.items():
            d[column]['max'] = len(repr(str(column)))-2
            for field in v['names']:
                d[column]['widths'].append(len(repr(str(field)))-2)
                if len(repr(str(field)))-2 > d[column]['max']:
                    d[column]['max'] = len(repr(str(field)))-2
        output = ''
        length = len(d)
        c = 0
        for column in d.keys():
            c += 1
            end = ''; first = ''
            if c == 1:
                first = '+'
            if c == length:
                end = '\n'
            output += first+'-'+('-'*d[column]['max'])+'-+'+end
        c = 0
        for column in d.keys():
            c += 1
            end = ''; first = ''
            if c == 1:
                first = '|'
            if c == length:
                end = '\n'
            output += first+' '+repr(str(column))[1:-1]+(' '*(d[column]['max'] - len(repr(str(column)))+2))+' |'+end
        c = 0
        for column in d.keys():
            c += 1
            end = ''; first = ''
            if c == 1:
                first = '+'
            if c == length:
                end = '\n'
            output += first+'-'+('-'*d[column]['max'])+'-+'+end
        for value in range(len(d[column]['names'])):
            c = 0
            for column in d.keys():
                c += 1
                end = ''; first = ''
                if c == 1:
                    first = '|'
                if c == length:
                    end = '\n'
                output += first+' '+repr(str(d[column]['names'][value]))[1:-1]+(' '*(d[column]['max'] - len(repr(str(d[column]['names'][value])))+2))+' |'+end
        c = 0
        for column in d.keys():
            c += 1
            end = ''; first = ''
            if c == 1:
                first = '+'
            if c == length:
                end = '\n'
            output += first+'-'+('-'*d[column]['max'])+'-+'+end
        if width:
            lines = output.split('\n')
            g = len(lines)
            j = len(lines[0]) # Maximum number of characters in lines
            k = int((j / float(width))+1) # Number of rows
            rows = []
            for j in range(k):
                rows.append([])
            for line in lines:
                for j in range(k):
                    if j == (k-1):
                        rows[j].append(line[(j*width):((j+1)*width)]+'\n')
                    else:
                        rows[j].append(line[(j*width):((j+1)*width)]+'\n')
            o = ''
            for row in rows:
                o += ''.join(row)
            return o
        else:
            return output
            
def runWebServer(root='../',cgi='/doc/src/lib', ):
    import SocketServer
    import BaseHTTPServer
    import CGIHTTPServer
    import sys
    import os
    import posixpath
    import urllib

    class WebRequestHandler(CGIHTTPServer.CGIHTTPRequestHandler):
        
        cgi_directories = [cgi]
        
        def translate_path(self, path):
            """Translate a /-separated PATH to the local filename syntax.
    
            Components that mean special things to the local file system
            (e.g. drive or directory names) are ignored.  (XXX They should
            probably be diagnosed.)
    
            """
            path = posixpath.normpath(urllib.unquote(path))
            words = path.split('/')
            words = filter(None, words)
            path = root#os.getcwd()
            for word in words:
                drive, word = os.path.splitdrive(word)
                head, word = os.path.split(word)
                if word in (os.curdir, os.pardir): continue
                path = os.path.join(path, word)
            return path
        
    class ThreadingCGIServer(SocketServer.ThreadingMixIn,
                       BaseHTTPServer.HTTPServer):
        pass
    
    server = ThreadingCGIServer(('', 8080), WebRequestHandler)
    try:
        while 1:
            sys.stdout.flush()
            server.handle_request()
    except KeyboardInterrupt:
        print "Finished"

