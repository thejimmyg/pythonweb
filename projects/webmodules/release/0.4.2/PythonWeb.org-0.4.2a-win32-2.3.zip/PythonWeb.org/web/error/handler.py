"Ready-to-use custom error handler functions."

def htmlfile(dict, params={}):
    p = {
        'print':True,
    }
    for k,v in params.items():
        p[k]=v
    if not params:
        raise Exception("You must specify a file to write the error report to using the file parameter.")
    fp = open(p['file'], 'w')
    fp.write(dict['html'])
    fp.close()
    if p['print']:
        print "Exception occured. Output written to '%s'"%params['file']
    
def textfile(dict, params={}):
    p = {
        'print':True,
    }
    for k,v in params.items():
        p[k]=v
    if not params:
        raise Exception("You must specify a file to write the error report to using the file parameter.")
    fp = open(p['file'], 'w')
    fp.write(dict['text'])
    fp.close()
    if p['print']:
        print "Exception occured. Output written to '%s'"%params['file']
    
def html(dict, params={}):
    p = {
        'header':True,
    }
    for k,v in params.items():
        p[k]=v
        
    import web
    if p['header']:
        print web.header()
    print dict['html']
    
def text(dict, params={}):
    p = {
        'header':True,
    }
    for k,v in params.items():
        p[k]=v
    import web
    if p['header']:
        print web.header('text/plain')
    print dict['text']