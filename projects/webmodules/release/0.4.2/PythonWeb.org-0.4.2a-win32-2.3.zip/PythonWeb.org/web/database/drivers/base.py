"""web.database -- SQL database layer"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import datetime
import dtuple

class Debug:
    def __init__(self):
        self.sql = []
        self.types = []

#
# Converter Classes
#

"""Converters for the web.database module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import datetime
        
class SQLFieldConverter:
    def __init__(self, name, createSQL, codes=(), params={}):
        self.createSQL = createSQL
        self.params = params
        self.codes = codes
        if not name:
            self.name = self.__class__.__name__
        else:
            self.name = name
        
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        raise Exception('Should be overridden in the derived class')
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        raise Exception('Should be overridden in the derived class')

class StringConverter(SQLFieldConverter):
        
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            return str(field)
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        if len(str(object)) > 255:
            raise Exception('String fields only take of 255 characters or less.')
        return "'"+str(object).replace("'","''")+"'"


class CharConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            return str(field)[0:1]  
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"

        if object == None:
            return None
        if len(str(object)) > 1:
            raise Exception('String fields only take of 255 characters or less.')
        else:
            return "'"+str(object)[0:1].replace("'","''")+"'"   
            
                
class TextConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            return str(field)
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object).replace("'","''")+"'"

class IntegerConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            try:
                return int(field)
            except ValueError:
                raise Exception("Invalid value '%s' for integer."%field)
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        elif type(object) <> type(1):
            raise Exception("Objects should be integers not '%s'"%(str(type(object)[1:-1])))
        else:
            try:
                return int(object)
            except:
                pass
            else:
                raise Exception("'%s' is not an int."%field)
        
class FloatConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            try:
                return float(field)
            except ValueError:
                raise Exception("Invalid value '%s' for float."%field)
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        elif type(object) <> type(1.0):
            raise Exception("Objects should be floats not '%s'"%(str(type(object)[1:-1])))
        else:
            try:
                return float(object)
            except:
                pass
            else:
                raise Exception("'%s' is not an float."%field)
            
class DateConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            sql = str(field)#tup = datetime.isodate2tuple(str(field))
            return datetime.date(int(sql[0:4]),int(sql[5:7]),int(sql[8:10]))
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)[:10]+"'"

class DateTimeConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            sql = str(field)
            return datetime.datetime(int(sql[0:4]),int(sql[5:7]),int(sql[8:10]),int(sql[11:13]),int(sql[14:16]),int(sql[17:19]))

    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)[:19]+"'"
    
class TimeConverter(SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            sql = str(field)
            return datetime.time(int(sql[0:2]),int(sql[3:5]),int(sql[6:8]))
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)[:8]+"'"

class Fields:
    def __init__(self, fields):
        d = {}
        for field in fields:
            d[field.name] = field
        self.fields = d

    def __getattr__(self, name):
        try:
            return self.fields[name]
        except:
            raise AttributeError("No field type named '%s' exists."%name)

    def getByCode(self, code):
        for name, field in self.fields.items():
            if code in field.codes:
                return field
        raise Exception("No field type named '%s' exists."%name)
        
    def __getitem__(self, name):
        try:
            return self.fields[name]
        except:
            raise KeyError("No field type named '%s' exists."%name)



#
# Database classes
#

class DatabaseError(Exception):
    """Error Class for the DB Module. Use as follows:

    try:
        raise DBError(ERROR_PASSWORD)
    except SessionError, e:
        print 'DB exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return self.value
        
class baseConnection:
    def __init__(self):
        'Set up the database connection'
        raise DatabaseError('This function should be overridden in the derived class to set the self.connection object to a valid DB 2.0 API Connection object.')
        
    def cursor(self, autoExecute=True, convertMode='table', colTypesName='ColTypes', types={}, debug=False):
        "Return our custom cursor rather than the default connection cursor."
        raise DatabaseError('This function should be overridden in the derived class to return a custom cursor object.')

    # Delegate unrecognised methods/attributes to the cursor object
    def __getattr__(self, name):
        "Delegate unrecognised methods/attributes to the cursor object."
        return getattr(self.connection, name)

class baseCursor:
    "Base class for database adaptation layer"

#
# Initialisation
#


    def _setupOptions(self):
        "Overridden in derived classes"
        return [
                    [True, False],              # autoExecute
                    ['tuple','dict','dtuple'],  # fetchMode
                    [True, False],              # autoConvert
                    ['table', 'description'],   # convertMode
                ]
                

    def __init__(self, cursor, autoExecute, convertMode, colTypesName='ColTypes', types={}, debug=False):  
                
        # Verify the options
        autoConvert = True
        options = self._setupOptions()
       
        self._autoExecuteOptions = options[0]
        self._fetchModeOptions   = options[1]
        self._autoConvertOptions = options[2]
        self._convertModeOptions = options[3]
        
        if autoExecute not in self._autoExecuteOptions:
            raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        #if fetchMode not in self._fetchModeOptions:
        #    raise DatabaseError("fetchMode must be one of %s."%(str(self._fetchModeOptions),))
        if autoConvert not in self._autoConvertOptions:
            raise DatabaseError("autoConvert must be one of %s."%(str(self._autoConvertOptions),))
        if convertMode not in self._convertModeOptions:
            raise DatabaseError("convertMode must be one of %s."%(str(self._convertModeOptions),))
        # XXX Verify types as well.
            
        self.baseCursor = cursor
        
        # Setup the options
        self._colTypesName   = colTypesName
        self._autoExecute    = autoExecute
        self._fetchMode      = 'tuple'
        self._typesCache     = types
        self._autoConvert    = autoConvert
        self._convertMode    = convertMode
        self._fieldCodes     = None          # Defined in each derived class

        # To store results between calls
        
        self._colTypes = []
        self._colNames = []

        # Setup Loggin
        if debug:
            self.debug = Debug()
        else:
            self.debug = None
        
        # Specify the column type integers and strings
        self._setupFields()
        
        #~ if self._autoConvert not in self._autoConvertOptions:
            #~ raise Exception("'%s' is not a valid option for autoConvert.")
            
        # Setup the colTypes table if it is not already present
        if self._convertMode == 'table':
            if not self.tableExists(self._colTypesName):
                self._createColTypesTable()
        

    def _setupFields(self): # Override
        "This function is overridden in derived classes. It is used to specify the column type integers and strings for each field type Lemon allows. You should also set the self._autoConvertOptions list in this function if it needs to be changed."
        raise DBError("The function '_setupFields(self)' should be overriden in the derived class.")

#
# Delegate unrecognised methods/attributes to the cursor object
#
    def __getattr__(self, name):
        "Delegate unrecognised methods/attributes to the cursor object."
        #~ if name in ['description']:
            #~ return getattr(self.baseCursor, name)
        #~ else:
            #~ raise AttributeError("No attribute named '%s'"%name)
        return getattr(self.baseCursor, name)
#
# Useful SQL related functions
# 

    def tableExists(self, table):
        try:
            self.execute("SELECT * FROM "+table+" WHERE 3=4")
            self.baseCursor.fetchall()
        except:
            return False
        else:
            return True
        
    def columnExists(self, column, table):
        try:
            self.execute("SELECT "+column+" FROM "+table+" WHERE 3=4")
            self.baseCursor.fetchall()
        except:
            return False
        else:
            return True

    def columns(self, table):
        return self.columnNames(table)
        
    # Deprecated
    def columnNames(self, table):
        if self._convertMode == 'table':
            # Returns a list of all the column names for the table 'table'. Used if autoConvert='table'.
            self.execute("select ColumnName from "+self._colTypesName+" where TableName='"+table+"'")
            rows = self.baseCursor.fetchall()
            if not rows:
                if not self.tableExists(table):
                    raise Exception("There is no table named '%s' in the database."%table)
            res = []
            for row in rows:
                res.append(row[0])
                
        elif self._convertMode == 'description':
            self.execute("SELECT * FROM "+table+" WHERE 3=4")
            rows = self.baseCursor.fetchall()
            res = []
            for row in self.description:
                res.append(row[0])
        else:
            raise DatabaseError("convertMode should be 'table' or 'description'.. if it isn't you shouldn't have seen this anyway so this message indicates a bug.")
        return res
        
    def columnTypes(self, table):
        if self._typesCache.has_key(table.upper()):
            print self._typesCache[table.upper()]
        cols = self.columnNames(table)
  
        
#
# Table column types information
#

    def _createColTypesTable(self):
        "Create the ColumnTypes table required by the DB layer."
        self.execute("CREATE TABLE %s (TableName %s, ColumnName %s, ColumnType %s)"%(self._colTypesName, self.fields['String'].createSQL, self.fields['String'].createSQL, self.fields['Integer'].createSQL))
        self.execute("insert into "+self._colTypesName+" (TableName,ColumnName,ColumnType) values ('"+self._colTypesName+"', 'TableName', " + str(self.fields['String'].codes[0])+")")
        self.execute("insert into "+self._colTypesName+" (TableName,ColumnName,ColumnType) values ('"+self._colTypesName+"', 'ColumnName', " +str(self.fields['String'].codes[0])+")")
        self.execute("insert into "+self._colTypesName+" (TableName,ColumnName,ColumnType) values ('"+self._colTypesName+"', 'ColumnType', " +str(self.fields['Integer'].codes[0])+")")
        return True
        
    def _addColumnType(self, table, col, c):
        "Add a column type definition to the ColumnTypes table."
        self.execute("select ColumnName, ColumnType from "+self._colTypesName+" where TableName='"+table+"' and ColumnName='"+col+"'")
        rows = self.baseCursor.fetchall()
        if not rows:
            return self.execute("insert into "+self._colTypesName+" (TableName,ColumnName,ColumnType) values ('"+str(table)+"', '"+str(col)+"', " +str(c)+")")
        elif rows[0][1] <> type:
            return self.execute("update "+self._colTypesName+" set ColumnType='"+str(c)+"' where TableName='"+table+"' and ColumnName='"+col+"'")
            
    def _removeColumnType(self, table, col):
        "Remove a column type definition to the ColumnTypes table."
        return self.delete(self._colTypesName, WHERE="TableName='"+table+"' and ColumnName='"+col+"'")

    def _removeTableTypes(self, table):
        "Remove all definitions for the table 'table' from the ColumnTypes table."
        self.execute("delete from "+self._colTypesName+" where TableName='"+table+"'")

#
# Types Cache Management
#

    def mergeTypes(self, table, types):
        "Called to merge a partial a dictionary of fieldName: ColumnCode pairs." 
        if type(table) <> type('l'):
            raise Exception("Bad type '%s' for table name. Should be string."%table)
        if self._typesCache.has_key(table.upper()):
            for k,v in types.items():
                if type(k) <> type('s'):
                    raise Exception("Bad type '%s' for entry into the types cache. Should be string."%k)
                if type(v) <> type(1):
                    raise Exception("Bad type '%s' for entry into the types cache. Should be int."%v)
                if self._typesCache[table.upper()].has_key(k):
                    if self._typesCache[table.upper()][k] <> v:
                        raise Exception("The information to be merged into the types cache conflicts with data already in it. In table '%s' '%s'<>'%s'."%(table.upper(), self._typesCache[table.upper()][k], v))
                else:
                    self._typesCache[table.upper()][k] = v              
        else:
            self._typesCache[table.upper()] = {}
            for k,v in types.items():
                if type(k) <> type('s'):
                    raise Exception("Bad type '%s' for entry into the types cache. Should be string."%k)
                if type(v) <> type(1):
                    raise Exception("Bad type '%s' for entry into the types cache. Should be int."%v)
                self._typesCache[table.upper()][k] = v

    def _checkTypes(self, table, cols):
        "Checks to see if the columns specified by 'cols' are all present in the cache."
        if self._typesCache.has_key(table.upper()):
            for k in cols:
                if not self._typesCache[table.upper()].has_key(k):
                    return False
            return True
        else:
            return False

    def _getTableData(self, table): # XXX really might as well get the whole lot in one go.
        "Called to retrieve information on the types of each column for a particular database using the retrieval method set with the autoConvert option."
        if self._autoConvert:
            if self._convertMode == 'table':
                # Returns a list of all the column names for the table 'table'. Used if autoConvert='table'.
                self.execute("select ColumnName, ColumnType from "+self._colTypesName+" where TableName='"+table+"'")
                rows = self.baseCursor.fetchall()
                types = {}
                for row in rows:
                    types[row[0].upper()]=int(row[1])
                self.mergeTypes(table, types)
                
            elif self._convertMode == 'description':
                if not self._typesCache.has_key(table):
                    # Obtain the type from the database
                    self.execute("SELECT * FROM "+table+" WHERE 3=4")
                    types = {}
                    for row in self.description:
                        types[row[0].upper()]=int(row[1])
                    self.mergeTypes(table, types)
            else:
                 raise DatabaseError("You cannot retrieve table data without setting convertMode to 'table' or 'description'.")
        else:
            raise DatabaseError("You cannot retrieve table data without setting autoConvert to True.")
        return self._typesCache[table.upper()]
        

    def _getTypes(self, table, fields):
        "Called to get a list of field types from a table name and a list of field names."
        if self._checkTypes(table, fields):
            desc = self._typesCache[table.upper()]
        else:
            desc = self._getTableData(table)
        colTypes = []
        for col in fields: # ie for each column
            if desc.has_key(col.upper()):
                colTypes.append(desc[col.upper()])
            else:
                raise DatabaseError("The column '%s' doesn't exist in the types cache. Does the table have a '%s' column?"%(col.upper(),col.upper()))
        return colTypes
 
    def _getType(self, table, field):
        return self._getTypes(table, [field])[0]

#
# Encoding (and error checking # XXX ) Functions 
#

    
    def _encodeRow(self, types, values):
        "Called to encode the data sent as SQL to ensure all strings are handled correctly across each database."
        if len(values) != len(types):
            raise DatabaseError("Type conversion error: The values submitted don't match the types values from the database. %s %s"%(types, values))
        encodedValues = []
        for field in range(len(values)):
            fieldType = types[field]
            fieldValue = values[field]
            encodedValues.append(self.fields.getByCode(fieldType).sql(fieldValue))
        return tuple(encodedValues)
    
    def _decodeRow(self, types, values):
        "Called to convert the results of a select or function call to the correct types."
        if len(types) != len(values):
            raise DatabaseError("Type conversion error: The values submitted don't match the types values from the database. %s %s"%(types, values))
        decodedValues = []
        for field in range(len(values)):
            fieldType = types[field]
            fieldValue = values[field]
            decodedValues.append(self.fields.getByCode(fieldType).object(fieldValue))
        return tuple(decodedValues)

        
    
#
# Cursor Methods
#
    
    def execute(self, sql, values=None):
        if self.debug:
            self.debug.sql.append(sql)
            self.debug.types.append(self._typesCache)
        if values:
            self.baseCursor.execute(sql,values)
        else:
            self.baseCursor.execute(sql)

#
# Fetch operations
#   

    
    def fetchRows(self, fetchMode=None, types=None):
        """Retrieve all the rows from the query in the format of a sequence of results.
        The 'types' value should be a dictionary containing the table names with each table being the key to another dict containg the column names and types."""

        # Check we have something to return
        results = self.baseCursor.fetchall()
        if len(results) == 0:
            return results

        # Check options are valid
        if fetchMode <> None:
            if fetchMode not in self._fetchModeOptions:
                raise DatabaseError("fetchMode must be one of %s."%(str(self._fetchModeOptions),))
        else:
            fetchMode = self._fetchMode
        if types:
            for k in types.items():
                self.mergeTypes(k, types[k])

        colTypes = self._colTypes
        colNames = self._colNames
        
        rows = []
        for row in results:
            if self._autoConvert == True:
                row = self._decodeRow(colTypes,row)
            if fetchMode == 'dict':
                dict={}
                for field in range(len(row)):
                    dict[colNames[field]] = row[field]
                rows.append(dict)
            elif fetchMode == 'dtuple':
                descr = dtuple.TupleDescriptor([[n] for n in colNames])
                rows.append(dtuple.DatabaseTuple(descr, row))
            elif fetchMode == 'tuple':
                rows.append(tuple(row))
            else:
                raise Exception("'%s' is not a valid option for fetchMode.")
        return tuple(rows)

#
# SQL statement generators
#

    def select(self, columns, table, as=None, where=None, order=None, rest=None, autoExecute=None, fetchMode=None, distinct=False):
        fields = columns
        aliases = as
        # Setup the default actions
        #~ if autoConvert <> None:
            #~ if autoConvert not in self._autoConvertOptions:
                #~ raise DatabaseError("autoConvert must be one of %s."%(str(self._autoConvertOptions),))
        #~ else:
            #~ autoConvert = self._autoConvert
        autoConvert = self._autoConvert
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
        if not autoExecute and fetchMode:
            raise Exception("You cannot set the fetchMode if you haven't set autoExecute as there would be nothing to fetch.")
        if fetchMode <> None:
            if fetchMode not in self._fetchModeOptions:
                raise DatabaseError("fetchMode must be one of %s."%(str(self._fetchModeOptions),))
        else:
            fetchMode = self._fetchMode
        
        # Get the fields in the correct format
        if fields == '*':
            fields = self.columnNames(table)

        if type(fields) is type(''):
           fields = [fields]
        if type(table) is type(''):
           table = [table]
        if type(aliases) is type(''):
           aliases = [aliases]
        if len(fields) == 0:
            raise Exception('You must specify at least one field.')
        if len(table) == 0:
            raise Exception('You must specify at least one table.')
        if aliases and len(aliases) <> len(fields):
            raise Exception("Number of aliases doesn't match number of fields.")

        names = [] # XXX To be filled later!
        types = [] # XXX To be filled later!

        # Check all the fields are in the same format and the tables format matches the fields format
        multipleJoins = False
        for field in fields:
            if '.' in field:
                multipleJoins=True
                break
        sqlFields = []
        counter = 0
        if multipleJoins == True:
            for field in fields:
                if '.' not in field:
                    raise Exception("'%s' is an invalid field name. If you are selecting from multiple tables all fields should be fully qualified in the form 'tableName.fieldName'."%field)
                if field.count('.') > 1:
                    raise Exception("Field names cannot have more than one '.' so '%s' is an invalid name."%field)
                tableName = field[:field.index('.')]
                if not tableName in table:
                    raise Exception("You are selecting '%s' from table '%s' but '%s' is not listed in the 'table' parameter."%(field, tableName, tableName))
                fieldName = field[field.index('.')+1:]
                if self._autoConvert == True:
                    if not self._typesCache.has_key(tableName.upper()):
                        self._getTableData(tableName)
                    if not self._typesCache[tableName.upper()].has_key(fieldName.upper()):
                        raise Exception("No types information available for '%s' field in table '%s'."%(fieldName, tableName))
                    types.append(self._typesCache[tableName.upper()][fieldName.upper()])
                if aliases and aliases[counter]:
                    names.append(aliases[counter])
                    sqlFields.append(field+' AS '+aliases[counter])
                else:
                    names.append(field)
                    sqlFields.append(field)
                counter+=1
        else:
            if len(table)>1:
                raise Exception("You have specifed more than one table but none of the fields are of the form 'tableName.fieldName'."%field)
            for field in fields:
                if aliases and aliases[counter]:
                    names.append(aliases[counter])
                    sqlFields.append(field+' AS '+aliases[counter])
                else:
                    names.append(field)
                    sqlFields.append(field)
                if self._autoConvert == True:
                    if not self._typesCache.has_key(table[0].upper()):
                        self._getTableData(table[0])
                    if not self._typesCache[table[0].upper()].has_key(field.upper()):
                        if self.tableExists(table[0]):
                            if self.columnExists(field, table[0]):
                                raise Exception("No types information available for '%s' field in table '%s'."%(field, table[0]))
                            else:
                                raise Exception("Column '%s' not found in the '%s' table."%(field, table[0]))
                        else:
                            raise Exception("There is no '%s' table in the database. Have you connected to the correct database or chosen the wrong table?"%(table[0]))
                    types.append(self._typesCache[table[0].upper()][field.upper()])
                counter += 1

        self._colNames = names
        self._colTypes = types
        
        sql = "SELECT "
        if distinct:
            sql += "DISTINCT " 
        sql += ", ".join(sqlFields)
        if table:
            sql += " FROM %s" % ', '.join(table)
        if where:
            sql += " WHERE %s" % where
        if order:
            sql += " ORDER BY %s" % order
        if rest:
            sql += " %s" % rest
            
        if autoExecute == False:
            return sql
        else:
            # Don't need to worry about convertResult since it is taken care of in fetchRows()
            # Don't need to worry about fetchMode since it is taken care of in fetchRows()
            self.execute(sql)
            return self.fetchRows(fetchMode, None)

    def insert(self, table, columns, values, autoExecute=None):
        fields = columns
        # Setup the default actions
        #if autoConvert <> None:
        #    if autoConvert not in self._autoConvertOptions:
        #        raise DatabaseError("autoConvert must be one of %s."%(str(self._autoConvertOptions),))
        #else:
        #    autoConvert = self._autoConvert
        autoConvert = self._autoConvert
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
        fieldList = ""
        valuesString = ""
        if type(fields) <> type(()) and type(fields) <> type([]):
            fields = tuple([fields])
        fieldList = ", ".join(fields)

        if len(fields) is 1:
            valuesString = '%s'
        else:
            valuesString = (('%s' + ", ")*(len(fields)-1))+'%s'

        sql = "INSERT INTO %s (%s) VALUES (%s)" % (table, fieldList, valuesString)

        # Convert the values to the in the correct format
        if type(values) <> type(()) and type(values) <> type([]):
            values = tuple([values])
            
        # Convert the values to the correct type
        if autoConvert == False:
            for v in values:
                if type(v) <> type(''):
                    raise Exception("If you don't want values autoConverted they must be supplied as properly quoted strings.")
        else:
            types = self._getTypes(table, fields)
            values = self._encodeRow(types, values)
            
        # Execute the query
        val = []
        for v in values:
            if v == None:
                val.append('NULL')
            else:
                val.append(v)
        sql = sql%(tuple(val))
        if autoExecute is True:
            self.execute(sql)
        return sql

    def update(self, table, fields, values, where=None, autoExecute=None):
        # Setup the default actions
        #~ if autoConvert <> None:
            #~ if autoConvert not in self._autoConvertOptions:
                #~ raise DatabaseError("autoConvert must be one of %s."%(str(self._autoConvertOptions),))
        #~ else:
            #~ autoConvert = self._autoConvert
        autoConvert = self._autoConvert
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
        if type(fields) <> type(()) and type(fields) <> type([]):
            fields=(fields,)
        if type(values) <> type(()) and type(values) <> type([]):
            values = tuple([values])
            
        if len(fields) != len(values):
            raise DatabaseError("UPDATE column count disqlFieldsers from value count.")
    
        # Convert the values to the correct type
        if autoConvert == False:
            for v in values:
                if type(v) <> type(''):
                    raise Exception("If you don't want values autoConverted they must be supplied as properly quoted strings.")
        else:
            types = self._getTypes(table, fields)
            values = self._encodeRow(types, values)
        
        params=[]
        for item in values:
            params.append('%s')
        sql = "UPDATE %s SET %s" % (table, ", ".join(map(lambda x,y: str(x)+"="+str(y), fields, params)))
        if where:
            sql += " WHERE " + where
        val = []
        for v in values:
            if v == None:
                val.append('NULL')
            else:
                val.append(v)
        sql = sql%(tuple(val))
        if autoExecute == True:
            self.execute(sql)
        return sql

    def delete(self, table, where=None, autoExecute=None):
        # Setup the default actions
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
        sql = "DELETE FROM %s" % table
        if where:
            sql += " WHERE %s" % where
        if autoExecute == True:
            self.execute(sql)
        return sql

    def create(self, table, fields, autoExecute=None):
        return self._create(table, fields, autoExecute)
        
    def _create(self, table, fields, autoExecute=None):#, auto=None, primary=None, notNULL=None, unique=None, default=None):
        """Fields:
            (name, type, notNULL, default, unique)
        """

        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
            
        if table == self._colTypesName:
            raise DatabaseError("You cannot create the '"+self._colTypesName+"' table using this method. It is a reserved table name.")
        
        self._typesCache[table.upper()] = {}
        
        for f in fields:
            #if type(f[1]) in [type([]), type((1,))]:
            #    c = f[1][0]
            #else:
            #    c = f[1]
            c = self.fields[f[1]].codes[0]
            self._typesCache[table.upper()][f[0].upper()] = c
            if self._autoConvert == True and self._convertMode == 'table':
                self._addColumnType(table, f[0], c)

        sqlFields = []
        for f in range(len(fields)): 
            if len(fields[f][0])>255:
                raise DatabaseError('Column names must be 255 charaters or less.')
                
            # name, type
            stri = "%s %s" % (fields[f][0], self.fields[fields[f][1]].createSQL)
            # notNULL
            if len(fields[f])>2:
                if fields[f][2] == True:
                    stri += ' NOT NULL'
            # default
            if len(fields[f])>3:
                if fields[f][3]:
                    stri += ' DEFAULT '+str(fields[f][3])
            #~ # auto
            #~ if len(fields[f])>4:
                #~ if fields[f][4] == True:
                    #~ stri += ' AUTO_INCREMENT'
            #~ # primary
            #~ if len(fields[f])>5:
                #~ if fields[f][5] == True:
                    #~ stri += ' PRIMARY KEY'
            # unique
            if len(fields[f])>4:
                if fields[f][4] == True:
                    stri += ' UNIQUE'
            
            sqlFields.append(stri)
        sql = "CREATE TABLE %s (%s)" % (table, ", ".join(sqlFields))
        
        if autoExecute == True:
            self.execute(sql)
        return sql
            

    def drop(self, table, autoExecute=None):
        "Remove a table from the database."

        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute
            
        if table == self._colTypesName:
            raise DatabaseError("You cannot drop the '"+self._colTypesName+"' table using this method. It is a reserved table name.")
        if self._typesCache.has_key(table.upper()):
            del self._typesCache[table.upper()]
        if self._autoConvert == True and self._convertMode == 'table':
            self._removeTableTypes(table)

        result = "DROP TABLE %s" % table
        if autoExecute is True:
            self.execute(result)
        return result

    def max(self, field, table, where=None):
        return self._function('max',field, table, where, True)
        
    def min(self, field, table, where=None):
        return self._function('min',field, table, where, True)

    def _function(self, func, field, table, where=None, autoExecute=None):

        # Setup the default actions
        #~ if autoConvert <> None:
            #~ if autoConvert not in self._autoConvertOptions:
                #~ raise DatabaseError("autoConvert must be one of %s."%(str(self._autoConvertOptions),))
        #~ else:
            #~ autoConvert = self._autoConvert
        autoConvert = self._autoConvert
        if autoExecute <> None:
            if autoExecute not in self._autoExecuteOptions:
                raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        else:
            autoExecute = self._autoExecute

        if func.upper() in ['MAX', 'MIN']:
            if self._autoConvert == True:
                if not self._typesCache.has_key(table.upper()):
                    self._getTableData(table)
                if not self._typesCache[table.upper()].has_key(field.upper()):
                    raise Exception("No types information available for '%s' field in table '%s'."%(field, table))
                self._colTypes = [self._typesCache[table.upper()][field.upper()]]
            self._colName = [field]

            sql = "SELECT %s(%s) FROM %s" % (func, field, table)
            if where:
                sql += " WHERE %s" % where

            self.execute(sql)
            val = self.fetchRows('tuple', None)[0][0]
            return val

        else:
            raise DatabaseError("The function '%s' is not supported by the database module."%func)

    #
    # Deprecated
    #


    #~ def sum(self, field, table, where=None):
        #~ return self.function('sum',field, table, where)
        
    #~ def average(self, field, table, where=None):
        #~ return self.function('avg',field, table, where)