"""MySQL driver for the web.database module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import sqlite
import base

class sqliteConnection(base.baseConnection):
    def __init__(self, database):
        'Set up the database connection'
        self.connection = sqlite.connect(database)
        
    def cursor(self, autoExecute=True,  convertMode='table', colTypesName='ColTypes', types={}, debug=False):
        "Return our custom cursor rather than the default connection cursor."
        return sqliteCursor(self.connection.cursor(), autoExecute, convertMode, colTypesName, types, debug)
        
class sqliteCursor(base.baseCursor):

    def _setupOptions(self):
        return [
                    [True, False],              # autoExecute
                    ['tuple','dict','dtuple'],  # fetchMode
                    [True, False],              # autoConvert
                    ['table'],   # convertMode
                ]

    def _setupFields(self):
        self.type = 'sqlite'
        self.fields = base.Fields(
            [
                base.CharConverter       ('Char',     "CHAR",           (1,)),
                base.StringConverter     ('String',   "TEXT",           (2,)),
                base.TextConverter       ('Text',     "TEXT",           (3,)),
                base.IntegerConverter    ('Integer',  "INTEGER",        (4,)),
                base.FloatConverter      ('Float',    "FLOAT",          (5,)),
                base.DateConverter       ('Date',     "TEXT",           (6,)),
                base.TimeConverter       ('Time',     "TEXT",           (7,)),
                base.DateTimeConverter   ('DateTime', "TEXT",           (8,)),
            ]
        )

    #~ def _function(self, func, field, table, where=None, autoExecute=None):
        #~ # Setup the default actions
        #~ autoConvert = self._autoConvert
        #~ if autoExecute <> None:
            #~ if autoExecute not in self._autoExecuteOptions:
                #~ raise DatabaseError("autoExecute must be one of %s."%(str(self._autoExecuteOptions),))
        #~ else:
            #~ autoExecute = self._autoExecute
        #~ if func.upper() in ['MAX', 'MIN']:
            #~ self._colName = [field]
            #~ sql = "SELECT %s FROM %s" % (field, table)
            #~ if where:
                #~ sql += " WHERE %s" % where
            #~ sql += " ORDER BY %s;"%field
            #~ if autoExecute:
                #~ self.execute(sql)
                #~ val = self.fetchone()
                #~ if func.upper() == 'MIN':
                    #~ val = val[0]
                #~ if func.upper() == 'MAX':
                    #~ val = val[-1:]
                #~ if self._autoConvert == True:
                    #~ typ = self.getType(table, field) # Make sure the field is in the cache
                    #~ return self.fields.getByCode(typ).object(val[0])
                #~ else:
                    #~ return val
            #~ else:
                #~ return sql
        #~ else:
            #~ raise DatabaseError("The function '%s' is not supported by the database module."%func)