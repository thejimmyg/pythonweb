"""ODBC driver for the web.database module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."

import os
if os.name == 'nt' or os.name == 'dos':
    try:
        import mx.ODBC.Windows as odbc
    except:
        raise ImportError("The mx.ODBC module could not be imported. Is it installed? You may also need mx.BASE")
elif os.name == 'posix':
    raise Exception('ODBC driver not tested for posix.')
    import mx.ODBC.iODBC as odbc
else:
    raise Exception('ODBC driver not implemented for your platform')
    
import base, datetime

class DateConverter(base.SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            tup = datetime.isodate2tuple(str(field)[0:10])
            return datetime.date(tup[0],tup[1],tup[2])
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)+"'"

class DateTimeConverter(base.SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            #raise Exception(field.__class__.__name__)
            tup = datetime.isodatetime2tuple(str(field)[:-3])
            return datetime.datetime(tup[0],tup[1],tup[2],tup[3],tup[4],tup[5])
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)+"'"
    
class TimeConverter(base.SQLFieldConverter):
    def object(self, field):
        "Converts an SQL string for the field into a Python object"
        if field == None:
            return None
        else:
            tup = datetime.isotime2tuple(str(field)[11:19])
            return datetime.time(tup[3],tup[4],tup[5])
        
    def sql(self, object):
        "Converts a Python object into an SQL string for the field"
        if object == None:
            return None
        else:
            return "'"+str(object)+"'"
            
class odbcConnection(base.baseConnection):
    def __init__(self, database):
        'Set up the database connection'
        self.connection = odbc.connect(database) 
        
    def cursor(self, autoExecute=True, convertMode='table', colTypesName='ColTypes', types={}, debug=False):
        "Return our custom cursor rather than the default connection cursor."
        return odbcCursor(self.connection.cursor(), autoExecute,  convertMode, colTypesName, types, debug)

class odbcCursor(base.baseCursor):

    def _setupOptions(self):
        return [
                    [True, False],              # autoExecute
                    ['tuple','dict','dtuple'],  # fetchMode
                    [True, False],              # autoConvert
                    ['table'],                  # convertMode
                ]
        
    def _setupFields(self):
        self.type = 'odbc'
        self.fields = base.Fields(
            [
                base.CharConverter       ('Char',     "CHAR",           (1,)),
                base.StringConverter     ('String',   "VARCHAR",        (2,)),
                base.TextConverter       ('Text',     "MEMO",           (3,)),
                base.IntegerConverter    ('Integer',  "INTEGER",       (4,)),
                base.FloatConverter      ('Float',    "FLOAT",          (5,)),
                DateConverter            ('Date',     "DATE",           (6,)),
                TimeConverter            ('Time',     "TIME",           (7,)),
                DateTimeConverter        ('DateTime', "DATETIME",       (8,)),
            ]
        )