"""Database driver for the auth module.

N.B. You cannot have a column named username as Gadfly thinks it is ambiguous hence the username column is
called user.
"""

import authBase
from web.errors import AuthError

class AuthAdminDatabase:
    
    def __init__(self, cursor, table='Auth'):
        self.cursor = cursor
        self.table = table
        
    def applicationExists(self, app):
        """Test to see if the application named 'app' exists. N.B. This function doesn't test whether the data is valid or whether the level info is availabel, just whether the file exists.""" 
        rows = self.cursor.select('name','%sApp'%self.table, where="name='"+app+"'", fetchMode='tuple')
        if rows:
            return True
        else:
            return False
            
    def addApplication(self, app):
        """Add an application named 'app' unless it already exists in which case raise an AuthError."""
        if self.applicationExists(app):
            raise AuthError("The '%s' application already exists."%app)
        else:
            self.cursor.insert('%sApp'%self.table, 'name', app)
            
    def removeApplicaiton(self, app):
        """Remove an application named 'app' unless it doesn't exist in which case raise an AuthError."""
        if not self.applicationExists(app):
            raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            self.cursor.delete('%sLevel'%self.table,where="app='"+app+"'")
            self.cursor.delete('%sApp'%self.table,where="name='"+app+"'")

    def userExists(self, username):
        """Test to see if the user with the username 'username' exists.""" 
        rows = self.cursor.select('user','%sUser'%self.table, where="user='"+username+"'", fetchMode='tuple')
        if rows:
            return True
        return False
        
    def addUser(self, username, password, firstname='', surname='', email=''):
        """Add a user with the username 'username' and the password 'password' unless the username already exists in which case raise an AuthError
        Can optionally specify a firstname, surname and email for the user."""
        if self.userExists(username):
            raise AuthError('That user already exists.')
        else:
            self.cursor.insert('%sUser'%self.table,('user', 'password', 'firstname', 'surname', 'email'),(username,password,firstname,surname,email))

    def removeUser(self, username):
        """Remove a user with the username 'username' unless the username doesn't exist in which case raise an AuthError."""
        if self.userExists(username):
            self.cursor.delete('%sUser'%self.table,where="user='"+username+"'")
            self.cursor.delete('%sLevel'%self.table,where="user='"+username+"'")
        else:
            raise AuthError("The user '%s' doesn't exist."%(username))

    def setAccessLevel(self, username, app, level):
        """Set the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        if self.userExists(username):
            if self.applicationExists(app):
                rows = self.cursor.select('accessLevel','%sLevel'%self.table,where="user='"+username+"' and app='"+app+"'", fetchMode='tuple')
                if rows:
                    self.cursor.update('%sLevel'%self.table, ('user','app','accessLevel'), (username,app,int(level)), where="user='"+username+"' and app='"+app+"'")
                else:
                    self.cursor.insert('%sLevel'%self.table, ('user','app','accessLevel'), (username,app,int(level)))
                return True
            else:
                raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            raise AuthError("The user '%s' doesn't exist."%username)

    def getAccessLevel(self, username, app):
        """Return the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        levels = self.getAccessLevels(username)
        if levels.has_key(app):
            return levels[app]
        else:
            return None

    def getAccessLevels(self, username):
        """Return a dictioanry containing the access level of the user with username 'username' for every application the user has been granted access to. Raise an AuthError if there is no user called 'username'."""
        if self.userExists(username):
            rows = self.cursor.select(('app','accessLevel'),'%sLevel'%self.table,where="user='"+username+"'", fetchMode='tuple')
            #raise Exception(rows)
            d = {}
            for row in rows:
                d[row[0]] = row[1]
            return d
        else:
            raise AuthError('That username doesn\'t exist.')

    def _setProperty(self, property, username, value):
        """Private method to set the value of one of 'password', 'firstname', 'surname' and 'email' for a particular user."""
        if property in ['password','firstname','surname','email']:
            if self.userExists(username):
                self.cursor.update('%sUser'%self.table, (property,), (value,), where="%s='%s'"%(property,value))
            else:
                raise AuthError('That user doesn\'t exist.')
        else:
            raise AuthError("You can only set the properties 'password', 'firstname', 'surname' and 'email'")
            
    def setFirstname(self, username, value):
        """Sets the firstname of the user 'username' to 'value'."""
        return self._setProperty('firstname', username, value)
        
    def setSurname(self, username, value):
        """Sets the surname of the user 'username' to 'value'."""
        return self._setProperty('surname', username, value)

    def setEmail(self, username, value):
        """Sets the email address of the user 'username' to 'value'."""
        return self._setProperty('email', username, value)
            
    def setPassword(self, username, value):
        """Sets the password of the user 'username' to 'value'."""
        return self._setProperty('password', username, value)
        
    def users(self):
        """Return a list of current usernames."""
        rows = self.cursor.select('user', '%sUser'%self.table, fetchMode='tuple')
        if rows:
            return rows[0]
        else:
            return []
            
    def apps(self):
        """Return a list of current applications."""
        rows = self.cursor.select('name', '%sApp'%self.table, fetchMode='tuple')
        if rows:
            return rows[0]
        else:
            return []
            
    def getUser(self, username, app=None, property=None):
        """Returns a data structure containing useful infomation about the user.
        eg. 
            user = getUser('testuser', 'testapp')
            
            # The variables below all return values the value as expected
            user.username, user.email, user.password, user.firstname, user.surname
            
            user.app # contains a structure of apps which testuser has access to
            user.app.testapp.level # returns testuser's access level to 'testapp'.
            
            user.apps() # returns a list of app names. (Similar to the auth.apps() function)"""
        if self.userExists(username):
            # Read the user level
        
            if app == None:
                app = self.app
            
            from objects import App, Apps, User

            rows = self.cursor.select(('user','password','firstname','surname','email'), '%sUser'%self.table, where="user='%s'"%username, fetchMode='dict')
            object = rows[0]
            level = self.getAccessLevel(username, app)
            user = User(
                {
                    'username':object['user'],
                    'password':object['password'],
                    'firstname':object['firstname'],
                    'surname':object['surname'],
                    'email':object['email'],
                    #'app':appStructure,
                    'level':self.getAccessLevels(username),
                    'accessLevel': level,
                }
            )
            
            if not property:
                return user
            elif user.has_key(property):
                return user[property]
            else:
                raise AuthError("No such property '%s'."%property)
        else:
            raise AuthError("No such username '%s'."%username)

    def getFirstname(self, username):
        """Returns the firstname of the user 'username'."""
        return self.getUser(username, property='firstname')
        
    def getSurname(self, username):
        """Returns the surname of the user 'username'."""
        return self.getUser(username, property='surname')
        
    def getEmail(self, username):
        """Returns the email address of the user 'username'."""
        return self.getUser(username, property='email')

    def getPassword(self, username):
        """Returns the password of the user 'username'."""
        return self.getUser(username, property='password')
        

class AuthManagerDatabase(AuthAdminDatabase):
    
#
# Auth Manager code (Over-ridden in other classses)
#

    def createTables(self):#, autoCommit=None): # autoCommit needed for the Gadfly types information to be added.
        "autoCommit should be None or else a valid database connection to commit the db changes."
        errors = []
        # Auth User
        if not self.cursor.tableExists('%sUser'%self.table):
            self.cursor.create(
                '%sUser'%self.table,
                (    
                    ('user', 'String' ),
                    ('password', 'String' ),
                    ('firstname','String' ),
                    ('surname',  'String' ),
                    ('email',    'String' ),
                )
            )
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sUser' table already exists."%self.table)
    
        # Auth
        if not self.cursor.tableExists('%sLevel'%self.table):
            self.cursor.create(
                '%sLevel'%self.table,
                (    
                    ('user',     'String'),
                    ('app',      'String' ),
                    ('accessLevel',    'Integer'),
                )
            )
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sLevel' table already exists."%self.table)
            
        # AuthApp
        if not self.cursor.tableExists('%sApp'%self.table):
            self.cursor.create( 
                '%sApp'%self.table,
                (    
                    ('name',     'String' ),
                )
            )
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sApp' table already exists."%self.table)

        return errors
    
    def dropTables(self):#, autoCommit=None):
        "autoCommit should be None or else a valid database connection to commit the db changes."
        errors = []
        #raise Exception(self.cursor)
        if self.cursor.tableExists('%sLevel'%self.table):
            self.cursor.drop('%sLevel'%self.table)
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sLevel' table doesn't exist."%self.table)
        if self.cursor.tableExists('%sApp'%self.table):
            self.cursor.drop('%sApp'%self.table)
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sApp' table doesn't exist."%self.table)
        if self.cursor.tableExists('%sUser'%self.table):
            self.cursor.drop('%sUser'%self.table)
            #if autoCommit:
            #    autoCommit.commit()
        else:
            errors.append("The '%sUser' table doesn't exist."%self.table)
        return errors
            
    def tablesExist(self):
        if self.cursor.tableExists('%sLevel'%self.table) and self.cursor.tableExists('%sUser'%self.table) and self.cursor.tableExists('%sApp'%self.table):
            return True
        return False

class AuthDatabase(AuthAdminDatabase, authBase.AuthBase):
    
#
# Auth Driver code (Over-ridden in other classses)
#

    def __init__(
        self, 
        session, 
        expire=0, 
        idle=0, 
        signInForm=None, 
        autoSignIn=True, 
        autoRedirect=False,
        redirect=None, 
        includeQuery=False, 
        stickyData={}, 
        reminderForm=None, 
        emailOptions=None, 
        app=None, 
        errorCodes=None, 
        htmlPage=None,
        encryption=None,
        cursor = None,
        table='Auth',
        debug=False,
        checkSignInAttempt=False,
        htmlPageRegions={'content':'content','title':'title'},
    ):
        if not cursor:
            raise AuthError('No database cursor specified.')
        else:
            self.cursor = cursor
            self.table = table
            return authBase.AuthBase.__init__(
                self,
                session, 
                expire, 
                idle, 
                signInForm, 
                autoSignIn, 
                autoRedirect,
                redirect, 
                includeQuery, 
                stickyData, 
                reminderForm, 
                emailOptions, 
                app, 
                errorCodes,
                htmlPage,
                encryption,
                debug,
                checkSignInAttempt,
                htmlPageRegions,
            )
