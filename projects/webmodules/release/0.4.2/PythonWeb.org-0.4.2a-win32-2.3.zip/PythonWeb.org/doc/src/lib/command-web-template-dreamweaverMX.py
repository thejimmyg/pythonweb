#!/usr/bin/env python

import sys; sys.path.append('../../../') # show python where the web modules are

import web.template

dict =  {
            'Content':'Welcome to the test page!',
            'doctitle':'Dreamweaver MX Example',
            'Title':'Dreamweaver MX Example',
        }
        
print web.template.parse(type='dreamweaverMX', file='file-web-template-dreamweaverMX.dwt', dict=dict)