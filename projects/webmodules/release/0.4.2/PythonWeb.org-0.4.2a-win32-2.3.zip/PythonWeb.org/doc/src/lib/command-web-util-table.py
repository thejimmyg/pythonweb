#!/usr/bin/env python

import sys; sys.path.append('../../../') # show python where the web modules are

import web.util
table = (
    ('column1Heading', ('column1value1', 'column1value2', 'column1value3')),
    ('column2Heading', ('column2value1', 'column2value2', 'column2value3')),
    ('column3Heading', ('column3value1', 'column3value2', 'column3value3')),
    ('column4Heading', ('column4value1', 'column4value2', 'column4value3')),

)
print "Printing the table with wrap width=0...\n"
print web.util.table(table, width=0)
print "Printing the table with wrap width=60...\n"
print web.util.table(table, width=60)

