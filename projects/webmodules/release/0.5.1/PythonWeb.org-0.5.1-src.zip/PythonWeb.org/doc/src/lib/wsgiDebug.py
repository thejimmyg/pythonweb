import web.wsgi.base, web.wsgi.error

class simpleApp(web.wsgi.base.BaseApplication):
    def start(self):
        import web.error
        value = 5
        raise web.error.Breakpoint('Test Exception')

application = simpleApp()


