"Auth Handling"


import web.wsgi.base

class Auth(web.wsgi.base.BaseMiddleware):
    """Auth handling middleware
    
    The session middleware requires the following environ entries:
    web.envionment.name
    web.environment.type
    web.database.connection
    web.database.cursor
    web.session.manager
    """
    def __init__(self, application, setupEnvironment=False, expire=0, idle=0):
        
        self.application = application
        self.newHeaders = []
        self.setupEnvironment = setupEnvironment
        self.expire = expire
        self.idle = idle
        
#~ session[, storage='database'][, cursor=None][, expire=0][, idle=0][, signInForm=None][, autoSignIn=False][, autoRedirect=False][, redirect=None][, includeQuery=False][, stickyData=][, reminderForm=None][, email=None][, app=None][, accessDenied=None][, emailMessage=None][, htmlPage=None][, encryption=None][, table='Auth'][, dir=None][, debug=False][, checkSignInAttempt=False])

    def environ(self, environ):
        import web, web.auth.handler.signIn, web.errors
        for key in [
            'web.cgi',
            'web.environment.driver',
            'web.database.connection',
            'web.database.cursor',
            'web.session.manager',
        ]:
            if not environ.has_key(key):
                raise web.errors.AuthError('Expected %s key in environ dictionary'%key)
        
        createdEnvironment = False
        if self.setupEnvironment:
            if not environ['web.environment.driver'].completeAuthEnvironment():
                environ['web.environment.driver'].removeAuthEnvironment(ignoreErrors=True)
                environ['web.environment.driver'].createAuthEnvironment()
                createdEnvironment = True

        import web.auth, web.auth.handler.signIn

        environ['web.auth.session'] = web.auth.session(
            store = environ['web.session.manager'].store('auth'),
            expire = self.expire,
            idle = self.idle,
        )

        driver = web.auth.driver(
            storage='database',
            cursor=environ['web.database.cursor'],
            environment=environ['web.environment.driver'].name,
        )
        environ['web.auth.manager'] = web.auth.manager(driver=driver)
        #~ if createdEnvironment:
            #~ environ['web.auth.manager'].addApplication('app')
            #~ environ['web.auth.manager'].addUser('test', '123')
            #~ environ['web.auth.manager'].addUser(
                #~ 'john',
                #~ 'bananas',
                #~ 'John',
                #~ 'Smith',
                #~ 'johnsmith@example.com'
                #~ )
            #~ environ['web.auth.manager'].setAccessLevel('john', 'app', 1)

        # Get the signedInUsername
        username = environ['web.auth.session'].username() 
        if username:
            if environ['web.auth.manager'].userExists(username):
                environ['web.auth.username'] = environ['REMOTE_USER'] = username# Get the username of the current logged in user
            else:
                environ['web.auth.session'].signOut()
        else:
            if environ.has_key('web.auth.username'):
                environ['web.auth.username'] = ''
            if environ.has_key('REMOTE_USER'):
                environ['REMOTE_USER'] = ''
        return environ
