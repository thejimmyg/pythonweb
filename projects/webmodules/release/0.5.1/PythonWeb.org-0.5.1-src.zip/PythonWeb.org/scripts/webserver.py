#!/usr/bin/env python

"""
PythonWeb.org Webserver
        
Visit http://localhost:8080/doc/html/ to see the webserver running.
"""

version = '0.5'

# Set up True and False
try:
    True
except NameError:
    True = (1==1)
    False = (1==0)

import sys; sys.path.append('../')
import web.util
import SocketServer
import BaseHTTPServer
if sys.version_info[:2] == (2,4) and sys.platform == 'win32':
    import web.compat.only2_4.CGIHTTPServer as CGIHTTPServer # XXX Bug in Python 2.4 win XP
else:
    import CGIHTTPServer
import os
import posixpath
import urllib


if __name__ == '__main__':
    from optparse import OptionParser, OptionGroup
    useage = "usage: %prog [options] database"
    parser = OptionParser(usage=useage, version="%%prog %s"%(version))
    parser.add_option("-c", "--cgi-directory", dest="cgi", default= '/doc/src/lib',
                      action="store", metavar="CGI_DIR", 
                      help="the directory relative to BASE_DIR where the executable files are to be found"),
    parser.add_option("-l", "--launch",
                      action="store_true", dest="launch", default=False,
                      help="launch a web browser when started",
                      )
    parser.add_option("-p", "--port",
                      action="store", dest="port", default=8080,
                      help="port on which to start the server", type="int",
                      )
    parser.add_option("-b", "--base", dest="base", default= '../',
                      metavar="BASE_DIR", help="the root of the server"),
    (options, args) = parser.parse_args()


    class WebRequestHandler(CGIHTTPServer.CGIHTTPRequestHandler):
        
        cgi_directories = [options.cgi]
        
        def translate_path(self, path):
            """Translate a /-separated PATH to the local filename syntax.
    
            Components that mean special things to the local file system
            (e.g. drive or directory names) are ignored.  (XXX They should
            probably be diagnosed.)
    
            """
            path = posixpath.normpath(urllib.unquote(path))
            words = path.split('/')
            words = filter(None, words)
            path = options.base
            for word in words:
                drive, word = os.path.splitdrive(word)
                head, word = os.path.split(word)
                if word in (os.curdir, os.pardir): continue
                path = os.path.join(path, word)
            return path
        
    class ThreadingCGIServer(SocketServer.ThreadingMixIn,
                       BaseHTTPServer.HTTPServer):
        pass
        # XXX Note we cannot over-ride error handling since CGIHTTPServer.CGIHTTPRequestHandler simply prints output from the script. Python bug?

    print __doc__
    server_address = ('', options.port)
    server = ThreadingCGIServer(server_address, WebRequestHandler)
    if options.launch:
        import webbrowser
        webbrowser.open('http://localhost:%s/'%options.port, 1, 1)
    try:
        while 1:
            sa = server.socket.getsockname()
            print "Serving HTTP on", sa[0], "port", sa[1], "..."
            sys.stdout.flush()
            server.handle_request()
    except KeyboardInterrupt:
        print "Finished"
    
    
    
