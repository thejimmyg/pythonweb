"""ODBC driver for the PDBC module"""

__author__ = "James Gardner <james@jimmyg.org>"
__copyright__ = "Copyright 2001-2004 James Gardner All Rights Reserved."



#~ class DateConverter(base.SQLFieldConverter):
    #~ def object(self, field):
        #~ "Converts an SQL string for the field into a Python object"
        #~ if field == None:
            #~ return None
        #~ else:
            #~ tup = datetime.isodate2tuple(str(field)[0:10])
            #~ return datetime.date(tup[0],tup[1],tup[2])
        
    #~ def sql(self, object):
        #~ "Converts a Python object into an SQL string for the field"
        #~ if object == None:
            #~ return None
        #~ else:
            #~ return "'"+str(object)+"'"

#~ class DateTimeConverter(base.SQLFieldConverter):
    #~ def object(self, field):
        #~ "Converts an SQL string for the field into a Python object"
        #~ if field == None:
            #~ return None
        #~ else:
            #~ #raise Exception(field.__class__.__name__)
            #~ tup = datetime.isodatetime2tuple(str(field)[:-3])
            #~ return datetime.datetime(tup[0],tup[1],tup[2],tup[3],tup[4],tup[5])
        
    #~ def sql(self, object):
        #~ "Converts a Python object into an SQL string for the field"
        #~ if object == None:
            #~ return None
        #~ else:
            #~ return "'"+str(object)+"'"
    
#~ class TimeConverter(base.SQLFieldConverter):
    #~ def object(self, field):
        #~ "Converts an SQL string for the field into a Python object"
        #~ if field == None:
            #~ return None
        #~ else:
            #~ tup = datetime.isotime2tuple(str(field)[11:19])
            #~ return datetime.time(tup[3],tup[4],tup[5])
        
    #~ def sql(self, object):
        #~ "Converts a Python object into an SQL string for the field"
        #~ if object == None:
            #~ return None
        #~ else:
            #~ return "'"+str(object)+"'"
            
import base, mysql, database, datetime, SnakeSQL, SQLParserTools

converters = {
        'String':   base.BaseStringConverter(),
        'Text':     base.BaseTextConverter(),
        'Binary':   base.BaseBinaryConverter(),
        'Bool':     mysql.MySQLBoolConverter(),
        'Integer':  base.BaseIntegerConverter(),
        'Long':     base.BaseLongConverter(),
        'Float':    base.BaseFloatConverter(),
        'Date':     base.BaseDateConverter(),
        'Datetime': base.BaseDatetimeConverter(), # Decision already made.
        'Time':     base.BaseTimeConverter(),
}

class Connection(base.Connection):
    def makeConnection(self, **params):
        import os
        if os.name == 'nt' or os.name == 'dos':
            try:
                import mx.ODBC.Windows as odbc
            except:
                raise ImportError("The mx.ODBC module could not be imported. Is it installed? You may also need mx.BASE")
        elif os.name == 'posix':
            raise Exception('ODBC driver not tested for posix.')
            import mx.ODBC.iODBC as odbc
        else:
            raise Exception('ODBC driver not implemented for your platform')
        #return odbc.connect(**params)
        return odbc.connect(params['database'])

class Cursor(base.Cursor):

    def _setupTypes(self):
        return {
            'String':   'VARCHAR',
            'Text':     "MEMO",
            'Binary':   "MEMO",
            'Bool':     'INTEGER', # XXX
            'Integer':  "INTEGER",
            'Long':     'VARCHAR', # XXX
            'Float':    "FLOAT",
            'Date':     "DATE",
            'Datetime': "DATETIME", 
            'Time':     "TIME",
        }
        
    def _checkInsertConstraints(self, table, columns, internalValues):
        for col in self.connection.tables[table].columns:
            if col.required and not col.default and col.name not in columns:
                raise SnakeSQL.SQLError("The REQUIRED value '%s' has not been specified."%col.name)

    def _checkUpdateConstraints(self, table, columns, internalValues):
        for i in range(len(columns)):
            if self.connection.tables[table].get(columns[i]).primaryKey and internalValues[i] == 'NULL':
                raise SnakeSQL.SQLError("The PRIMARY KEY '%s' cannot be set to NULL"%col.name)

    def _buildColumns(self, columns):
        """Build column specifications for the CREATE statements
        
        Expects defaults to be properly quoted SQL Values"""
        sqlColumns = []
        for column in columns:
            if column['foreignKey'] != None:
                column['required'] = 1
            f = []
            f.append(column['name'])
            f.append(self.types[column['type'].capitalize()])

            if column['required']:
                f.append('NOT NULL')
            if column['default'] != None:
                default = self.connection.converters[column['type'].capitalize()].valueToSQL(self.connection.converters[column['type'].capitalize()].sqlToValue(column['default']))
                f.append('DEFAULT '+default)
            if column['primaryKey']:
                f.append('PRIMARY KEY')
            if column['unique']:
                f.append('UNIQUE')
            if column['foreignKey'] != None:
                f.append('FOREIGN KEY REFERENCES ('+column['foreignKey']+')')

            sqlColumns.append(' '.join(f))
        sql = ',\n '.join(sqlColumns)
        #print sql
        return sql
        
driver = {
    'converters':converters,
    'columnClass':base.BaseColumn,
    'tableClass':base.BaseTable,
    'cursorClass':Cursor,
}