"""Database driver for the auth module.

N.B. You cannot have a column named username as Gadfly thinks it is ambiguous hence the username column is
called user.
"""

#import authBase
from web.errors import AuthError

class DatabaseAuthEnvironmentDriver:

    def __init__(self, cursor, name):
        self.cursor = cursor
        self.name = name

    #
    # Environment Methods
    #
    
    def createAuthEnvironment(self):
        errors = []
        if not self.cursor.tableExists(self.name+'AuthUser'):
            self.cursor.create(
                table=self.name+'AuthUser',
                columns=[    
                    ('user', 'String' ),
                    ('password', 'String' ),
                    ('firstname','String' ),
                    ('surname',  'String' ),
                    ('email',    'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthUser'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthLevel'):
            self.cursor.create(
                table=self.name+'AuthLevel',
                columns=[  
                    ('user',     'String'),
                    ('app',      'String' ),
                    ('accessLevel',    'Integer'),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthLevel'+"' table already exists.")
        if not self.cursor.tableExists(self.name+'AuthApp'):
            self.cursor.create(
                table=self.name+'AuthApp',
                columns=[  
                    ('name',     'String' ),
                ]
            )
        else:
            errors.append("The '"+self.name+'AuthApp'+"' table already exists.")
        if errors:
            raise AuthError(', '.join(errors))

    def removeAuthEnvironment(self, ignoreErrors=True):
        errors = []
        try:
            self.cursor.drop(self.name+'AuthUser')
        except:
            if not ignoreErrors:
                errors.append("The "+self.name+'AuthUser'+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
        else:
            pass
        try:
            self.cursor.drop(self.name+'AuthLevel')
        except:
            if not ignoreErrors:
                errors.append("The "+self.name+'AuthLevel'+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
        else:
            pass
        try:
            self.cursor.drop(self.name+'AuthApp')
        except:
            if not ignoreErrors:
                errors.append("The "+self.name+'AuthApp'+" table may not exist. Error: %s"%str(sys.exc_info()[1]))
        else:
            pass
        if errors:
            raise AuthError(', '.join(errors))
        
    def completeAuthEnvironment(self):
        if self.cursor.tableExists(self.name+'AuthUser') and self.cursor.tableExists(self.name+'AuthLevel') and self.cursor.tableExists(self.name+'AuthApp'):
            return True
        else:
            return False
        
class DatabaseAuthDriver(DatabaseAuthEnvironmentDriver):

    def applicationExists(self, app):
        """Test to see if the application named 'app' exists. N.B. This function doesn't test whether the data is valid or whether the level info is availabel, just whether the file exists.""" 
        rows = self.cursor.select(
            'name',
            '%sAuthApp'%self.name, 
            where="name='"+app+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return True
        else:
            return False
            
    def addApplication(self, app):
        """Add an application named 'app' unless it already exists in which case raise an AuthError."""
        if self.applicationExists(app):
            raise AuthError("The '%s' application already exists."%app)
        else:
            self.cursor.insert('%sAuthApp'%self.name, ['name'], [app])
            
    def removeApplicaiton(self, app):
        """Remove an application named 'app' unless it doesn't exist in which case raise an AuthError."""
        if not self.applicationExists(app):
            raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            self.cursor.delete('%sAuthLevel'%self.name,where="app='"+app+"'")
            self.cursor.delete('%sAuthApp'%self.name,where="name='"+app+"'")


    def setAccessLevel(self, username, app, level):
        """Set the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        username = username.lower()
        if self.userExists(username):
            if self.applicationExists(app):
                rows = self.cursor.select(
                    'accessLevel',
                    '%sAuthLevel'%self.name,
                    where="user='"+username+"' and app='"+app+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                if rows:
                    self.cursor.update('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)), where="user='"+username+"' and app='"+app+"'")
                else:
                    self.cursor.insert('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)))
                return True
            else:
                raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            raise AuthError("The user '%s' doesn't exist."%username)

    def getAccessLevels(self, username):
        """Return a dictioanry containing the access level of the user with username 'username' for every application the user has been granted access to. Raise an AuthError if there is no user called 'username'."""
        username = username.lower()
        if self.userExists(username):
            rows = self.cursor.select(
                ('app','accessLevel'),
                '%sAuthLevel'%self.name,where="user='"+username+"'", 
                fetch=True,
                format='tuple',
                convert=True,
            )
            #raise Exception(rows)
            d = {}
            for row in rows:
                d[row[0]] = row[1]
            return d
        else:
            raise AuthError('That username doesn\'t exist.')
            
    def userExists(self, username):
        """Test to see if the user with the username 'username' exists.""" 
        username = username.lower()
        rows = self.cursor.select(
            'user',
            '%sAuthUser'%self.name, 
            where="user='"+username+"'", 
            fetch=True,
            format='tuple',
            convert=True,
        )

        if rows:
            return True
        return False
        
    def addUser(self, username, password, firstname='', surname='', email=''):
        """Add a user with the username 'username' and the password 'password' unless the username already exists in which case raise an AuthError
        Can optionally specify a firstname, surname and email for the user."""
        username = username.lower()
        if self.userExists(username):
            raise AuthError('That user already exists.')
        else:
            self.cursor.insert('%sAuthUser'%self.name,('user', 'password', 'firstname', 'surname', 'email'),(username,password,firstname,surname,email))

    def removeUser(self, username):
        """Remove a user with the username 'username' unless the username doesn't exist in which case raise an AuthError."""
        username = username.lower()
        if self.userExists(username):
            self.cursor.delete('%sAuthUser'%self.name,where="user='"+username+"'")
            self.cursor.delete('%sAuthLevel'%self.name,where="user='"+username+"'")
        else:
            raise AuthError("The user '%s' doesn't exist."%(username))

    def setAccessLevel(self, username, app, level):
        """Set the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        username = username.lower()
        if self.userExists(username):
            if self.applicationExists(app):
                rows = self.cursor.select(
                    'accessLevel',
                    '%sAuthLevel'%self.name,where="user='"+username+"' and app='"+app+"'", 
                    fetch=True,
                    format='tuple',
                    convert=True,
                )
                if rows:
                    self.cursor.update('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)), where="user='"+username+"' and app='"+app+"'")
                else:
                    self.cursor.insert('%sAuthLevel'%self.name, ('user','app','accessLevel'), (username,app,int(level)))
                return True
            else:
                raise AuthError("The '%s' application doesn't exist in the database."%app)
        else:
            raise AuthError("The user '%s' doesn't exist."%username)

    def getAccessLevel(self, username, app):
        """Return the access level of the user with username 'username' for the application named 'app'. Raise an AuthError if there is no user called 'username' or application named 'app'."""
        username = username.lower()
        levels = self.getAccessLevels(username)
        if levels.has_key(app):
            return levels[app]
        else:
            return None

    def getAccessLevels(self, username):
        """Return a dictioanry containing the access level of the user with username 'username' for every application the user has been granted access to. Raise an AuthError if there is no user called 'username'."""
        username = username.lower()
        if self.userExists(username):
            rows = self.cursor.select(
                ('app','accessLevel'),
                '%sAuthLevel'%self.name,where="user='"+username+"'", 
                fetch=True,
                format='tuple',
                convert=True,
            )
            #raise Exception(rows)
            d = {}
            for row in rows:
                d[row[0]] = row[1]
            return d
        else:
            raise AuthError('That username doesn\'t exist.')

    def _setProperty(self, property, username, value):
        """Private method to set the value of one of 'password', 'firstname', 'surname' and 'email' for a particular user."""
        username = username.lower()
        if property in ['password','firstname','surname','email']:
            if self.userExists(username):
                self.cursor.update('%sAuthUser'%self.name, (property,), (value,), where="%s='%s'"%(property,value))
            else:
                raise AuthError('That user doesn\'t exist.')
        else:
            raise AuthError("You can only set the properties 'password', 'firstname', 'surname' and 'email'")
            
    def setFirstname(self, username, value):
        """Sets the firstname of the user 'username' to 'value'."""
        return self._setProperty('firstname', username, value)
        
    def setSurname(self, username, value):
        """Sets the surname of the user 'username' to 'value'."""
        return self._setProperty('surname', username, value)

    def setEmail(self, username, value):
        """Sets the email address of the user 'username' to 'value'."""
        return self._setProperty('email', username, value)
            
    def setPassword(self, username, value):
        """Sets the password of the user 'username' to 'value'."""
        return self._setProperty('password', username, value)
        
    def users(self):
        """Return a list of current usernames."""
        rows = self.cursor.select(
            'user', 
            '%sAuthUser'%self.name, 
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return rows[0]
        else:
            return []
            
    def apps(self):
        """Return a list of current applications."""
        rows = self.cursor.select(
            'name', 
            '%sAuthApp'%self.name,
            fetch=True,
            format='tuple',
            convert=True,
        )
        if rows:
            return rows[0]
        else:
            return []
            
    def getUser(self, username, property=None):
        """Returns a data structure containing useful infomation about the user.
        eg. 
            user = getUser('testuser', 'testapp')
            
            # The variables below all return values the value as expected
            user.username, user.email, user.password, user.firstname, user.surname
            
            user.app # contains a structure of apps which testuser has access to
            user.app.testapp.level # returns testuser's access level to 'testapp'.
            
            user.apps() # returns a list of app names. (Similar to the auth.apps() function)"""
        username = username.lower()
        if self.userExists(username):
            # Read the user level
            
            "Useful objects used by the auth module."
            
            class DictWrapper:
                "Dict for cgi variables."
                def __init__(self, dict):
                    self.__dict = dict
                def __getattr__(self, name):
                    if self.__dict.has_key(name):
                        return self.__dict[name]
                    elif name in dir(self.__dict):
                        return getattr(self.__dict, name)
                    else:
                        raise AttributeError("%s object has no attribute '%s'"%(self.__class__.__name__,name))
                def __getitem__(self, name):
                    if self.__dict.has_key(name):
                        return self.__dict[name]
                    else:
                        raise AttributeError("%s object has no attribute '%s'"%(self.__class__.__name__,name))
                def __setitem__(self, name, value):
                    raise Exception('You cannot assign values to a %s object.'%self.__class__.__name__)
                def __setitem__(self, name, value):
                    raise Exception('You cannot assign values to a %s object.'%self.__class__.__name__)
                def __str__(self):
                    stri = ''
                    for k, v in self.__dict.items():
                        stri+=(' %s=%s,'%(k,repr(v)))
                    return stri[:-1]
                def __repr__(self):
                    return '<%s %s>'%(self.__class__.__name__, self.__str__())
            
            class App(DictWrapper):
                pass
            class Apps(DictWrapper):
                pass
            class User(DictWrapper):
                def apps(self):
                    return self.__dict['app'].__dict.keys()

                #~ def changePassword(self, NewPassword):
                    #~ self.cursor.update(
                      #~ '%sUser' % (self.table),
                      #~ 'password',
                      #~ NewPassword,
                      #~ where = 'id = %s ' % self.__dict__['id'],
                    #~ )
                    
            rows = self.cursor.select(
                ('user','password','firstname','surname','email'), 
                '%sAuthUser'%self.name, 
                where="user='%s'"%username, 
                fetch=True,
                format='dict',
                convert=True,
            )
            object = rows[0]
            user = User(
                {
                    'username':object['user'],
                    'password':object['password'],
                    'firstname':object['firstname'],
                    'surname':object['surname'],
                    'email':object['email'],
                    'level':self.getAccessLevels(username),
                }
            )
            if not property:
                return user
            elif user.has_key(property):
                return user[property]
            else:
                raise AuthError("No such property '%s'."%property)
        else:
            raise AuthError("No such username '%s'."%username)

    def getFirstname(self, username):
        """Returns the firstname of the user 'username'."""
        return self.getUser(username, property='firstname')
        
    def getSurname(self, username):
        """Returns the surname of the user 'username'."""
        return self.getUser(username, property='surname')
        
    def getEmail(self, username):
        """Returns the email address of the user 'username'."""
        return self.getUser(username, property='email')

    def getPassword(self, username):
        """Returns the password of the user 'username'."""
        return self.getUser(username, property='password')
        
