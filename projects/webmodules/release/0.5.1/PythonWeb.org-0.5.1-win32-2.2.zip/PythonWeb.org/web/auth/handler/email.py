import web.form

class SignInHandler:

    def __init__(self, session, manager, cgi=None, redirect=None, modeName='mode', action=None, stickyData={}, email=True):
        self.session = session
        self.manager = manager
        self.modeName = modeName
        self.action = action
        self.email = email
        self.stickyData = stickyData
        self.messages = {
            # Errors
            'ALREADY_SIGNED_IN'     : 'You are already signed in. If you want to sign in again you should <a href="%s">sign out</a> first.'%('?%s=signOut'%(self.modeName)),
            'NOT_SIGNED_IN_YET'     : '', # No status message needs displaying
            'NO_USER_ENTERED'       : 'Please enter a username.',
            'NO_EMAIL_ENTERED'      : 'Please enter your email address.',
            'NO_USER'               : 'The username you have specified does not exist.',
            'NO_PASSWORD_ENTERED'   : 'No password entered.',
            'INVALID_PASSWORD'      : 'The password is incorrect.',
            # Statements:
            'SIGNED_OUT'            : 'You have been sucessfully signed out.',
            'EMAIL_DISABLED'        : 'Email mode is not enabled.',
            'SIGNED_IN'             : '', # No status message is returned anyway
        }
        if cgi == None:
            self.cgi = web.cgi
        else:
            self.cgi = cgi
        self.redirect = redirect
        # Setup the form
        stickyData[self.modeName] = 'signIn'
        stickyData['redirect'] = redirect
        self.form = web.form.Form(method='get', stickyData=stickyData, action=self.action)
        self.form.add(field='String', name='username', size=18, required=1, requiredError=self.messages['NO_USER_ENTERED'])
        self.form.add(field='Password', name='password', size=18, required=1, requiredError=self.messages['NO_PASSWORD_ENTERED'])
        self.form.add(action='Sign In')
        
        stickyData[self.modeName] = 'email'
        self.emailForm = web.form.Form(method='get', stickyData=self.stickyData, action=self.action)
        self.emailForm.add(field='String', name='username', size=18, required=1, requiredError=self.messages['NO_USER_ENTERED'])
        self.emailForm.add(field='Email', name='email', required=1, requiredError=self.messages['NO_EMAIL_ENTERED'])
        self.emailForm.add(action='Send Reminder')
        
        
    def handle(self):
        username = self.session.username() # Get the username of the current logged in user
        if username:
            self.status = 'ALREADY_SIGNED_IN'
            return self.messages[self.status]
        elif not self.cgi.has_key(self.modeName) or self.cgi[self.modeName].value not in ['signIn','signOut','email']:
            self.status = 'NOT_SIGNED_IN_YET'
            return self.form.html()
        else:
            if self.cgi[self.modeName].value == 'signOut':
                self.session.signOut(username)
                self.status = 'SIGNED_OUT'
                return self.messages[self.status]
            elif self.cgi[self.modeName].value == 'email':
                if not self.email:
                    self.status = 'EMAIL_DISABLED'
                    return self.messages[self.status]
                else:
                    self.emailForm.populate(self.cgi)
                    if not self.emailForm.valid():
                        return self.form.html()
                    elif not self.manager.userExists(self.emailForm['username'].value):
                        self.status = 'NO_USER'
                        self.emailForm['username'].setError(self.messages[self.status])
                        return self.form.html()
                    elif self.manager.getEmail(self.emailForm['username'].value).lower() == self.emailForm['email'].value.lower():
                        
            
            
            
            
            
            
            
            
            if self.emailOptions and web.cgi.has_key('mode') and web.cgi.has_key('username') and web.cgi['mode'].value == 'reminder':
            if web.cgi.has_key('email'):
                email = web.cgi['email'].value
                if email == self.getEmail(web.cgi['username'].value):
                    
                    firstname = self.getFirstname(web.cgi['username'].value)
                    if not firstname:
                        firstname = 'user'
                    
                    dict = {
                            'firstname' :   firstname,
                            'system'    :   self.emailOptions['system'], 
                            'password'  :   self.getPassword(web.cgi['username'].value),
                            'sender'    :   self.emailOptions['sender'],
                        }
                    msg = web.template.parse(type=self.emailOptions['type'], dict=dict, template=self.emailOptions['template'])
                    
                        
                    if self.emailOptions['method'] == 'sendmail':
                        web.mail.send(msg=msg, to=email, subject='Password Reminder', method='sendmail', sendmail=self.emailOptions['sendmail'], reply=self.emailOptions['reply'], sender=self.emailOptions['sender'])
                    elif self.emailOptions['method'] == 'smtp':
                        web.mail.send(msg=msg, to=email, subject='Password Reminder', method='smtp', smtp=self.emailOptions['smtp'],         reply=self.emailOptions['reply'], sender=self.emailOptions['sender'])
                    
                    self.error = 'PASS_REMINDER_SENT'
                    self._printPage(
                        self.signInForm(
                            username=web.cgi['username'].value,
                            error='PASS_REMINDER_SENT'
                        ),
                        self.errorCodes['PASS_REMINDER_SENT'][0]
                    )
                else:
                    self.error = 'EMAIL_NOT_FOUND'
                    self._printPage(
                        self.reminderForm(
                            stickyData={
                                'username':web.cgi['username'].value,
                                'mode':'reminder'
                            },
                            error='EMAIL_NOT_FOUND'
                        ),
                        self.errorCodes['EMAIL_NOT_FOUND'][0]
                    )
            else:
                self._printPage(
                    self.getReminderForm(
                        stickyData={
                            'username':web.cgi['username'].value,
                            'mode':'reminder'
                        }
                    ),
                    self.errorCodes['REMINDER'][0]
                )
            
            
            
            
            
            
            
            else:
                self.form.populate(self.cgi)
                validates = 1
                if not self.form.valid():
                    return self.form.html()
                elif not self.manager.userExists(self.form['username'].value):
                    self.status = 'NO_USER'
                    self.form['username'].setError(self.messages[self.status])
                    return self.form.html()
                elif self.manager.getUser(self.form['username'].value).password <> self.form['password'].value:
                    self.status = 'INVALID_PASSWORD'
                    self.form['password'].setError(self.messages[self.status])
                    return self.form.html()
                else:
                    self.session.signIn(self.cgi['username'].value)
                    if self.redirect: # Redirect to correct place!
                        status = 'SIGNED_IN'
                        self.setHeader("Location",self.redirect)
                        return None
                    else:
                        status = 'SIGNED_IN'
                        return None
        
    def setHeader(self, header, value):
        print "%s: %s\n\n"%(header,value)
