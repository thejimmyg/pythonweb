"Useful objects used by the auth module."

class DictWrapper:
    "Dict for cgi variables."
    def __init__(self, dict):
        self.__dict = dict
    def __getattr__(self, name):
        if self.__dict.has_key(name):
            return self.__dict[name]
        elif name in dir(self.__dict):
            return getattr(self.__dict, name)
        else:
            raise AttributeError("%s object has no attribute '%s'"%(self.__class__.__name__,name))
    def __getitem__(self, name):
        if self.__dict.has_key(name):
            return self.__dict[name]
        else:
            raise AttributeError("%s object has no attribute '%s'"%(self.__class__.__name__,name))
    def __setitem__(self, name, value):
        raise Exception('You cannot assign values to a %s object.'%self.__class__.__name__)
    def __setitem__(self, name, value):
        raise Exception('You cannot assign values to a %s object.'%self.__class__.__name__)
    def __str__(self):
        stri = ''
        for k, v in self.__dict.items():
            stri+=(' %s=%s,'%(k,repr(v)))
        return stri[:-1]
    def __repr__(self):
        return '<%s %s>'%(self.__class__.__name__, self.__str__())

class App(DictWrapper):
    pass
class Apps(DictWrapper):
    pass
class User(DictWrapper):
    def apps(self):
        return self.__dict['app'].__dict.keys()

            