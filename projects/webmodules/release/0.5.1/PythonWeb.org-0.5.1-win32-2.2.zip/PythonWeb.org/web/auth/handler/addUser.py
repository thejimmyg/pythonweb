import web.form, web.form.field.typed, web.form.field.basic, web.form.field.extra

class AddUserHandler:
    
    def __init__(self, userManager, modeName='mode'):
        self.userManager = userManager#web.auth.UserManager()
        self.modeName = modeName
        self.error = None
        self.messages = {
            # Errors
            'ALREADY_SIGNED_IN'     : 'Already signed in. If you want to sign in again you should sign out first.',
            'NOT_SIGNED_IN_YET'     : '', # No status message needs displaying
            'NO_USER_ENTERED'       : 'Please enter a username.',
            'NO_USER'               : 'The username you have specified does not exist.',
            'NO_PASSWORD_ENTERED'   : 'No password entered.',
            'INVALID_PASSWORD'      : 'The password is incorrect.',
            # Statements:
            'SIGNED_OUT'            : 'You have been sucessfully signed out.',
            'SIGNED_IN'             : '', # No status message is returned anyway
        }
        self.cgi = web.cgi
        
    def handle(self):
        # Get the signedInUsername
        if self.cgi.has_key(self.modeName) and self.cgi[self.modeName].value == 'add':
            form = self.addUserForm()
            form.populate(self.cgi)
            if form.valid():
                if self.userManager.userExists(form['username'].value):
                    form['username'].error = 'User already exists'
                else:
                    # Add User
                    self.userManager.addUser(
                        form['username'].value,
                        form['password'].value,
                        form['firstname'].value,
                        form['surname'].value,
                        form['email'].value,
                    )
                    return None
            return form.html()
        else:
            form = self.addUserForm()
            return form.html()
        
    def addUserForm(self):#, error='', redirect='', username='', method='get'):
        
        form = web.form.Form(stickyData={self.modeName:'add'})
        fields = [
            web.form.field.typed.String(name="username", required=1),
            web.form.field.basic.Password(name="password", required=1),
            web.form.field.typed.String(name="firstname"),
            web.form.field.typed.String(name="surname"),
            web.form.field.extra.Email(name="email"),
        ]
        form.addFields(fields)
        form.addAction('Add User')
        return form
        
        #~ return """
        #~ <form name="signIn" method="%(method)s" action="">
        #~ <table border="0">
        #~ <tr>
          #~ <td>Username: </td><td><input type="text" name="username" value="%(username)s" /></td>
        #~ </tr>
        #~ <tr>
          #~ <td>Password: </td><td><input type="password" name="password" /></td>
        #~ </tr>
        #~ <tr>
          #~ <td colspan="2">
            #~ <input type="hidden" name="%(modeName)s" value="signIn" />
            #~ <input type="hidden" name="redirect" value="%(redirect)s" />
            #~ <input type="submit" name="submit" value="Sign In" />
          #~ </td>
        #~ </tr>
        #~ </table>
        #~ </form>
        #~ <p>%(error)s</p>
        #~ """%{'error':error, 'redirect':redirect, 'username':username, 'modeName':self.modeName, 'method':method}
            
