"""Tools for preparing an environment for the web modules"""

from web.errors import EnvironmentError, SessionError, AuthError

def driver(name='', storage='database', **params):
    if storage not in ['database']:
        raise web.errors.EnvironmentError("%s is not a valid environment type."%(repr(storage)))
        
    from web.session.drivers.database import DatabaseSessionEnvironmentDriver
    from web.auth.drivers.database    import DatabaseAuthEnvironmentDriver
    
    class Environment(DatabaseSessionEnvironmentDriver, DatabaseAuthEnvironmentDriver):

        def createEnvironment(self):
            errors = ''
            try:
                self.createSessionEnvironment()
            except SessionError, e:
                errors += ', '+str(e)
            try:
                self.createAuthEnvironment()
            except AuthError, e:
                errors += ', '+str(e)
            if errors:
                raise EnvironmentError(errors)
            
        def removeEnvironment(self, ignoreErrors=True):
            errors = ''
            try:
                self.removeSessionEnvironment(ignoreErrors)
            except SessionError, e:
                errors += ', '+str(e)
            try:
                self.removeAuthEnvironment(ignoreErrors)
            except AuthError, e:
                errors += ', '+str(e)
            if errors:
                raise EnvironmentError(errors)
            
        def completeEnvironment(self):
            if not self.completeAuthEnvironment() or not self.completeSessionEnvironment():
                return 0
            else:
                return 1

        
    return Environment(name=name, **params)