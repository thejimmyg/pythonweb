"""HTML template classes.

TODO: Add PSP
"""



class TemplateError(Exception):
    """Error Class for the html.template Module. Use as follows:

    try:
        raise TemplateError(ERROR_PASSWORD)
    except SessionError, e:
        print 'Template exception occurred, value:', e.value
    """
    
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return self.value

def parse(type, dict={}, file=None, template=None, useCompiled=False, swapTemplatePaths=None):
    """Simple wrapper method to load and parse a template from the options given.
    
    type        - The type of template eg. xyaptu
    file        - The path to the template.
    template    - The template txt to use.
    dict        - The dictionary containg the variables to be replaced.
    swapTemplatePaths - (old, new) tuple specifying the paths to swap."""
    
    #if dict == None:
    #    raise TemplateError('You must specify a dictionary to populate the template.')
    if file and template:
        raise TemplateError('You cannot specify both a file to use as a template and template text to use as a template.')
    if file == None and template == None:
        raise TemplateError("You must specify either 'file' or 'template'")
        
    if type.lower() == 'xyaptu':
        if file:
            fp = open(file)
            template = fp.read()
            fp.close()
        import xyaptu
        import cStringIO
        file = cStringIO.StringIO(template)
        out = cStringIO.StringIO()
        xcp = xyaptu.xcopier(dict, ouf=out)
        xcp.xcopy(file)
        txt = out.getvalue()
        out.close()
        return txt
        # XXX Maybe include support for error checking.
        
    if type.lower() == 'cheetah':
        if template <> None:
            from Cheetah.Template import Template
            t = Template(str(template), searchList=[dict])
            return str(t)
        elif useCompiled == False:
            fp = open(file)
            template = fp.read()
            fp.close()
            from Cheetah.Template import Template
            t = Template(template, searchList=[dict])
            return str(t)
        else:
            import os.path, sys
            if useCompiled == 'auto':
                import os
                if not os.path.exists(file[:-5]+'.py') or os.stat(file).st_mtime > os.stat(file[:-5]+'.py').st_mtime:
                    from Cheetah.CheetahWrapper import CheetahWrapper
                    import cStringIO
                    stdout = sys.stdout # Hide stdout.. quite verbose.
                    sys.stdout = cStringIO.StringIO() 
                    CheetahWrapper().main(['cheetah-compile', 'compile', file]) 
                    sys.stdout = stdout
            head, tail = os.path.split(file) 
            import imp
            fp, pathname, description = imp.find_module(tail[:-5], [head])
            try:
                a = imp.load_module(tail[:-5], fp, pathname, description)
            finally: # Since we may exit via an exception, close fp explicitly.
                if fp:
                    fp.close()
            return str(a.__dict__[tail[:-5]](searchList=[dict]))

    elif type.lower() == 'dreamweavermx': # XXX Experimental Support
        
        if file:
            fp = open(file)
            template = fp.read()
            fp.close()
        
        import dreamweaverMX
        page = dreamweaverMX.Template(template=template)
        for key, value in dict.items():
            page.set(key, value)
        if swapTemplatePaths:
            page.swapTemplatePaths(swapTemplatePaths[0], swapTemplatePaths[1])
            
        
        return page.output()
        
    elif type.lower() == 'python':
        if file:
            fp = open(file)
            template = fp.read()
            fp.close()
        return str(template % dict)
    else:
        raise TemplateError("The type parameter can only be 'xyaptu', 'cheetah', 'python' or 'dreamweaverMX', not %s"%type)