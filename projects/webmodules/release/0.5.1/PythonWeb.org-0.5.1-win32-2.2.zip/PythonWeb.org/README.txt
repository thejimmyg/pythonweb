

     ======================================================================
                             PYTHON WEB MODULES   
     ======================================================================

                          http://www.pythonweb.org
                    Copyright (C) 2002-2005 James Gardner
                         email: mail@pythonweb.org


 Installation
 ============

 To install the modules:

    > python setup.py install

 Other ways to use the modules are discussed in the Getting Started Guide
 section of the documentation.


 Documentation
 =============

 Full documentation including a getting started guide and module reference
 can be found in the doc directory. 

 The documentation is also available in alternative formats from the website.


 Licence
 =======

 The web modules are thought likely to be LGPL compatible. 
 See the licence section of the documentation for licence information
 on all the constituent parts.


 Directory Structure
 ===================

  + doc           Full documentation for the modules
  + scripts       Useful scripts
  + web           The modules themselves
    + external      Software written by 3rd parties