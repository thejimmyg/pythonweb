"""SnakeSQL Interactive Interpreter - James Gardner"""

import sys, os.path
sys.path.append('../')
import SnakeSQL
sys.path.append(SnakeSQL.__name__+'/external')
sys.path.append(SnakeSQL.__name__)
import code, traceback, time
from tablePrint import table

__version__ = SnakeSQL.__version__

def prompt(database, driver, header='Interactive Prompt', create=False):

    class SQLConsole(code.InteractiveConsole):
        "SnakeSQL Interactive Interpreter Class"
        def __init__(self, locals=None):
            code.InteractiveConsole.__init__(self, locals, "SnakeSQL Console")

        def push(self, line):
            "If the line is a keyword, handle it. Otherwise send the line to the database as SQL."
            if line == 'help':
                print "No help yet available."
            elif line == 'copyright':
                print "Copyright James Gardner 2004, All rights reserved. http://www.jimmyg.org"
            elif line == 'license':
                print "Released under the GNU GPL available to read at http://gnu.org"
            elif line == 'exit':
                sys.exit(0)
            else:
                while line and line[1:] == ' ':
                    line = line[1:]
                while line and line[-1:] == ' ':
                    line = line[:-1]
                if not line:
                    pass
                else:
                    line = "execute("+repr(line)+',database)'
                    return code.InteractiveConsole.push(self, line)
            
        def showtraceback(self):
            "Over-ride default traceback handling."

            if sys.exc_info()[0].__name__ in [
                'SQLError', 
                'SQLSyntaxError',
                'SQLKeyError',
            ]:
                print '\a'+sys.exc_info()[0].__name__[3:]+': '+str(sys.exc_info()[1])
            else:
                code.InteractiveConsole.showtraceback(self)
                print "\aBUG: The error described above was not expected and should be considered a bug."

    # Check the database exists before we hide exceptions.
    try:
        connection = SnakeSQL.connect(database, driver, autoCreate = create)
    except SnakeSQL.DatabaseError,e:
        print "ERROR: %s Use '-c' to create a database.\n"%e
        print "For instructions use:\npython snake.py ? "
        sys.exit(1)
    else:
        connection.close()
    
    def execute(sql, database):
        """Connect to the database, execute the SQL, return the result then close the connection
        so other users can access it."""
        
        connection = SnakeSQL.connect(database, driver=driver, autoCreate=create)
        cursor = connection.cursor()
        start = time.time()
        cursor.execute(sql)
        results = cursor.info['results']
        end = time.time()
        t = "%0.2f"%(end-start)
        if results <> None:
            print table(cursor.info['columns'], cursor.fetchall(), mode='sql')
            if cursor.info['affectedRows'] == 1:
                print str(cursor.info['affectedRows'])+' row in set (%s sec)\n'%t
            else:
                print str(cursor.info['affectedRows'])+' rows in set (%s sec)\n'%t
        else:
            if cursor.info['affectedRows'] == 1:
                print 'Query OK, '+str(cursor.info['affectedRows'])+' row affected (%s sec)\n'%t
            else:
                print 'Query OK, '+str(cursor.info['affectedRows'])+' rows affected (%s sec)\n'%t
        connection.commit()
        connection.close()

    # Prepare the locals that the interpreter will need
    locals = {
        'execute':execute,
        'database':database,
    }
    c = SQLConsole(locals)
    c.interact(header)

def main():
    from optparse import OptionParser, OptionGroup
    useage = "usage: %prog [options] database"
    parser = OptionParser(usage=useage, version="%%prog %s.%s"%(__version__[0],__version__[1]))
    parser.add_option("-c", "--create",
                      action="store_true", dest="create", default=False,
                      help="create a database if it doesn't already exist")
    parser.add_option("-d", "--driver",
                      action="store", dest="driver", default='dbm',
                      help="storage mechanism can be dbm [defualt] or csv",
                      type="string")
    #~ parser.add_option("-v", "--verbose",
                      #~ action="store_true", dest="verbose", default=True,
                      #~ help="make lots of noise [default]")
    #~ parser.add_option("-q", "--quiet",
                      #~ action="store_false", dest="verbose", 
                      #~ help="be vewwy quiet (I'm hunting wabbits)")
    #~ parser.add_option("-f", "--file", dest="filename",
                      #~ metavar="FILE", help="write output to FILE"),
    #~ parser.add_option("-m", "--mode",
                      #~ default="intermediate",
                      #~ help="interaction mode: one of 'novice', "
                           #~ "'intermediate' [default], 'expert'")
    #~ group = OptionGroup(parser, "Dangerous Options",
                        #~ "Caution: use these options at your own risk.  "
                        #~ "It is believed that some of them bite.")
    #~ group.add_option("-g", action="store_true", help="Group option.")
    #~ parser.add_option_group(group)
    (options, args) = parser.parse_args()
    if len(args) != 1:
        parser.error("incorrect number of arguments, expected just the database name after the options")
    if not options.create and not os.path.exists(args[0]):
        parser.error("database %s does not exist"%(repr(args[0])))
    else:
        prompt(args[0], options.driver, """SnakeSQL Interactive Prompt\nType SQL or "exit" to quit, "help", "copyright" or "license" for information.""", options.create)
        
if __name__ == '__main__':
    main()

