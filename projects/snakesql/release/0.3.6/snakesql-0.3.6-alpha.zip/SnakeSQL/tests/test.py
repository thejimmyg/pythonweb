"# XXX Connection also neeeds ignoreSQLReservedWords, ignoreDtupleReservedWords, compatibilitySQL, updateWhereValues"

import sys; sys.path.append('../')
import SnakeSQL, datetime

connection = SnakeSQL.connect('test', driver='dbm', autoCreate=True)
cursor = connection.cursor()
cursor.create(
    table = 'test', 
    columns = [
        cursor.column(name='columnDate', type='Date'),
        cursor.column(name='keyString', type='String', key=True),
        cursor.column(name='columnString', type='String'),
        cursor.column(name='columnText', type='Text'),
        cursor.column(name='requiredText', type='Text', required=True),
        cursor.column(name='columnBool', type='Bool'),
        cursor.column(name='columnInteger', type='Integer'),
        cursor.column(name='uniqueInteger', type='Integer', unique=True),
        cursor.column(name='columnLong', type='Long'),
        cursor.column(name='columnFloat', type='Float'),
        cursor.column(name='columnDateTime', type='DateTime'),
        cursor.column(name='columnTime', type='Time'),
    ],
)

cursor.insert(
    table = 'test',
    columns = [
        'columnDate', 
        'keyString', 
        'columnString', 
        'columnText', 
        'requiredText', 
        'columnBool', 
        'columnInteger', 
        'uniqueInteger', 
        'columnLong', 
        'columnFloat',
        'columnDateTime', 
        'columnTime',
    ],
    values = [
        datetime.date(2004,12,12), 
        "str''ing1", 
        'string3', 
        'string4', 
        'string2', 
        False, 
        1, 
        2, 
        999999999999999999,
        1.2, 
        datetime.datetime(2004,12,12,12,12,12), 
        datetime.time(1,12,12),
    ]
)

try:
    cursor.insert(table='test', columns='keyString', values="str''ing2")
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

try:
    cursor.insert(table='test', columns='uniqueInteger', values=2)
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

try:
    cursor.insert(
        table='test', 
        columns=[
            'keyString',
            'uniqueInteger',
        ],
        values=[
            'string2', 
            2,
        ]
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

try:
    cursor.insert(
        table='test', 
        columns=[
            'keyString',
            'uniqueInteger',
        ],
        values=[
            'string2', 
            2,
        ]
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"
    
    
try:
    cursor.insert(
        table='test', 
        columns=[
            'keyString',
            'uniqueInteger',
            'requiredText',
        ],
        values=[
            'string2', 
            2,
            None,
        ]
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

try:
    cursor.insert(
        table='test', 
        columns=[
            'keyString',
            'uniqueInteger',
            'requiredText',
        ],
        values=['string2', 2, 'Text']
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"
    

cursor.insert(
    table='test', 
    columns=[
        'keyString',
        'uniqueInteger',
        'requiredText',
    ],
    values=['string2', 3, 'Text']
)

print cursor.select(
    table='test',
    columns='*',
)

try:
    cursor.update(
        table='test', 
        columns='uniqueInteger',
        values=2,
        where="keyString <> NULL", # XXX Not good.
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"
    
    
try:
    cursor.update(
        table='test', 
        columns='keyString',
        values="str''ing2",
        where="keyString <> NULL", # XXX Not good.
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

try:
    cursor.update(
        table='test', 
        columns='uniqueInteger',
        values=3,
        where="uniqueInteger == 2", # XXX Not good.
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"
    
cursor.update(
    table='test', 
    columns='requiredText',
    values='newtext',
    where="uniqueInteger = 2", # XXX Not good.
)

print cursor.select(
    table='test',
    columns = [
        'columnDate', 
        'keyString', 
        'columnDateTime', 
        'columnString', 
        'columnText', 
        'requiredText', 
        'columnBool', 
        'columnInteger', 
        'uniqueInteger', 
        'columnLong', 
        'columnFloat',
        'columnTime',
    ],
)

cursor.delete(
    table='test', 
    where="keyString='string2'", # XXX Not good.
)

print cursor.select(
    table='test',
    columns='*',
)

cursor.update(
    table = 'test',
    columns = [
        'columnDate', 
        'columnString', 
        'columnText', 
        'columnBool', 
        'columnInteger', 
        'columnLong', 
        'columnFloat',
        'columnDateTime', 
        'columnTime',
    ],
    values = [
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
        None,
    ]
)

print cursor.select(
    table='test',
    columns='*',
)

cursor.drop(
    table='test',
)

try:    
    print cursor.select(
        table='test',
        columns='*',
    )
except:
    print "Caught: ", sys.exc_info()[1]
else:
    print "FAILED to catch an error"

connection.commit()