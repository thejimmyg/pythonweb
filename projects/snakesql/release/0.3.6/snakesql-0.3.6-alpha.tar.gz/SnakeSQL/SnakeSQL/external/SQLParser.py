"""SQLParser class for parsing SQL Code into more useful forms.

All useful error checking that can be done at this stage is done. For example, checking that no duplicate column names are specified in an INSERT or CREATE.

Restrictions:
* VALUES in the insert statement are assumed to be right next to their ending , and the preceding one.. otherwise the whitespace is included in the value if it is unquoted.
* No newline characters should be used in the SQL except in quoted values.


TODO
check for multiple keys.

"""

# Check Bools are defined
try:
    True
except NameError:
    True = 1
    False = 0

# Imports
from error import *
from external.StringParsers import *
import string

# Definitions
allowedCharacters = string.letters+'_-0123456789'
class Param: # Used to represent ? in parameter substitution and yet still be distinguishable from '?'
    pass
    
# SQLParser
class SQLParser:
    "Returns the main SQL function and the terms, stripping whitespace as necessary."
    def parse(self, sql):
        stripped = stripBoth(sql.split(' '))
        function = stripped[0].lower()
        if function == 'select':
            return self.parseSelect(sql)
        elif function == 'delete':
            return self.parseDelete(sql)
        elif function == 'insert':
            return self.parseInsert(sql)
        elif function == 'update':
            return self.parseUpdate(sql) 
        elif function == 'create':
            return self.parseCreate(sql)
        elif function == 'drop':
            return self.parseDrop(sql)
        elif function == 'show':
            if stripped[1].lower() == 'tables':
                return {
                    'function':'show',
                    'item':'tables',
                }
            else:
                raise SQLSyntaxError("Expected 'TABLES' after SHOW.")
        else:
            raise SQLError("%s is not a supported keyword."%function.upper())

    def parseDrop(self, sql):
        sql, table = self._parseTable(sql, 'DROP', 'TABLE')
        if stripBoth(sql):
            raise SQLSyntaxError("Extra characters '%s' found after '%s' in DROP statement."%(stripBoth(sql),table))
        return {
            'function':'drop',
            'table':table,
        }

    def parseCreate(self, sql):
        #XXX check for multiple keys.
        sql, table = self._parseTable(sql, 'CREATE', 'TABLE')
        if sql[0] <> "(":
            raise SQLSyntaxError("Expected a '(' after the table name.")
        if sql[-1:] <>  ")":
            raise SQLSyntaxError("Expected a ')' at the end of the CREATE statement.")
        sql = sql[1:]
        pos = 0
        columns = []
        column = {'name':None,'type':None,'unique':False,'required':False,'key':False,'default': None,}
        term = ''
        part = 'name'
        position = 'one'
        while 1:
            if part in ['name', 'type']:
                if position=='one' and sql[pos] == ' ': # Whitespace at start
                    pos+=1
                elif position=='one' and sql[pos] in allowedCharacters: # start the name
                    position = 'middle'
                    term += sql[pos]
                    pos+=1
                elif position=='middle' and sql[pos] in allowedCharacters: # middle of name
                    position = 'middle'
                    term += sql[pos]
                    pos+=1
                elif position=='middle' and sql[pos] == ' ': # end of the name
                    column[part] = term
                    if part == 'name':
                        for c in columns:
                            if c['name'] == term:
                                raise SQLError("You cannot create a table with two columns of the same name, '%s'."%(term))
                        part='type'
                    else:
                        part='options'
                    position='one'
                    term = ''
                    pos+=1
                elif position=='middle' and sql[pos] in [',',')']:
                    if part == 'name':
                        raise SQLSyntaxError("No field type specified for column %s."%(len(columns)+1))
                    else:
                        column[part] = term
                        columns.append(column)
                        column = {
                            'name':None,'type':None,'unique':False,'required':False,'key':False,
                            'default': None,
                        }
                        pos+=1
                        part='name'
                        position='one'
                        term = ''
                elif part == 'name':
                    raise SQLSyntaxError("Extra ',' or ')' found in create statement.")
                else:
                    raise SQLSyntaxError("Column type not specified for %s."%(column['name']))
            elif part == 'options':
                if sql[pos:pos+6].lower() == 'unique':
                    pos += 6
                    column['unique'] = True
                elif sql[pos:pos+8].lower() == 'required':
                    pos += 8
                    column['required'] = True
                elif sql[pos:pos+11].lower() == 'primary key':
                    pos += 11
                    column['key'] = True
                    
                    
                    #~ if column['key'] and not column['required']:
                        #~ raise SQLError("PRIMARY KEY '%s' is not specified as REQUIRED."%column['name'])
                    #~ if column['key'] and not column['unique']:
                        #~ raise SQLError("PRIMARY KEY '%s' is not specified as UNIQUE."%column['name'])

                
                elif sql[pos] == ' ': #Whitespace
                    pos += 1
                elif sql[pos] in [',',')']:
                    columns.append(column)
                    column = {
                        'name':None,'type':None,'unique':False,'required':False,'key':False,
                        'default': None,
                    }
                    pos+=1
                    part='name'
                    position='one'
                    term = ''
                else: # We must be looking at the default value
                    if sql[pos:pos+7].lower() == 'default':
                        pos+=7
                        while sql[pos] == ' ':
                            pos+=1
                        if sql[pos] == '=':
                            part='default'
                            pos += 1
                            position = 'one'                            
                        else:
                            raise SQLSyntaxError("Expected '=' after 'default' in column %s in CREATE statement."%(len(columns)+1))
                    else:
                        raise SQLSyntaxError("Expected 'default=' or the end of the statement not %s for column %s in CREATE statement."%(repr(sql[pos:pos+7]), len(columns)+1))
            elif part=='default':
                #if column['required']:
                #    raise SQLError("REQUIRED column '%s' cannot also have a DEFAULT value."%column['name'])
                if column['key']:
                    raise SQLError("PRIMARY KEY column '%s' cannot also have a DEFAULT value."%column['name'])
                
                if position == 'one':
                    if sql[pos] == ' ': #Whitespace
                        pos+=1
                    elif sql[pos] == "'":
                        position='defaultString'
                        pos+=1
                    else:
                        position='defaultNonString'
                        if column['default'] == None:
                            column['default'] = sql[pos]
                        else:
                            column['default'] += sql[pos]
                        pos+=1
                elif position=='defaultNonString':
                    if sql[pos] == ' ':
                        position='defaultNonStringEnded'
                        pos+=1
                    elif sql[pos] in [',',"'"]:
                        raise SQLSyntaxError("'%s' character found in the unquoted default value of column %s"%(sql[pos], len(columns)+1))
                    elif sql[pos] == ')':
                        position='defaultNonStringEnded'
                        #pos+=1
                    else:
                        column['default']+=sql[pos]
                        pos+=1
                elif position=='defaultNonStringEnded':
                    if sql[pos] == ' ':
                        pos+=1
                    elif sql[pos] in [',',')']:
                        if column['default'] == 'NULL':
                            column['default']
                        columns.append(column)
                        column = {
                            'name':None,'type':None,'unique':False,'required':False,'key':False,
                            'default': None,
                        }
                        pos+=1
                        part='name'
                        position='one'
                        term = ''
                    else:
                        raise SQLSyntaxError("Non-whitespace character '%s' found after default value of column %s"%(sql[pos], len(columns)+1))
                elif position=='defaultString':
                    if sql[pos:pos+2] == "''":
                        column['default']+="''" # JG Changed form "'"
                        pos+=2
                    elif sql[pos] == "'":
                        position='defaultEnded'
                        pos+=1
                    else:
                        if column['default'] == None:
                            column['default']=sql[pos]
                        else:
                            column['default']+=sql[pos]
                        pos+=1
                elif position=='defaultEnded':
                    if sql[pos] == ' ':
                        pos+=1
                    elif sql[pos] in [',',')']:
                        columns.append(column)
                        column = {
                            'name':None,'type':None,'unique':False,'required':False,'key':False,
                            'default': None,
                        }
                        pos+=1
                        part='name'
                        position='one'
                        term = ''
                    else:
                        raise SQLSyntaxError("Non-whitespace character '%s' found after default value of column %s"%(sql[pos], len(columns)+1))
                else:
                    raise Bug('Programming Error')
            if len(sql) <= pos:
                break
                
        key = False
        for column in columns:
            if column['key']:
                if key:
                    raise SQLError("More than one column specified as PRIMARY KEY.")
                key = True
        return {
            'table':table,
            'columns':columns,
            'function':'create',
        }

    def _parseTable(self, sql, keyword, tableIdentifier):
        "Check the syntax of the starts of the INSERT and CREATE statements, returning a tuple (remaining sql, table name)."
        sql = stripBoth(sql)
        if sql[:len(keyword)+1].lower() <> keyword.lower()+' ':
            raise SQLSyntaxError('%s term not found at start of the %s statement.'%(keyword.upper(), keyword.upper()))
        else:
            sql = stripStart(sql[len(keyword)+1:]) # Remove whitespace
        if sql[:len(tableIdentifier)+1].lower() <> tableIdentifier.lower()+' ':
            raise SQLSyntaxError('%s term not found after %s keyword.'%(tableIdentifier.upper(), keyword.upper()))
        else:
            sql = stripStart(sql[len(tableIdentifier)+1:]) # Remove whitespace
            table = ''
            pos = 0
            for char in sql:
                if char in [',','(',' ']:
                    break
                elif char in allowedCharacters: # Only allowed characters
                    table += char
                else:
                    raise SQLSyntaxError("Table name contains the invalid character '%s' after '%s'."%(char, table))
                pos += 1
            sql = stripBoth(sql[pos:]) # Remove whitespace
        return sql, table

    def parseInsert(self, sql):
        "Expects no spaces between commas and the start of the next term in values. These "
        sql, table = self._parseTable(sql, 'INSERT', 'INTO')
        if sql[0] <> "(":
            raise SQLSyntaxError("Expected a '(' after the table name.")
        else:
            sql=stripStart(sql[1:])
            columns = ''
            for char in sql:
                if not char == ')':
                    if char in allowedCharacters+', ':
                        columns+= char
                    else: 
                        raise SQLSyntaxError("Invalid character '%s' found after '%s' in INSERT statement."%(char, columns))
                else:
                    break
            if len(columns) == len(sql):
                raise SQLSyntaxError("')' not found after column names in INSERT statement.")
            sql = stripStart(sql[len(columns):])
            if not sql[0] == ')':
                raise SQLSyntaxError("Expected ')' after column names in INSERT statement.")
            sql=stripStart(sql[1:])
            columns = stripBoth(columns.split(','))
            for column in columns:
                if columns.count(column) > 1:
                    raise SQLError("The column named '%s' has been specified more than once in the INSERT statement."%(column))
            if sql[:6].lower() <> 'values':
                raise SQLSyntaxError("Expected 'VALUES' after column names in INSERT statement.")
            sql = stripStart(sql[6:])
            if sql[0] <> '(':
                raise SQLSyntaxError("Expected '(' after VALUES in INSERT statement.")
            if sql[-1:] <> ')':
                raise SQLSyntaxError("Expected ')' after column values in INSERT statement.")
            values = smartSplit(sql[1:-1], separater=',', quote="'", linebreak='\n', whitespace=' ', swap={'NULL':None, '?':Param()})
            if len(columns) <> len(values):
                raise SQLError("The number of columns doesn't match the number of values.")
            vals = []
            for value in values:
                if type(value) == type(''):
                    vals.append(str(value).replace("'","''"))
                else:
                    vals.append(value)
            values = vals
            return {
                'table':table,
                'columns':columns,
                'values':values,
                'function':'insert',
            }
            
    def parseSelect(self, sql):
        "Parse a SELECT statement."
        sql = stripBoth(sql)
        order = []
        where = []
        keyword = 'SELECT'
        if sql[:len(keyword)+1].lower() <> keyword.lower()+' ':
            raise SQLSyntaxError('%s term not found at start of the %s statement.'%(keyword.upper(), keyword.upper()))
        else:
            sql = stripStart(sql[len(keyword)+1:]) # Remove whitespace
        pos = sql.lower().find('from')
        if pos == -1:
            raise SQLSyntaxError('FROM term not found after column list in SELECT statement')
        else:
            columns = stripBoth(sql[:pos].split(','))
            if columns[-1] == '':
                raise SQLSyntaxError("Unexpected ',' found after column names and before FROM keyword.")
            if columns <> ['*']:
                for column in columns:
                    for char in column:
                        if char not in allowedCharacters:
                            if column == '*':
                                raise SQLSyntaxError("The special identifier '*' should be used on its own to select all columns.") 
                            raise SQLSyntaxError("Column name '%s' contains the invalid character '%s'."%(column, char))
                    if columns.count(column)>1:
                        raise SQLError("Column '%s' is selected more than once in the SELECT statement."%(column))
            tableIdentifier = 'FROM'
            sql = stripStart(sql[pos+len(tableIdentifier)+1:]) # Remove whitespace
            table = ''
            pos = 0
            for char in sql:
                if char in [',','(',' ']:
                    break
                elif char in allowedCharacters: # Only allowed characters
                    table += char
                else:
                    raise SQLSyntaxError("Table name contains the invalid character '%s' after '%s'."%(char, table))
                pos += 1
            sql = stripBoth(sql[pos:]) # Remove whitespace
            if sql[:6].lower() == 'where ':
                orderbyParts = sql.lower().split('order by')
                if len(orderbyParts) == 1:
                    where = stripBoth(sql[6:])
                elif len(orderbyParts) == 2:
                    where = stripBoth(sql[6:len(orderbyParts[0])])
                    order = stripBoth(sql[len(orderbyParts[0])+8:])
                else:
                    order = sql[len(orderbyParts[-1:]):]
                    where = sql[6:len('order by'.join(orderbyParts[:-1]))]
            elif sql[:9].lower() == 'order by ':
                if sql[9:].lower().find('where') <> -1:
                    raise SQLSyntaxError('WHERE should come before ORDER BY in SELECT statement.')
                order = stripBoth(sql[9:]) 
                    
            if order:
                order = self._parseOrder(order)
        return {
            'table':table,
            'columns': columns,
            'order':order,
            'where':self._parseWhere(where),
            'function':'select',
        }
        
    def _parseOrder(self, order):
        "Parse an ORDER BY clause with the ORDER BY already removed."
        parts = order.split(',')
        orderPairs = []
        cols = []
        for part in parts:
            while part[0] == ' ':
                part = part[1:]
            while part[-1:] == ' ':
                part = part[1:]
            if not part:
                raise SQLSyntaxError('Too many commas in order clause.')
            pair = part.split(' ')
            if len(pair) == 1:
                if pair[0] in cols:
                    raise SQLError("You have specified %s more than once in the ORDER BY clause."%(repr(pair[0])))
                else:
                    cols.append(pair[0])
                    orderPairs.append([pair[0],'asc'])
            elif len(pair) == 2:
                if pair[0] in cols:
                    raise SQLError("You have specified %s more than once in the ORDER BY clause."%(repr(pair[0])))
                elif pair[1].lower() not in ['asc','desc']:
                    raise SQLSyntaxError("Expected 'ASC' or 'DESC' after %s not %s."%(repr(pair[0]),repr(pair[1])))
                else:
                    cols.append(pair[0])
                    orderPairs.append([pair[0],pair[1].lower()])
            else:
                raise SQLSyntaxError("Order clause not properly formed near '%s'."%part)
        return orderPairs

    def _parseWhere(self, where, compOperators=['>','<','=','>=','<=','<>'], logicalOperators=['and', 'or']):
        "Split up an if style clause into blocks of [first term, comparison operator, second term, logical operator]. Does not support brackets, not, like or between."
        if not where:               #0  1    2 3 4 5 6 7  8 9   10
            return []               #|  |test| |=| |'|3|' | |and| |  
        firstChars = []
        for operator in compOperators:
            firstChars.append(operator[:1])
        pos = 0
        position = 0
        blocks = []
        terms = []
        term = ''
        quote = False
        while 1:
            if position == 0:
                if where[pos] == ' ':
                    pos+=1
                elif where[pos] in allowedCharacters:
                    position = 1
                    term+=where[pos]
                    pos+=1
                else:
                    if len(blocks) == 0:
                        raise SQLSyntaxError("Invalid character '%s' found after WHERE keyword."%(where[pos]))
                    else:
                        raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], blocks[0][0]))
            elif position == 1:
                if where[pos] in allowedCharacters:
                    term+=where[pos]
                    pos+=1
                elif where[pos] == ' ': # End of first column
                    position = 2
                    terms.append(term)
                    term = ''
                    pos+=1
                else:
                    terms.append(term)
                    term = ''
                    position=2
            elif position == 2:
                if where[pos] == ' ': 
                    pos+=1
                elif where[pos:pos+2] in compOperators: # The next section is a two character operator
                    terms.append(where[pos:pos+2])
                    term = ''
                    pos+=2
                    position = 4
                elif where[pos] in compOperators: # The next section is a one character operator
                    terms.append(where[pos])
                    term=''
                    pos+=1
                    position = 4
                else:
                    raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], terms[0]))
            elif position == 4:               
                if where[pos] == ' ': 
                    pos+=1
                elif where[pos] == "'":
                    quote=True
                    pos+=1
                    position = 6
                elif where[pos] in allowedCharacters:
                    position = 6
                    term += where[pos]
                    pos+=1
                elif where[pos] == '?':
                    terms.append(Param())
                    term = ''
                    position = 8
                    pos+=1
                    if len(where) == pos:
                        blocks.append(terms)
                        return blocks
                else:
                    raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], terms[1]))
            elif position == 6:
                if not quote:
                    if where[pos] in ["'",',','\n']:
                        raise SQLSyntaxError("Invalid character '%s' found after operator in WHERE clause. Try removing the space after the operator or quoting the value."%(where[pos]))
                    elif where[pos] == ' ':
                        if term.upper() == 'NULL':
                            terms.append(None)
                        else:
                            terms.append(term)
                        term = ''
                        position = 8
                        pos+=1
                    else:
                        term+=where[pos]
                        pos+=1
                        if len(where) <= pos:
                            if term.upper() == 'NULL':
                                terms.append(None)
                            else:
                                terms.append(term)
                            terms.append('')
                            blocks.append(terms)
                            return blocks
                else:
                    if where[pos] == "'" and where[pos:pos+2] == "''":
                        term += "''" # JG Changed form "'"
                        pos += 2
                    elif where[pos] == "'" and where[pos:pos+2] == "' ":
                        pos += 2
                        terms.append(term)
                        term = ''
                        position = 8
                    elif where[pos] == "'" and len(where) == pos+1:
                        terms.append(term)
                        terms.append('')
                        blocks.append(terms)
                        return blocks
                    elif where[pos] == "'":
                        raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], term))
                    else:
                        term+=where[pos]
                        pos+=1
            elif position == 8:
                if where[pos] == ' ':
                    pos+=1
                else:
                    max = 0
                    found = False
                    for operator in logicalOperators:
                        if len(operator)>max:
                            max = len(operator)
                    for length in range(1,max):
                        if length < len(where[pos:]):
                            if where[pos:pos+length+1].lower() in logicalOperators:
                                terms.append(where[pos:pos+length+1].lower())
                                blocks.append(terms)
                                terms=[]
                                term = ''
                                pos+=length+1
                                position = 0
                                quote=False
                                found = True
                    if not found: # XXX maybe could be added to columns code too?
                        raise SQLSyntaxError("Extra character %s found after ? in WHERE clause."%(where[pos]))
            if len(where) < pos+1:
                if len(terms) == 2:
                    terms.append(term)
                    terms.append('')
                    blocks.append(terms)
                    return blocks
                else:
                    raise SQLSyntaxError("WHERE clause ended too early.")
        
    def parseUpdate(self, sql):
        sql = stripBoth(sql)
        table = ''
        where = []
        columns = []
        keyword = 'UPDATE'
        if sql[:len(keyword)+1].lower() <> keyword.lower()+' ':
            raise SQLSyntaxError('%s term not found at start of the %s statement.'%(keyword.upper(), keyword.upper()))
        else:
            sql = stripStart(sql[len(keyword)+1:]) # Remove whitespace
        pos = sql.lower().find('set')
        if pos == -1:
            raise SQLSyntaxError('SET term not found after table name in UPDATE statement')
        else:
            table = ''
            for char in stripBoth(sql[:pos]):
                if char in allowedCharacters:
                    table+=char
                else:
                    raise SQLSyntaxError("Invalid character '%s' near '%s' before SET keyword."%(char, table))
            sql = stripStart(sql[pos+len('set')+1:]) # Remove whitespace
            whereParts = sql.lower().split(' where ')
            if len(whereParts) == 1:
                columns = stripBoth(sql[:len(whereParts[0])])
            elif len(whereParts) == 2:
                columns = stripBoth(sql[:len(whereParts[0])])
                where = self._parseWhere(stripBoth(sql[len(whereParts[0])+7:]))
            else:
                raise SQLSyntaxError("More than one WHERE clause specified.")
                
            cols = []
            vals = []
            
            for col, op, val in self._parseColumns(columns):
                cols.append(col)
                vals.append(val)
        return {
            'table':table,
            'columns': cols,
            'values': vals,
            'where':where,
            'function':'update',
        }
        
    def _parseColumns(self, sql, compOperators=['=']):
        # XXX WHERE keyword needs changing everywhere.
        "Split up an if style clause into blocks of [first term, comparison operator, second term, logical operator]. Does not support brackets, not, like or between."
        where = sql             #0  1   2 3 4 5 6  7 8 9 10
        firstChars = []         #|  |one| |=| |'67'| |,| |
        for operator in compOperators:  # START Same code as where
            firstChars.append(operator[:1])
        pos = 0
        position = 0
        blocks = []
        terms = []
        term = ''
        quote = False
        while 1:
            if position == 0:
                if where[pos] == ' ':
                    pos+=1
                elif where[pos] in allowedCharacters:
                    position = 1
                    term+=where[pos]
                    pos+=1
                else:
                    if len(blocks) == 0:
                        raise SQLSyntaxError("Invalid character '%s' found after WHERE keyword."%(where[pos]))
                    else:
                        raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], blocks[0][0]))
            elif position == 1:
                if where[pos] in allowedCharacters:
                    term+=where[pos]
                    pos+=1
                elif where[pos] == ' ': # End of first column
                    position = 2
                    terms.append(term)
                    term = ''
                    pos+=1
                else:
                    terms.append(term)
                    term = ''
                    position=2
            elif position == 2:
                if where[pos] == ' ': 
                    pos+=1
                elif where[pos:pos+2] in compOperators: # The next section is a two character operator
                    terms.append(where[pos:pos+2])
                    term = ''
                    pos+=2
                    position = 4
                elif where[pos] in compOperators: # The next section is a one character operator
                    terms.append(where[pos])
                    term=''
                    pos+=1
                    position = 4
                else:
                    raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], terms[0]))
            elif position == 4:               
                if where[pos] == ' ': 
                    pos+=1
                elif where[pos] == "'":
                    quote=True
                    pos+=1
                    position = 6
                elif where[pos] in allowedCharacters:
                    position = 6
                    term += where[pos]
                    pos+=1
                elif where[pos] == '?':
                    terms.append(Param())
                    term = ''
                    position = 8
                    pos+=1
                    if len(where) == pos:
                        blocks.append(terms)
                        return blocks
                else:
                    raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], terms[1]))
            elif position == 6: # END SAME AS WHERE CODE
                if not quote:
                    if where[pos] in ["'",'\n']:
                        raise SQLSyntaxError("Invalid character '%s' found after operator in WHERE clause. Try removing the space after the operator or quoting the value."%(where[pos]))
                    elif where[pos] == ' ':
                        if term.upper() == 'NULL':
                            terms.append(None)
                        else:
                            terms.append(term)
                        term = ''
                        position = 8
                        pos+=1
                    elif where[pos] == ',':
                        if term.upper() == 'NULL':
                            terms.append(None)
                        else:
                            terms.append(term)
                        blocks.append(terms)
                        terms=[]
                        term = ''
                        pos+=1
                        position = 0
                    else:
                        term+=where[pos]
                        pos+=1
                        if len(where) <= pos:
                            if term.upper() == 'NULL':
                                terms.append(None)
                            else:
                                terms.append(term)
                            #terms.append('')
                            blocks.append(terms)
                            return blocks
                else:
                    if where[pos] == "'" and where[pos:pos+2] == "''":
                        term += "''" # JG Changed form "'"
                        pos += 2
                    elif where[pos] == "'" and where[pos:pos+2] == "' ":
                        pos += 2
                        terms.append(term)
                        term = ''
                        position = 8
                    elif where[pos] == "'" and where[pos:pos+2] == "',":
                        terms.append(term)
                        pos+=1
                        position = 8
                        quote=False
                    elif len(where) == pos+1:
                        terms.append(term)
                        blocks.append(terms)
                        return blocks
                    elif where[pos] == "'":
                        raise SQLSyntaxError("Invalid character '%s' found after '%s' in WHERE clause."%(where[pos], term))
                    else:
                        term+=where[pos]
                        pos+=1
            elif position == 8:
                if where[pos] == ' ':
                    pos+=1
                elif where[pos] == ',':
                    blocks.append(terms)
                    terms=[]
                    term = ''
                    pos+=1
                    position = 0
                    quote=False
            if len(where) <= pos:
                if len(terms) == 2:
                    terms.append(term)
                    blocks.append(terms)
                    return blocks
                else:
                    raise SQLSyntaxError("SET clause ended too early. Perhaps there was an extra comma?")
        
    def parseDelete(self, sql):
        sql, table = self._parseTable(sql, 'DELETE', 'FROM')
        sql = stripBoth(sql)
        where=[]
        if sql[:6].lower() == 'where ':
            where = self._parseWhere(stripStart(sql[6:]))
        return {
            'table':table,
            'where':where,
            'function':'delete',
        }

if __name__ == '__main__':
    s = SQLParser()
    print s.parse("""CREATE TABLE table_name1( column_name1 data_type unique required primary key default='as''d' ,  column_name2 data_type )""")
    print s.parse("INSERT INTO table_name1 (column_name1, column_name2) VALUES ('te,''\nst', '88')")
    print s.parse("""select one, two from table where one = 'NULL' and two >= ' 2 asd 1 ' order BY column DESC, two """)
    print s.parse("""UPDATE table SET one =  '6\n,''7', two=24 WHERE one = 12 and two=22 """)
    print s.parse("""delete from table where one=11 or two=22 or three = '2 3' or four= 55 or five =90""")
    print s.parse("""drop    table    tableName    """)