#!/usr/bin/env python

import shutil, sys, os, os.path
useage="""Useage: setup.py [option]

Options
 install   Install the modules
 bdist     Create a binary distribution"""


def install(dir, name):
    print "Installing %s"%name
    def choosePath(inst):
        while not(os.path.exists(inst) and (not os.path.exists(inst+os.sep+'web'))):
            if not os.path.exists(inst):
                print "There is no such path '%s'."%inst
            else:
                print "There is already a '%s' directory at the location '%s'. Are the modules already installed?"%(dir, inst+os.sep+dir)
                
            if raw_input('Would you like to install the modules somewhere else? [y/n]: ') == 'y':
                inst = raw_input('Please enter a directory into which to install the modules: ')
            else:
                print "Install aborted."
                raw_input('Press ENTER to exit.')
                sys.exit(1)
        return inst
        
    from distutils import sysconfig
    inst = sysconfig.get_python_lib()
        
    if raw_input("The default directory for installation is '%s' Accept this location? [y/N]: "%(inst+os.sep)) == 'y':
        inst = choosePath(inst)
    else:
        inst = choosePath(raw_input('Enter install directory: '))
        
    if inst not in sys.path:
        print "The installation directory '%s' is not on your sys.path. This means that if the modules were to be installed there you would not be able to import them unless you modified your path with code as follows:"%inst
        print "import sys; sys.path.append('%s')\n"%inst
    
    if raw_input('Continue with installation? [y/N]: ') == 'y':
        print "Installing the modules to '%s'..."%(inst+os.sep+dir)
        shutil.copytree(dir, inst+os.sep+dir)
        print "%s successfully installed."%name
    else:
        print "Install aborted."
    raw_input('Press ENTER to exit.')

def bdist(dirName, archiveName, archiveType='zip', excludeAllDirs=[], excludeDirs=[], excludeAllFiles=[], excludeFiles=[], binaries=[], excludeExtensions=[]):

    excludeDirs.append('build')
    excludeDirs.append('dist')
    import os
    from distutils.errors import DistutilsExecError
    from distutils.spawn import spawn
    from distutils.dir_util import mkpath
    #from distutils import log

    from distutils.archive_util import make_tarball,make_zipfile,ARCHIVE_FORMATS,check_archive_formats, make_archive

    def copytree(src, dst, symlinks=0):
        if binaries:
            binaries.remove(str(sys.platform+'-'+sys.version[:3].replace('.','_')))
        names = os.listdir(src)
        if os.path.normpath(dst).replace(os.sep,'/') not in excludeDirs and dst not in excludeAllDirs:
            #print 'Making '+dst
            os.mkdir(dst)

        for name in names:
            srcname = os.path.normpath(os.path.join(src, name)).replace(os.sep,'/')
            dstname = os.path.normpath(os.path.join(dst, name)).replace(os.sep,'/')
            try:
                if symlinks and os.path.islink(srcname):
                    linkto = os.readlink(srcname)
                    os.symlink(linkto, dstname)
                elif os.path.isdir(srcname):
                    if srcname not in excludeDirs:
                        if os.path.split(srcname)[1] not in excludeAllDirs:
                            if srcname not in binaries:
                                copytree(srcname, dstname, symlinks)
                            else:
                                pass
                        else:
                            pass
                    else:
                        pass
                elif srcname in excludeFiles:
                    pass
                elif os.path.split(srcname)[1] in excludeAllFiles:
                    pass
                else:
                    found = False
                    for ext in excludeExtensions:
                        if os.path.split(srcname)[1][-len(ext):] == ext:
                            found=True
                    if not found:
                        print "Copying %s"%srcname
                        shutil.copy2(srcname, dstname)

            except (IOError, os.error), why:
                print "Can't copy %s to %s: %s" % (`srcname`, `dstname`, str(why))
    
    print "Building a new binary distribution..."
    if os.path.exists('build'):
        print "Removing old builds..."
        shutil.rmtree('build')
    print "Copying directories..."
    os.mkdir('build')
    #if not os.path.exists('build/'+dirName):
    #    os.mkdir('build/'+dirName)
    copytree('./','build/'+dirName)
    
    zip_filename = '../dist/'+archiveName+'.zip'
    if not os.path.exists('dist'):
        print "Creating dist directory..."
        os.mkdir('dist')
    if os.path.exists(zip_filename):
        print "Removing old version..."
        os.remove(zip_filename)
        
    os.chdir('build')
    make_archive(archiveName, archiveType, root_dir=None, base_dir=dirName,verbose=0, dry_run=0)
    if os.path.exists(archiveName+'.zip'):
        if os.path.exists('../dist/'+archiveName+'.zip'):
            print "Removing old distribution..."
            os.remove('../dist/'+archiveName+'.zip')
        
        os.rename(archiveName+'.zip', '../dist/'+archiveName+'.zip')
    print "\n%s distribution created successfully."%dirName
    

    
