
import os.path, sys
from base import *
sys.path.append('../external') # For lockcsv
sys.path.append('../') # For errors
import lockcsv

class LockCSV(BaseDriver):

    def __init__(self):
        self.tableExtensions = ['.csv']

    def _checkTableFilesExist(self, tables):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        for table in tables: # Check each of the tables listed actually exists.
            for end in ['.dat','.dir']:
                if not os.path.exists(self.database+os.sep+table+end):
                    raise CorruptionError("Table file '%s' not found."%(table+end))
                    
    def _loadTable(self, table):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        self.tableFiles[table] = lockcsv.open(self.database+os.sep+table)

    def _closeTable(self, table):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        self.tableFiles[table].close()

    # Useful methods
    def databaseExists(self):
        "Return True if the database exists, False otherwise."
        if self._closed:
            raise Error('The connection to the database has been closed.')
        if os.path.exists(self.database) and os.path.exists(self.database+os.sep+self.colTypesName+'.dir') and os.path.exists(self.database+os.sep+self.colTypesName+'.dat'):
            return True
        else:
            return False

    def _deleteTableFromDisk(self, table):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        for end in self.tableExtensions:
            #if os.path.exists(self.database+os.sep+table+end):
            os.remove(self.database+os.sep+table+end)

    def _insertRow(self, table, key, values, types=None):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        v = []
        for value in range(len(values)):
            if types:
                v.append(repr(self.typeToInternal(types[value], values[value])))
            else:
                key = None
                for k in self.tableStructure[table].keys():
                    if self.tableStructure[table][k]['position'] == value:
                        key = k
                if not key:
                    raise ConversionError("No column definition found for value %s. Too many values specified."%repr(value))
                v.append(repr(self.typeToInternal(self.tableStructure[table][k]['type'], values[value])))
        self.tableFiles[table][str(key)] = values

    def _deleteRow(self, table, key):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        del self.tableFiles[table][key]

    def _getRow(self, table, key):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        r = []
        row = self.tableFiles[table][key]
        for item in row:
            #if self.tableStructure[table][key]['type'] 
            r.append(eval(item))
        return r
    
    def _updateRow(self, table, oldkey, newkey, values):
        if self._closed:
            raise Error('The connection to the database has been closed.')
        if newkey == None:
            newkey=oldkey
        del self.tableFiles[table][oldkey]  # XXX Is this a bug in dumbdbm?
        if self.tableFiles[table].has_key(newkey):
            raise Bug("The table %s already has a PRIMARY KEY named '%s'. This error should have been caught earlier."%(table,newkey))
        self.tableFiles[table][newkey] = str(values)
        return values
